---
name: job-search-multiplatform
display_name: 全平台岗位搜索
display_name_en: Multi-Platform Job Search
description: 全平台岗位搜索引擎。当用户要找工作、搜岗位、查招聘信息、看职位行情、对比各平台职位时使用。覆盖 BOSS直聘、猎聘、智联、拉勾、汇博及远程渠道，按"活跃优先"排序，单一方式失败自动降级到下一种，跨平台去重后输出统一清单（招聘岗位、薪资、地点、JD内容、平台链接）。
description_zh: 全平台岗位搜索引擎。当用户要找工作、搜岗位、查招聘信息、看职位行情、对比各平台职位时使用。覆盖 BOSS直聘、猎聘、智联、拉勾、汇博及远程渠道，按"活跃优先"排序，强制抓取完整 JD，单一方式失败自动降级到下一种，跨平台去重后输出统一清单（招聘岗位、薪资、地点、完整JD内容、平台链接）。
description_en: Multi-platform job search engine. Use when the user wants to find jobs, search positions, check hiring market, or compare listings across platforms. Covers BOSS Zhipin, Liepin, Zhaopin, Lagou, Huibo and remote channels. Prioritizes active listings, requires full JD content per job, auto-degrades to the next method on failure, and deduplicates across platforms into a unified list (title, salary, location, full JD, platform links).
version: 1.0.1
---

# 全平台岗位搜索 (Multi-Platform Job Search)

## 目标

一次搜索请求，覆盖**所有主流招聘平台**，输出一张去重后的统一岗位清单：

| 招聘岗位 | 薪资 | 地点 | JD内容 | 平台链接 |
|---|---|---|---|---|

## 必填参数（缺失必须追问，不要猜）

| 参数 | 说明 | 示例 |
|---|---|---|
| **岗位关键词** | 职位名称或方向，可多个 | `AI产品经理`、`大模型算法` |
| **城市** | 可多选，或"不限/远程" | `北京`、`杭州+上海` |
| **薪资下限**（可选但强烈建议） | 月薪 K | `25K以上` |

追问模板：

```
请补充以下信息：
1. 岗位：想搜索什么职位？（如：AI产品经理、大模型算法工程师）
2. 城市：哪些城市？（如：北京、杭州，或"不限"）
3. 薪资：期望月薪下限？（如：25K，可跳过）
```

## 核心原则（按优先级）

1. **全平台覆盖**：每次搜索必须覆盖下方「平台矩阵」中全部主力平台，不得因某个平台麻烦而跳过。
2. **完整 JD 强制获取**：进入最终清单的**每一个岗位**，`job_desc` 必须是完整 JD 原文（岗位职责逐条 + 任职要求 + 加分项）。列表页只有方向标签/摘要信息时，**必须**对该岗位执行方式4（详情页抓取）补全；方式4 也失败才允许标注「JD 需平台内查看」，且在「数据来源说明」中列出所有未补全的岗位编号。
3. **活跃优先**：只保留在招岗位，按活跃度/发布新鲜度排序（见 references/dedup-rules.md「活跃优先」一节）。
4. **失败降级**：每种搜索方式失败（报错/超时/空结果/被拦截）时，自动切换到下一种方式，不中断整体搜索（见「降级链」）。
5. **跨平台去重**：同公司+同岗位合并为一条，标记多平台来源，保留全部链接（见 references/dedup-rules.md）。
6. **诚实标注**：某平台无结果或降级，在报告"数据来源说明"中如实注明，不编造数据。

## 平台矩阵

| 平台 | 定位 | 主链接域名 |
|---|---|---|
| BOSS直聘 | 直聊、互联网/新经济、更新快 | zhipin.com |
| 猎聘 | 中高端、5年+经验 | liepin.com |
| 智联招聘 | 综合、传统行业/国企/央企多 | zhaopin.com |
| 拉勾招聘 | 互联网垂直、技术/产品岗 | lagou.com |
| 汇博招聘 | 重庆/西南区域 | huibo.com |
| 51job | 综合、长三角/珠三角制造业多 | 51job.com |
| 电鸭社区 | 远程岗位 | eleduck.com |
| V2EX 酷工作 | 技术圈远程/freelance | v2ex.com/go/jobs |
| 小蜜蜂远程 | 远程聚合 | xiaomifeng.work |

按用户行业调整权重：互联网技术岗重 BOSS+拉勾；中高端重猎聘；传统行业/国企重智联；西南区域必查汇博；要远程必查电鸭+V2EX。

## 搜索方式与降级链（每平台独立执行）

对**每个平台**，按以下顺序尝试，**一种失败立即换下一种**，成功即停：

```
方式1 CLI 工具（已安装且已登录时，结构化 JSON，最优）
  ↓ 失败/未安装/未登录
方式2 HTTP 直接抓取（requests + BeautifulSoup 解析静态/半静态页）
  ↓ 失败（反爬/动态渲染/空结果）
方式3 搜索引擎聚合（web_search + site: 限定，最稳的兜底）
  ↓ 也无结果
方式4 详情页抓取（JD 补全：对最终清单岗位逐条 fetch 详情页，获取完整 JD）
  ↓ 动态页无法解析
方式5 人工提示（告知用户需登录该平台，跳过，不阻塞其他平台）
```

### 方式1：CLI 工具

**BOSS直聘 — `boss-cli`**（安装：`uv tool install kabi-boss-cli`）：

```bash
# 检查登录（先做，不要假设已登录）
boss status --json 2>/dev/null | jq -r '.authenticated' | grep -q true && echo "AUTH_OK" || echo "AUTH_NEEDED"
# 未登录：boss login（自动从浏览器取 cookie）或 boss login --qrcode
# 搜索（注意：不要并行请求，内置限速保护账号）
boss search "关键词" --city 杭州 --salary 20-30K --json
boss search "关键词" --city 杭州 --salary 20-30K --exp 3-5年 --scale 1000-9999人 --json
# 详情 / 导出
boss detail <securityId> --json
boss export "关键词" --city 杭州 -n 50 -o jobs.csv
```

错误处理：`环境异常(__zp_stoken__过期)` → `boss logout && boss login`；rate_limited → 等待自动冷却；薪资字段为空是已知限制（服务端隐藏），用猎聘同岗位参考。

**猎聘 — `liepin-cli`**：

```bash
liepin-cli job search --job-name "关键词" --address "北京" --salary-floor 25 --page 0 --output json
# token 过期：liepin-cli auth open && liepin-cli auth setup
# job apply 的 --job-kind 必须复用搜索结果返回值，禁止猜测
```

### 方式2：HTTP 直接抓取

用 `scripts/scrape_platforms.py`（依赖 requests + beautifulsoup4，需 Python 3.10+）：

```bash
python3 scripts/scrape_platforms.py --platform liepin --keyword "AI产品经理" --city "北京" --pages 2
python3 scripts/scrape_platforms.py --platform zhaopin --keyword "AI产品经理" --city "北京" --pages 2
```

内置技术要点（详见 references/platform-methods.md）：

- **猎聘 URL 模板**（两种）：
  - `https://www.liepin.com/city-{城市码}/zp{URL编码关键词}/?currentPage={页码}`
  - `https://www.liepin.com/search/?dqs={dqs城市码}&key={关键词}&compsalary={下限},100&sortFlag=15&d_pageSize=40&d_curPage={页码-1}`（`sortFlag=15` = 最新发布，活跃优先）
- **智联 URL 模板**：`https://sou.zhaopin.com/?jl={城市码}&kw={关键词}&p={页码}`
- 城市代码对照表（猎聘 bj/sh/sz… 与 dqs 数字码、智联 530/538/765…、BOSS 101010100 气象码）见 references/platform-methods.md
- 请求头带桌面 Chrome UA + zh-CN Accept-Language
- 每次请求间 `time.sleep(random.uniform(2, 5))` 随机延迟；连续失败改用渐进式延迟（2s→2.5s→…封顶10s）
- 选择器多级兜底：精确 class → `[class*='job-card']` 模糊匹配 → 正则

**BOSS直聘 CDP 方式**（可选增强，方式2 的子分支，需用户配合）：

- 用独立 Chrome 实例开 CDP 端口 9222，走官方内部接口 `GET https://www.zhipin.com/wapi/zpgeek/search/joblist.json?query=...&city={气象码}&page=1...`
- 参数：`--keyword --city 101210100 --scale 305(1000-9999人) --salary 406(20-30K 等) --pages ≤10 --detail`（附 JD 详情抓取）
- 城市码示例：北京101010100 上海101020100 广州101280100 深圳101280600 杭州101210100 成都101270100（全表见 references/platform-methods.md）
- 未登录/出验证码时**提示用户人工在浏览器完成**，不绕过

### 方式3：搜索引擎聚合（最稳兜底，无需登录）

```
site:zhipin.com {岗位} {城市} 招聘
site:liepin.com {岗位} {城市} 招聘
site:zhaopin.com {岗位} {城市} 招聘
site:lagou.com {岗位} {城市}
site:huibo.com {岗位} {城市} 招聘        # 仅西南城市需要
site:eleduck.com {岗位} 远程             # 仅远程需求
site:v2ex.com 酷工作 {岗位}
```

规则：
- 加 `search_recency` 时间过滤（默认 week，最多 month）——**活跃优先的关键手段**
- 每平台 1-3 个 query，总搜索次数 ≤ 20 次；每 query 取前 5 条
- site: 无结果时去掉 site: 改用"平台名 + 岗位 + 城市"搜索
- 小众岗位自动扩同义词（如"前端开发"+"web前端"+"JavaScript开发"）
- 从摘要抽取字段：title / company / salary / location / link，缺关键字段的条目丢弃并计数

### 方式4：详情页抓取（JD 补全，**必执行步骤**）

对**进入最终清单的所有岗位**逐条执行（不再限于每平台 3 条）：

- 优先用平台 CLI 的详情命令（如 `boss detail <securityId> --json`）
- 其次 WebFetch / requests 抓取详情页，提取完整 JD：岗位职责逐条、任职要求、加分项、公司背景与福利
- 随机延迟 2-5s，避免批量轰炸
- 动态页/登录墙解析失败 → 换用搜索引擎 `"{岗位名}" "{公司名}" JD/岗位职责` 定位聚合站详情页再抓
- 全部方式失败 → 该岗位标注「JD 需平台内查看」，并在「数据来源说明」中列出编号，**不编造 JD 内容**
- JD 补全结果直接写入该岗位的 `job_desc` 字段，最终内联展示在清单条目中

### 方式5：人工提示

仅在用户明确要求某平台深度采集但所有自动方式都失败时使用：告知需登录/验证，请用户在浏览器登录后重试，**不阻塞其余平台**。

## 统一数据结构

每条岗位标准化为：

```json
{
  "title": "AI产品经理",
  "company": "XX科技",
  "salary": "25-50K·16薪",
  "location": "杭州-余杭",
  "experience": "3-5年",
  "education": "本科",
  "job_desc": "完整 JD 原文：岗位职责逐条 + 任职要求 + 加分项，不做摘要压缩；仅列表页可得时如实标注「JD 需平台内查看」",
  "activity": "本周发布 / 刚刚活跃 / 3天内更新",
  "sources": [
    {"platform": "BOSS直聘", "url": "https://www.zhipin.com/job_detail/xxx.html"},
    {"platform": "猎聘", "url": "https://www.liepin.com/job/xxx.html"}
  ],
  "crawl_time": "2026-09-10T10:00:00"
}
```

## 活跃优先规则（详见 references/activity-rules.md）

1. **硬过滤**：标题/状态含「停止招聘、已暂停、已下线、暂停招聘」直接剔除
2. **新鲜度信号**：猎聘 `sortFlag=15`；搜索引擎 recency=week；BOSS 活跃时间字段（"刚刚活跃/今日活跃"）；发布/更新时间在 2 周内
3. **排序**：活跃/发布时间新鲜 → 多平台在招（≥2 平台出现，说明真在招）→ 薪资明确度 → 匹配度
4. 薪资"面议"不剔除，但排序靠后并标注

## 去重规则（详见 references/dedup-rules.md）

- 主键 = 规范化公司名 + 规范化岗位名（去空格/去【】/去括号内城市与数字/统一大小写）+ 城市
- 命中主键 → 合并：`sources` 追加平台链接、薪资取更新鲜一方的值、JD 取更完整的一方
- 同公司不同岗位名 = 独立条目；不同公司同名岗位 = 独立条目
- 可运行 `python3 scripts/dedup_merge.py --input merged.json --out final.json --format md`（纯标准库，无依赖）完成合并与清单渲染

## 输出清单（最终交付）

**岗位速览表 + 岗位清单（每条含完整 JD 原文）**，写入 `岗位清单_YYYY-MM-DD.md`。
**注意：清单中每条岗位直接附完整 JD（逐条职责+要求），不写摘要；不要设置单独的「JD 详情」章节。**

```markdown
# 岗位搜索清单 — {关键词} · {城市} · {日期}

## 汇总
- 覆盖平台：BOSS直聘 ✅ / 猎聘 ✅ / 智联 ✅ / 拉勾 ⚠️(降级聚合) / …
- 去重前 N 条 → 去重后 M 条；活跃岗位 X 条

## 岗位速览表

| # | 招聘岗位 | 公司 | 薪资 | 地点 | 活跃度 | 平台链接 |
|---|---------|------|------|------|--------|---------|
| 1 | … | … | 25-50K·16薪 | 杭州-余杭 | 本周发布 | [BOSS](url) [猎聘](url) |

## 岗位清单（含完整 JD，按活跃度排序）

### 1. AI产品经理 — XX公司
- 薪资：… / 地点：… / 经验：… / 学历：…
- JD内容：（完整原文，职责逐条+任职要求，不摘要）
- 链接：BOSS直聘 url ｜ 猎聘 url

## 数据来源说明
- 各平台使用的搜索方式（CLI / HTTP / 聚合）、失败与降级记录、抓取时间
```

需要表格文件时，用 xlsx skill 导出同结构 Excel。

## 执行检查清单

- [ ] 收齐参数（岗位/城市/薪资下限）
- [ ] BOSS直聘：方式1→2→3 依次尝试
- [ ] 猎聘：方式1→2→3
- [ ] 智联：方式2→3
- [ ] 拉勾 / 51job：方式3（+4）
- [ ] 区域/远程渠道（按需）：汇博 / 电鸭 / V2EX
- [ ] 活跃过滤 + 排序
- [ ] 跨平台去重合并
- [ ] **JD 补全（方式4）：对最终清单每个岗位抓详情页，job_desc 为完整 JD 原文，未补全的列入数据来源说明**
- [ ] 生成清单文件并交付（每条岗位内联完整 JD，无单独 JD 详情章节）
- [ ] 附数据来源说明（含降级记录 + JD 未补全清单）

## 安全与合规

- 不绕过验证码/登录墙；需要登录时提示用户人工完成
- 不并行轰炸平台请求；尊重内置限速与随机延迟
- 仅采集公开可索引信息，用于个人求职研究
- 不把用户简历/个人信息发送到无关外部服务
