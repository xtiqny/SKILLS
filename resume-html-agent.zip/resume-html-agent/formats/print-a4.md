---
id: print-a4
name: A4 打印
flow: paged
page_width: 210mm
page_height: 297mm
---

# A4 打印规范

## 安全区

- 页面：210mm × 297mm。
- 推荐内边距：上下 12–16mm，左右 14–18mm。
- 正文 9–10.5pt；辅助文字不低于 7pt。
- 页面按正常文档流排列。

## 基础 CSS

```css
* { box-sizing: border-box; }

*, *::before, *::after {
  animation: none !important;
  transition: none !important;
}

html { scroll-behavior: auto; }

@page {
  size: A4 portrait;
  margin: 0;
}

.resume-book {
  width: 210mm;
  margin: 0 auto;
}

.resume-page {
  position: relative;
  width: 210mm;
  height: 297mm;
  padding: 14mm 16mm;
}

.resume-page + .resume-page {
  break-before: page;
  page-break-before: always;
}

.resume-item,
.project-item,
.metric-card {
  break-inside: avoid;
  page-break-inside: avoid;
}

.section-title {
  break-after: avoid;
  page-break-after: avoid;
}

@media print {
  html, body {
    margin: 0;
    background: #fff;
  }

  .screen-only { display: none !important; }

  .resume-book {
    display: block;
    width: auto;
    margin: 0;
  }

  .resume-page {
    display: block;
    position: relative;
    float: none;
    width: 210mm;
    height: 297mm;
    margin: 0;
    box-shadow: none;
    -webkit-print-color-adjust: exact;
    print-color-adjust: exact;
  }

  .resume-page + .resume-page {
    break-before: page;
    page-break-before: always;
  }
}
```

## 禁止项

- 不得把全部 `.resume-page` 设为绝对定位。
- 不得用 `overflow:hidden` 或 `overflow:clip` 隐藏正文。
- 不得只依赖视觉高度判断是否溢出。
- 不得通过缩放整页或使用低于 9pt 的正文满足页数。
- 不得复用会将单个报告绝对定位到第一页的打印类。
- 不得使用动画、转场、平滑滚动或自动播放效果。

## 验收

`.resume-page` 数量必须与打印预览页数一致。逐页检查 `scrollHeight <= clientHeight + 1`，并检查空白页、内容裁切、页脚越界和背景关闭后的基本可读性。
