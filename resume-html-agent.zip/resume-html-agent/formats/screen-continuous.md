---
id: screen-continuous
name: 网页浏览
flow: continuous
print_required: false
---

# 连续响应式网页

## 目标

生成适合浏览器直接阅读的连续 HTML 简历，不考虑纸张分页。允许使用屏幕友好的留白、轻量阴影和响应式布局，但核心内容必须离线可用。

## 结构

- 使用单一 `.resume-document` 主容器。
- 不生成 `.resume-page`、页码或固定纸张高度。
- 不使用 `@page`、`break-before:page` 或 `page-break-*`。
- 页面最大宽度建议 900–1100px，窄屏保留 16–24px 页面边距。
- 双栏版式在窄屏折叠成单栏；工作经历阅读顺序必须保持正确。

## 基础 CSS

```css
* { box-sizing: border-box; }

*, *::before, *::after {
  animation: none !important;
  transition: none !important;
}

html { scroll-behavior: auto; }

body {
  margin: 0;
  min-width: 0;
}

.resume-document {
  width: min(calc(100% - 40px), 980px);
  margin: 32px auto;
}

img, svg, table {
  max-width: 100%;
}

@media (max-width: 720px) {
  .resume-document {
    width: min(calc(100% - 24px), 980px);
    margin: 12px auto;
  }

  .layout-columns {
    grid-template-columns: 1fr;
  }
}

```

## 允许

- 屏幕预览阴影和柔和背景。
- 目录锚点等静态渐进增强；关闭 JavaScript 时核心履历仍需完整显示。
- 在视觉风格允许时使用有限的响应式装饰。

## 禁止

- 固定 `210mm × 297mm` 页面。
- 为屏幕输出人为切成多个纸张页面。
- 固定高度、隐藏溢出或横向滚动。
- 依赖 hover 才能看到关键事实。
- 动画、转场、平滑滚动、自动轮播或逐步出现效果。
- 将打印页脚或重复页眉混入连续网页。

## 验收

至少在 375px、768px 和 1440px 视口检查：无水平滚动、无内容裁切、阅读顺序正确、字号和对比度达标。
