---
id: slides-16x9
name: 16:9 演示分页
flow: paged
page_width: 13.333in
page_height: 7.5in
aspect_ratio: 16/9
---

# 16:9 演示分页规范

## 目标

生成宽屏 16:9 演示文稿比例的静态 HTML 简历。每个 `.resume-slide` 对应一张幻灯片，适合屏幕展示、分页浏览或导出 PDF；输出仍是 HTML，不生成 `.pptx` 文件。

## 分页结构

- 使用一个 `.resume-deck[data-output-format="slides-16x9"]` 根容器。
- 每张幻灯片使用独立 `.resume-slide`，尺寸为 13.333in × 7.5in。
- 幻灯片按正常文档流排列，从第二张开始强制分页。
- 每张幻灯片只承载一个主要主题，优先按完整经历、项目或能力组分页，不在句子或单条项目中间拆分。
- 宽屏可使用更明确的左右分区，但阅读顺序必须在 DOM 中保持正确。

## 基础 CSS

```css
* { box-sizing: border-box; }

*, *::before, *::after {
  animation: none !important;
  transition: none !important;
}

html { scroll-behavior: auto; }

@page {
  size: 13.333in 7.5in;
  margin: 0;
}

.resume-deck {
  width: 13.333in;
  margin: 0 auto;
}

.resume-slide {
  position: relative;
  width: 13.333in;
  height: 7.5in;
  padding: 0.55in 0.7in;
}

.resume-slide + .resume-slide {
  break-before: page;
  page-break-before: always;
}

@media print {
  html, body { margin: 0; background: #fff; }
  .resume-deck { width: auto; margin: 0; }
  .resume-slide {
    display: block;
    width: 13.333in;
    height: 7.5in;
    margin: 0;
    box-shadow: none;
    -webkit-print-color-adjust: exact;
    print-color-adjust: exact;
  }
}
```

## 排版与可读性

- 正文建议 14–18pt，不低于 12pt；辅助文字不低于 10pt。
- 主标题建议 28–42pt，章节标题建议 20–30pt。
- 一张幻灯片建议 2–4 个主要内容块，利用宽度组织信息，不用缩小字号堆满页面。
- 可使用静态页码、章节名和候选人姓名作为重复上下文。

## 禁止项与验收

- 不得使用动画、转场、自动播放、平滑滚动或逐步出现效果。
- 不得用 `overflow:hidden` 掩盖超出页面的正文。
- 不得把全部幻灯片绝对定位到同一位置。
- `.resume-slide` 数量必须与分页预览一致；逐页检查宽高比为 16:9，且 `scrollHeight <= clientHeight + 1`。
