# HTML 简历设计 Agent

该项目把简历生成拆成四个可独立组合的维度：

```text
简历原文 × 简历版式 × 视觉风格 × 输出规格 = HTML 简历
```

面向用户时不称为“模板”，而是三个独立选择：

| 选择项 | 决定什么 | 示例 |
|---|---|---|
| 视觉风格 | 色彩、字体、边框、留白和强调方式 | 温暖编辑、极简数据、黑白秩序 |
| 简历版式 | 章节顺序、信息占比和单/双栏结构 | 时间顺序、项目优先、高管成果 |
| 输出规格 | 连续网页、纸张或幻灯片分页及其验收方式 | 网页浏览、A4、4:3 演示分页、16:9 演示分页 |

## 目录

```text
resume-html-agent/
├── SKILL.md                  # Codex 能力入口与资源路由
├── AGENT.md                  # 完整运行机制与输出协议
├── agent.config.yaml         # 默认设置与资源索引
├── agents/openai.yaml        # UI 展示和默认调用提示
├── config/input.schema.json  # 商业化 API 输入结构
├── styles/                   # 可选视觉风格，不控制内容顺序
├── layouts/                  # 可选简历版式，不控制配色
├── formats/                  # 连续网页与分页打印等输出规格
├── previews/                 # 基准简历、预览生成器与独立预览输出
├── references/               # 事实、语言与验收规范
└── scripts/                  # 确定性校验工具
```

## 应用选项目录

用户端显示信息分别位于：

- `styles/catalog.md`：视觉风格
- `layouts/catalog.md`：简历版式
- `formats/catalog.md`：输出规格

每个目录都包含一段由 `<!-- app-options:start -->` 和 `<!-- app-options:end -->` 包围的合法 JSON。应用读取 `options` 数组即可获得统一字段：

```json
{
  "id": "稳定选项 ID",
  "name": "选项名称",
  "intro": "名称下方的简短介绍",
  "description": "选中后展示在预览区域的详细说明"
}
```

应用端应以目录 JSON 为显示文案的唯一来源；同名规范文件负责 Agent 的生成规则。

## 应用预览文件

预览资产与真实简历输出分开保存在 `previews/`：

- `previews/source/benchmark-resume-zh.md`：所有主预览共用的虚拟基准简历。
- `previews/generate-visual-style-previews-v2.mjs`：当前视觉风格预览生成器。共用的只有基准简历、事实分区与 A4 约束，8 种风格分别使用独立的页面结构和视觉组件。
- `previews/generate-layout-previews-v2.mjs`：当前简历版式预览生成器。固定基准简历、中性编辑视觉和 A4 规格，只改变章节顺序、信息比例、网格和分页预算。
- `previews/generate-format-previews-v2.mjs`：当前输出规格预览生成器。固定基准简历、标准经历版式和中性编辑风格，分别生成连续网页、A4、4:3 和 16:9 静态分页。
- `previews/generate-previews.mjs`：旧版批量组合草案，仅作历史参考，不用于当前视觉风格截图。
- `previews/output/index.html`：预览入口页。
- `previews/output/visual-styles/`：8 个视觉风格预览。
- `previews/output/layouts/`：6 个简历版式预览。
- `previews/output/formats/`：4 个输出规格预览。

预览文件统一使用 `类型-选项名称-预览简历.html` 命名，选项名称取自对应目录 JSON，并移除其中的空格。例如：`视觉风格-温暖编辑-预览简历.html`、`简历版式-标准经历-预览简历.html`、`输出规格-4:3演示分页-预览简历.html`。

本轮重新生成 8 个视觉风格时运行：

```bash
node previews/generate-visual-style-previews-v2.mjs
```

重新生成 6 个简历版式时运行：

```bash
node previews/generate-layout-previews-v2.mjs
```

重新生成 4 个输出规格时运行：

```bash
node previews/generate-format-previews-v2.mjs
```

预览生成后必须继续执行事实完整性、字号、动画禁用、A4 页数和渲染溢出检查；生成器运行成功不代表预览已通过验收。

## 最小调用

```yaml
resume_source: "...原始简历..."
visual_style:
  type: profile
  id_or_content: design_hellotime
layout:
  type: profile
  id: executive-impact
output_spec:
  id: screen-continuous
density:
  id: standard
target_pages: null
```

生成后执行：

```bash
python3 scripts/validate_resume_html.py output.html \
  --source resume.md \
  --format screen-continuous
```

静态脚本会按输出规格切换规则：连续网页检查响应式容器，A4 检查纸张页，PPT 规格检查幻灯片容器、比例标识和分页。所有规格还会检查并禁止动画。实际布局、颜色继承和分页预览仍需按照 `references/validation-checklist.md` 进行渲染检查。

## 三种条件自由组合

```text
visual_style × layout × output_spec
```

例如：

```yaml
visual_style:
  type: profile
  id_or_content: design_hellotime
layout:
  type: profile
  id: project-led
output_spec:
  id: print-a4
density:
  id: standard
```

或者：

```yaml
visual_style:
  type: profile
  id_or_content: design_officevibe
layout:
  type: profile
  id: executive-impact
output_spec:
  id: screen-continuous
density:
  id: complete
```

PPT 风格分页仍输出 HTML，例如：

```yaml
visual_style:
  type: profile
  id_or_content: design_caldera
layout:
  type: profile
  id: project-led
output_spec:
  id: slides-16x9
density:
  id: standard
target_pages: auto
```

四种输出规格都只生成静态页面，不使用动画、转场或自动播放。
