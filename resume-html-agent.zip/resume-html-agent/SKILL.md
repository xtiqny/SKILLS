---
name: resume-html-agent
description: Generate a faithful, self-contained HTML resume from raw resume text by independently combining a visual style, resume layout, and output format such as responsive web, paginated A4, or static 4:3 and 16:9 presentation pages. Use for resume-to-HTML work requiring source fidelity, accessibility, restrained non-AI-sounding copy, responsive validation, or fixed-page validation. Do not use for resume scoring, job matching, or inventing candidate claims.
---

# HTML Resume Agent

Generate a complete HTML resume from raw Markdown or plain text. Treat the source resume as the only source of facts.

## Required inputs

- Raw resume text.
- A visual style profile from `styles/`, or an equivalent user-provided `design.md`.
- A layout profile from `layouts/`; recommend one when the user has not chosen.
- An output format from `formats/`. Default to `print-a4`, `density: standard`, and automatic page count.

## Workflow

1. Read `AGENT.md` for the runtime contract.
2. Build an internal fact ledger before editing. For high-risk fidelity rules, read `references/content-fidelity.md`.
3. Select one layout profile, one visual style profile, and one output format. Keep all three independent.
4. Read `references/anti-ai-writing.md` before writing headings or summaries.
5. Generate one self-contained HTML document using system fonts and inline CSS. Core content must work without JavaScript or network access.
6. Apply the selected format from `formats/`. Use normal responsive flow for `screen-continuous`, A4 page containers for `print-a4`, or fixed-ratio slide containers for the presentation formats.
7. Read `references/combination-contract.md` and `references/validation-checklist.md`, run `scripts/validate_resume_html.py --format <format-id>`, and fix all errors before delivery.

## Non-negotiable constraints

- Do not invent, upgrade, score, or infer candidate facts.
- Preserve names, contact details, employers, titles, dates, locations, degrees, project names, responsibility verbs, numbers, currency, and percentages.
- Do not hide overflow. In paginated output, do not shrink body text below 9pt to meet a page target; add pages instead.
- Normal text contrast must be at least 4.5:1; large text must be at least 3:1.
- Explicitly set text colors on nested light and dark surfaces; do not rely on inherited inverse colors.
- In paginated output, multiple pages must remain in normal flow. In continuous output, do not emit fixed A4 heights or forced page breaks.
- All formats are static. Do not add CSS animation, transitions, smooth scrolling, animated SVG, auto-rotation, or JavaScript-driven motion.
- Output only the finished HTML when the calling workflow requests final-only output.

## Resource routing

- Content truth and allowed editing: `references/content-fidelity.md`
- Human, restrained resume language: `references/anti-ai-writing.md`
- Final QA and failure conditions: `references/validation-checklist.md`
- Combination precedence and compatibility: `references/combination-contract.md`
- Output choices: `formats/catalog.md`
- Continuous web rules: `formats/screen-continuous.md`
- A4 print rules: `formats/print-a4.md`
- 4:3 presentation rules: `formats/slides-4x3.md`
- 16:9 presentation rules: `formats/slides-16x9.md`
- Style choices: `styles/catalog.md`
- Layout choices: `layouts/catalog.md`
