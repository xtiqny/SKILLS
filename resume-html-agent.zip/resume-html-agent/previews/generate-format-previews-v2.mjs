#!/usr/bin/env node

import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const sourcePath = path.join(here, "source", "benchmark-resume-zh.md");
const outputRoot = path.join(here, "output");
const formatOutput = path.join(outputRoot, "formats");
const source = fs.readFileSync(sourcePath, "utf8").replace(/\r\n/g, "\n");

function previewFileName(type, optionName) {
  return `${type}-${optionName.replace(/\s+/g, "")}-预览简历.html`;
}

function esc(value) {
  return value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");
}

function inline(value) {
  return esc(value).replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>").replace(/`(.+?)`/g, "<code>$1</code>");
}

function markdown(markdownSource) {
  const out = [];
  let listOpen = false;
  let paragraph = [];
  const closeList = () => { if (listOpen) { out.push("</ul>"); listOpen = false; } };
  const closeParagraph = () => { if (paragraph.length) { out.push(`<p>${paragraph.join("")}</p>`); paragraph = []; } };
  const flush = () => { closeParagraph(); closeList(); };
  for (const original of markdownSource.trim().split("\n")) {
    const hardBreak = /\s{2,}$/.test(original);
    const line = original.trim();
    if (!line) { flush(); continue; }
    if (line === "---") { flush(); continue; }
    const heading = line.match(/^(#{1,3})\s+(.+)$/);
    if (heading) { flush(); out.push(`<h${heading[1].length}>${inline(heading[2])}</h${heading[1].length}>`); continue; }
    if (line.startsWith(">")) { flush(); out.push(`<p class="source-note">${inline(line.replace(/^>\s?/, ""))}</p>`); continue; }
    const bullet = line.match(/^[-*]\s+(.+)$/);
    if (bullet) {
      closeParagraph();
      if (!listOpen) { out.push("<ul>"); listOpen = true; }
      out.push(`<li>${inline(bullet[1])}</li>`);
      continue;
    }
    closeList();
    paragraph.push(`${inline(line)}${hardBreak ? "<br>" : " "}`);
  }
  flush();
  return out.join("\n");
}

function parseResume(raw) {
  const matches = [...raw.matchAll(/^##\s+(.+)$/gm)];
  const header = raw.slice(0, matches[0].index).trim();
  const sections = new Map();
  matches.forEach((match, index) => {
    const start = match.index + match[0].length;
    const end = index + 1 < matches.length ? matches[index + 1].index : raw.length;
    sections.set(match[1].trim(), raw.slice(start, end).trim());
  });
  return { header, sections };
}

const splitH3 = (raw) => raw.split(/(?=^###\s+)/m).map((part) => part.trim()).filter(Boolean);
const bullets = (raw) => [...raw.matchAll(/^[-*]\s+(.+)$/gm)].map((match) => match[1]);

function groupedCapabilities(raw) {
  const groups = [];
  let current = null;
  for (const line of raw.split("\n")) {
    const title = line.trim().match(/^\*\*(.+?)\*\*$/);
    if (title) { current = { title: title[1], items: [] }; groups.push(current); continue; }
    const bullet = line.trim().match(/^[-*]\s+(.+)$/);
    if (bullet && current) current.items.push(bullet[1]);
  }
  return groups;
}

const parsed = parseResume(source);
const sections = parsed.sections;
const work = splitH3(sections.get("工作经历"));
const projects = splitH3(sections.get("代表项目"));
const capabilities = groupedCapabilities(sections.get("核心能力"));
const keyResults = bullets(sections.get("关键成果"));
const [personName, roleName] = source.match(/^#\s+(.+)$/m)[1].split("｜");
const headerLines = parsed.header.split("\n")
  .map((line) => line.trim())
  .filter((line) => line && !line.startsWith("#") && !line.startsWith(">") && line !== "---")
  .map((line) => line.replace(/\\@/g, "@").replace(/\\$/, ""));
const sourceNote = [...parsed.header.matchAll(/^>\s?(.*)$/gm)].map((m) => m[1].replace(/\\$/, "")).join(" ");

const sectionHtml = (name) => markdown(sections.get(name));
const workHtml = (index) => markdown(work[index]);
const projectHtml = (index) => markdown(projects[index]);
const contactHtml = (className = "contact-list") => `<div class="${className}">${headerLines.map((line) => `<span>${inline(line)}</span>`).join("")}</div>`;
const noticeHtml = (className = "source-notice") => sourceNote ? `<p class="${className}">${inline(sourceNote)}</p>` : "";

function capabilityHtml(className = "capability-grid") {
  return `<div class="${className}">${capabilities.map((group, index) => `<section><span class="sequence">0${index + 1}</span><h3>${inline(group.title)}</h3><ul>${group.items.map((item) => `<li>${inline(item)}</li>`).join("")}</ul></section>`).join("")}</div>`;
}

function resultsHtml(className = "results-grid") {
  return `<div class="${className}">${keyResults.map((item, index) => `<div class="result-item"><span>0${index + 1}</span><p>${inline(item)}</p></div>`).join("")}</div>`;
}

function workHtmlList(indexes = work.map((_, index) => index), className = "experience-list") {
  return `<div class="${className}">${indexes.map((index) => `<section class="resume-item">${workHtml(index)}</section>`).join("")}</div>`;
}

function projectHtmlList(indexes = projects.map((_, index) => index), className = "project-list") {
  return `<div class="${className}">${indexes.map((index) => `<article class="project-item">${projectHtml(index)}</article>`).join("")}</div>`;
}

const staticReset = `
  * { box-sizing:border-box; }
  *, *::before, *::after { animation:none !important; transition:none !important; }
  html { scroll-behavior:auto; }
`;

const visualTokens = `
  :root { --ink:#171a20; --muted:#555d66; --accent:#264f78; --line:#aeb5bc; --soft:#edf0f2; --paper:#fff; }
`;

function screenContinuous() {
  const css = `
    ${staticReset}${visualTokens}
    body { margin:0; min-width:0; background:#e7eaed; color:var(--ink); font:16px/1.58 -apple-system,BlinkMacSystemFont,"Segoe UI","Noto Sans CJK SC",sans-serif; }
    .resume-document { width:min(calc(100% - 40px),1020px); min-width:0; margin:34px auto; padding:54px 60px 64px; background:var(--paper); box-shadow:0 10px 30px rgba(28,37,46,.12); overflow-wrap:anywhere; }
    .resume-document * { min-width:0; }
    .web-hero { display:grid; grid-template-columns:1.35fr .65fr; gap:56px; padding-bottom:28px; border-bottom:1px solid var(--ink); }
    .eyebrow,.sequence { margin:0 0 8px; color:var(--accent); font-size:12px; font-weight:700; letter-spacing:.12em; text-transform:uppercase; }
    h1 { margin:0; font:700 48px/1.02 Georgia,"Songti SC",serif; letter-spacing:-.04em; }
    .role { margin:10px 0 0; font-size:21px; font-weight:600; }
    .contact-list span { display:block; margin-bottom:5px; color:#343a41; font-size:13px; }
    .source-notice { margin:20px 0 34px; padding:12px 0; border-top:1px solid var(--line); border-bottom:1px solid var(--line); color:#424950; font-size:13px; }
    .web-intro { display:grid; grid-template-columns:.72fr 1.28fr; gap:44px; margin-bottom:38px; }
    .section-title { margin:0 0 18px; font:700 27px/1.1 Georgia,"Songti SC",serif; letter-spacing:-.02em; }
    .section-body p { margin:0 0 12px; }
    .capability-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:28px; margin-bottom:42px; }
    .capability-grid section { padding-top:15px; border-top:1px solid var(--ink); }
    .capability-grid h3 { margin:0 0 10px; font-size:17px; }
    ul { margin:10px 0 0; padding-left:20px; }
    li { margin-bottom:6px; }
    .results-grid { display:grid; grid-template-columns:1fr 1fr; margin-bottom:46px; border-top:1px solid var(--ink); }
    .result-item { display:grid; grid-template-columns:32px 1fr; gap:8px; padding:13px 16px 13px 0; border-bottom:1px solid var(--line); }
    .result-item:nth-child(odd) { border-right:1px solid var(--line); }
    .result-item:nth-child(even) { padding-left:16px; }
    .result-item span { color:var(--accent); font-size:12px; font-weight:700; }
    .result-item p { margin:0; }
    .content-section { margin-top:44px; }
    .resume-item,.project-item { padding:22px 0; border-top:1px solid var(--line); }
    .resume-item:first-child,.project-item:first-child { border-top:1px solid var(--ink); }
    .resume-item h3,.project-item h3,.section-body h3 { margin:0 0 7px; font-size:19px; }
    .resume-item p,.project-item p { margin:0 0 10px; }
    .web-two-column { display:grid; grid-template-columns:1fr 1fr; gap:42px; }
    .web-background { display:grid; grid-template-columns:1fr 1fr; gap:26px 42px; }
    .web-background section { padding-top:16px; border-top:1px solid var(--line); }
    .web-background .wide { grid-column:1/-1; }
    .web-background h2 { margin:0 0 12px; font:700 20px/1.15 Georgia,"Songti SC",serif; }
    @media (max-width:720px) {
      .resume-document { width:min(calc(100% - 24px),1020px); margin:12px auto; padding:30px 22px 42px; }
      .web-hero,.web-intro,.capability-grid,.results-grid,.web-two-column,.web-background { grid-template-columns:1fr; }
      .web-hero { gap:24px; }
      h1 { font-size:39px; }
      .result-item:nth-child(odd) { border-right:0; }
      .result-item:nth-child(even) { padding-left:0; }
      .web-background .wide { grid-column:auto; }
    }
  `;
  return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>输出规格-网页浏览-预览简历</title><style>${css}</style></head><body><main class="resume-document"><header class="web-hero"><div><p class="eyebrow">CAREER PROFILE</p><h1>${personName}</h1><p class="role">${roleName}</p></div>${contactHtml()}</header>${noticeHtml()}<section class="web-intro"><h2 class="section-title">个人简介</h2><div class="section-body">${sectionHtml("个人简介")}</div></section><section><h2 class="section-title">核心能力</h2>${capabilityHtml()}</section><section><h2 class="section-title">关键成果</h2>${resultsHtml()}</section><section class="content-section"><h2 class="section-title">工作经历</h2>${workHtmlList()}</section><section class="content-section"><h2 class="section-title">代表项目</h2><div class="web-two-column">${projectHtmlList([0])}${projectHtmlList([1])}</div></section><section class="content-section"><h2 class="section-title">管理与组织经验</h2><div class="section-body">${sectionHtml("管理与组织经验")}</div></section><section class="content-section web-background"><section><h2>教育与研究</h2>${sectionHtml("教育与研究")}</section><section><h2>研究与专业活动</h2>${sectionHtml("研究与专业活动")}</section><section class="wide"><h2>专业技能</h2>${sectionHtml("专业技能")}</section><section class="wide"><h2>荣誉与认证</h2>${sectionHtml("荣誉与认证")}</section></section></main></body></html>`;
}

function printA4() {
  const css = `
    ${staticReset}${visualTokens}
    html,body { margin:0; background:#d9dde2; }
    body { color:var(--ink); font:9.2pt/1.48 -apple-system,BlinkMacSystemFont,"Segoe UI","Noto Sans CJK SC",sans-serif; }
    @page { size:A4 portrait; margin:0; }
    .resume-book { width:210mm; margin:16px auto; }
    .resume-page { position:relative; width:210mm; height:297mm; margin:0 0 16px; padding:13mm 16mm 15mm; background:#fff; box-shadow:0 8px 22px rgba(31,40,49,.12); }
    .resume-page + .resume-page { break-before:page; page-break-before:always; }
    .resume-item,.project-item { break-inside:avoid; page-break-inside:avoid; }
    .a4-hero { display:grid; grid-template-columns:1.35fr .65fr; gap:10mm; margin-bottom:5mm; padding-bottom:5mm; border-bottom:1px solid var(--ink); }
    .eyebrow,.sequence { margin:0 0 2mm; color:var(--accent); font-size:7pt; font-weight:700; letter-spacing:.12em; text-transform:uppercase; }
    .a4-hero h1 { margin:0; font:700 27pt/1 Georgia,"Songti SC",serif; letter-spacing:-.035em; }
    .role { margin:2mm 0 0; font-size:12.5pt; font-weight:600; }
    .contact-list span { display:block; margin-bottom:1.2mm; color:#343a41; font-size:7.4pt; }
    .source-notice { margin:0 0 5mm; padding:2.5mm 0; border-top:1px solid var(--line); border-bottom:1px solid var(--line); color:#444b53; font-size:7.2pt; }
    .section-title { margin:0 0 3mm; font:700 16pt/1.1 Georgia,"Songti SC",serif; }
    .a4-intro { display:grid; grid-template-columns:.75fr 1.25fr; gap:8mm; margin-bottom:5mm; }
    p { margin:0 0 2mm; } ul { margin:2mm 0 0; padding-left:5mm; } li { margin-bottom:.9mm; }
    .capability-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:6mm; margin-bottom:5mm; }
    .capability-grid section { padding-top:3mm; border-top:1px solid var(--ink); }
    .capability-grid h3 { margin:0 0 2mm; font-size:10.4pt; }
    .capability-grid ul { margin:0; font-size:9pt; }
    .results-grid { display:grid; grid-template-columns:1fr 1fr; border-top:1px solid var(--ink); }
    .result-item { display:grid; grid-template-columns:8mm 1fr; gap:3mm; padding:2.2mm 0; border-bottom:1px solid var(--line); }
    .result-item:nth-child(odd) { border-right:1px solid var(--line); padding-right:3mm; }
    .result-item:nth-child(even) { padding-left:3mm; }
    .result-item span { color:var(--accent); font-size:7pt; font-weight:700; }
    .result-item p { margin:0; }
    .page-heading { display:flex; justify-content:space-between; align-items:end; margin-bottom:5mm; padding-bottom:3mm; border-bottom:1px solid var(--ink); }
    .page-heading h1 { margin:0; font:700 20pt/1 Georgia,"Songti SC",serif; }
    .page-heading span { color:var(--muted); font-size:7pt; }
    .resume-item,.project-item { padding:3.5mm 0; border-top:1px solid var(--line); }
    .resume-item:first-child,.project-item:first-child { border-top:1px solid var(--ink); }
    .resume-item h3,.project-item h3 { margin:0 0 1mm; font-size:11.8pt; }
    .a4-projects,.a4-background { display:grid; grid-template-columns:1fr 1fr; gap:7mm; }
    .a4-background { gap:5mm 7mm; margin-top:5mm; }
    .a4-background section { padding-top:3mm; border-top:1px solid var(--line); }
    .a4-background .wide { grid-column:1/-1; }
    .a4-background h2 { margin:0 0 2mm; font:700 12.5pt/1.1 Georgia,"Songti SC",serif; }
    .page-footer { position:absolute; left:16mm; right:16mm; bottom:5mm; display:flex; justify-content:space-between; padding-top:2mm; border-top:1px solid var(--line); color:#4f565e; font-size:7pt; }
    @media print { html,body{background:#fff}.resume-book{width:auto;margin:0}.resume-page{display:block;float:none;width:210mm;height:297mm;margin:0;box-shadow:none;-webkit-print-color-adjust:exact;print-color-adjust:exact} }
  `;
  const pages = [
    `<header class="a4-hero"><div><p class="eyebrow">CAREER PROFILE</p><h1>${personName}</h1><p class="role">${roleName}</p></div>${contactHtml()}</header>${noticeHtml()}<section class="a4-intro"><h2 class="section-title">个人简介</h2><div>${sectionHtml("个人简介")}</div></section><h2 class="section-title">核心能力</h2>${capabilityHtml()}<h2 class="section-title">关键成果</h2>${resultsHtml()}`,
    `<header class="page-heading"><h1>工作经历</h1><span>EXPERIENCE</span></header>${workHtmlList()}`,
    `<header class="page-heading"><h1>项目与专业背景</h1><span>PROJECTS & BACKGROUND</span></header><div class="a4-projects">${projectHtmlList([0])}${projectHtmlList([1])}</div><section><h2 class="section-title">管理与组织经验</h2>${sectionHtml("管理与组织经验")}</section><div class="a4-background"><section><h2>教育与研究</h2>${sectionHtml("教育与研究")}</section><section><h2>研究与专业活动</h2>${sectionHtml("研究与专业活动")}</section><section class="wide"><h2>专业技能</h2>${sectionHtml("专业技能")}</section><section class="wide"><h2>荣誉与认证</h2>${sectionHtml("荣誉与认证")}</section></div>`,
  ];
  return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>输出规格-A4打印-预览简历</title><style>${css}</style></head><body><main class="resume-book">${pages.map((content,index)=>`<article class="resume-page">${content}<footer class="page-footer"><span>${personName} · ${roleName}</span><span>0${index+1} / 03</span></footer></article>`).join("")}</main></body></html>`;
}

function slideDocument(format, slides) {
  const isWide = format === "slides-16x9";
  const width = isWide ? "13.333in" : "10in";
  const title = isWide ? "16:9 演示分页" : "4:3 演示分页";
  const css = `
    ${staticReset}${visualTokens}
    html,body { margin:0; background:#d9dde2; }
    body { color:var(--ink); font:12.5pt/1.42 -apple-system,BlinkMacSystemFont,"Segoe UI","Noto Sans CJK SC",sans-serif; }
    @page { size:${width} 7.5in; margin:0; }
    .resume-deck { width:${width}; margin:16px auto; }
    .resume-slide { position:relative; width:${width}; height:7.5in; margin:0 0 16px; padding:.5in ${isWide ? ".68in" : ".58in"} .55in; background:#fff; box-shadow:0 8px 22px rgba(31,40,49,.12); }
    .resume-slide + .resume-slide { break-before:page; page-break-before:always; }
    .slide-head { display:flex; justify-content:space-between; align-items:end; margin-bottom:.25in; padding-bottom:.13in; border-bottom:1px solid var(--ink); }
    .slide-head h1 { margin:0; font:700 ${isWide ? "26pt" : "24pt"}/1 Georgia,"Songti SC",serif; }
    .slide-head span,.sequence { color:var(--accent); font-size:12pt; font-weight:700; letter-spacing:.1em; text-transform:uppercase; }
    .slide-footer { position:absolute; left:${isWide ? ".68in" : ".58in"}; right:${isWide ? ".68in" : ".58in"}; bottom:.2in; display:flex; justify-content:space-between; padding-top:.09in; border-top:1px solid var(--line); color:#4f565e; font-size:12pt; }
    .cover { display:grid; grid-template-columns:${isWide ? "1.45fr .55fr" : "1.18fr .82fr"}; gap:.5in; align-items:center; height:5.9in; }
    .cover h1 { margin:0; font:700 ${isWide ? "42pt" : "37pt"}/1 Georgia,"Songti SC",serif; letter-spacing:-.035em; }
    .cover .role { margin:.14in 0 .28in; font-size:${isWide ? "21pt" : "19pt"}; font-weight:600; }
    .cover .profile p { margin:0 0 .11in; }
    .contact-list { padding-top:.16in; border-top:1px solid var(--ink); }
    .contact-list span { display:block; margin-bottom:.07in; font-size:12pt; }
    .source-notice { margin-top:.16in; padding-top:.12in; border-top:1px solid var(--line); color:#40474e; font-size:12pt; }
    .capability-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:.28in; }
    .capability-grid section { padding-top:.12in; border-top:1px solid var(--ink); }
    .capability-grid h3 { margin:.05in 0 .1in; font-size:15pt; }
    .capability-grid ul { margin:0; padding-left:.19in; }
    .capability-grid li { margin-bottom:.05in; }
    .results-grid { display:grid; grid-template-columns:1fr 1fr; margin-top:.27in; border-top:1px solid var(--ink); }
    .result-item { display:grid; grid-template-columns:.28in 1fr; gap:.08in; padding:.12in .15in .12in 0; border-bottom:1px solid var(--line); }
    .result-item:nth-child(odd) { border-right:1px solid var(--line); }
    .result-item:nth-child(even) { padding-left:.15in; }
    .result-item span { color:var(--accent); font-size:12pt; font-weight:700; }
    .result-item p { margin:0; }
    .slide-body h3 { margin:0 0 .07in; font-size:${isWide ? "18pt" : "17pt"}; }
    .slide-body p { margin:0 0 .1in; }
    .slide-body ul { margin:.1in 0 0; padding-left:.22in; }
    .slide-body li { margin-bottom:.06in; }
    .slide-columns { display:grid; grid-template-columns:1fr 1fr; gap:.35in; }
    .slide-columns > section,.slide-columns > div { min-width:0; }
    .subsection { padding-top:.12in; border-top:1px solid var(--line); }
    .subsection h2 { margin:0 0 .1in; font:700 ${isWide ? "18pt" : "17pt"}/1.1 Georgia,"Songti SC",serif; }
    .skills p { margin-bottom:.08in; }
    @media print { html,body{background:#fff}.resume-deck{width:auto;margin:0}.resume-slide{display:block;width:${width};height:7.5in;margin:0;box-shadow:none;-webkit-print-color-adjust:exact;print-color-adjust:exact} }
  `;
  return `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>输出规格-${title.replace(/\s+/g, "")}-预览简历</title><style>${css}</style></head><body><main class="resume-deck" data-output-format="${format}">${slides.map((slide,index)=>`<article class="resume-slide">${slide}<footer class="slide-footer"><span>${personName} · ${roleName}</span><span>${String(index+1).padStart(2,"0")} / ${String(slides.length).padStart(2,"0")}</span></footer></article>`).join("")}</main></body></html>`;
}

function slideHead(title, label) {
  return `<header class="slide-head"><h1>${title}</h1><span>${label}</span></header>`;
}

function slides4x3() {
  const slides = [
    `<section class="cover"><div><p class="sequence">CAREER PROFILE</p><h1>${personName}</h1><p class="role">${roleName}</p><div class="profile">${sectionHtml("个人简介")}</div></div><aside>${contactHtml()}${noticeHtml()}</aside></section>`,
    `${slideHead("核心能力与关键成果", "CAPABILITY & IMPACT")}<div class="slide-body">${capabilityHtml()}${resultsHtml()}</div>`,
    `${slideHead("工作经历｜澄序智能科技", "EXPERIENCE / 01")}<div class="slide-body">${workHtml(0)}</div>`,
    `${slideHead("工作经历｜森屿云计算", "EXPERIENCE / 02")}<div class="slide-body">${workHtml(1)}</div>`,
    `${slideHead("工作经历｜明川数字科技", "EXPERIENCE / 03")}<div class="slide-body">${workHtml(2)}</div>`,
    `${slideHead("Atlas 企业智能体平台", "PROJECT / 01")}<div class="slide-body">${projectHtml(0)}</div>`,
    `${slideHead("项目与管理经验", "PROJECT / 02")}<div class="slide-columns slide-body"><section>${projectHtml(1)}</section><section class="subsection"><h2>管理与组织经验</h2>${sectionHtml("管理与组织经验")}</section></div>`,
    `${slideHead("教育、研究与专业活动", "BACKGROUND / 01")}<div class="slide-columns slide-body"><section class="subsection"><h2>教育与研究</h2>${sectionHtml("教育与研究")}</section><section class="subsection"><h2>研究与专业活动</h2>${sectionHtml("研究与专业活动")}</section></div>`,
    `${slideHead("专业技能与荣誉认证", "BACKGROUND / 02")}<div class="slide-columns slide-body"><section class="subsection skills"><h2>专业技能</h2>${sectionHtml("专业技能")}</section><section class="subsection"><h2>荣誉与认证</h2>${sectionHtml("荣誉与认证")}</section></div>`,
  ];
  return slideDocument("slides-4x3", slides);
}

function slides16x9() {
  const slides = [
    `<section class="cover"><div><p class="sequence">CAREER PROFILE</p><h1>${personName}</h1><p class="role">${roleName}</p><div class="profile">${sectionHtml("个人简介")}</div></div><aside>${contactHtml()}${noticeHtml()}</aside></section>`,
    `${slideHead("核心能力与关键成果", "CAPABILITY & IMPACT")}<div class="slide-body">${capabilityHtml()}${resultsHtml()}</div>`,
    `${slideHead("工作经历｜澄序智能科技", "EXPERIENCE / CURRENT")}<div class="slide-body">${workHtml(0)}</div>`,
    `${slideHead("历史工作经历", "EXPERIENCE / HISTORY")}<div class="slide-columns slide-body"><section>${workHtml(1)}</section><section>${workHtml(2)}</section></div>`,
    `${slideHead("Atlas 企业智能体平台", "PROJECT / 01")}<div class="slide-body">${projectHtml(0)}</div>`,
    `${slideHead("项目与管理经验", "PROJECT / 02")}<div class="slide-columns slide-body"><section>${projectHtml(1)}</section><section class="subsection"><h2>管理与组织经验</h2>${sectionHtml("管理与组织经验")}</section></div>`,
    `${slideHead("教育、研究与专业活动", "BACKGROUND / 01")}<div class="slide-columns slide-body"><section class="subsection"><h2>教育与研究</h2>${sectionHtml("教育与研究")}</section><section class="subsection"><h2>研究与专业活动</h2>${sectionHtml("研究与专业活动")}</section></div>`,
    `${slideHead("专业技能与荣誉认证", "BACKGROUND / 02")}<div class="slide-columns slide-body"><section class="subsection skills"><h2>专业技能</h2>${sectionHtml("专业技能")}</section><section class="subsection"><h2>荣誉与认证</h2>${sectionHtml("荣誉与认证")}</section></div>`,
  ];
  return slideDocument("slides-16x9", slides);
}

const outputs = [
  ["screen-continuous", "网页浏览", screenContinuous],
  ["print-a4", "A4 打印", printA4],
  ["slides-4x3", "4:3 演示分页", slides4x3],
  ["slides-16x9", "16:9 演示分页", slides16x9],
];

fs.mkdirSync(formatOutput, { recursive:true });
for (const [, name, render] of outputs) fs.writeFileSync(path.join(formatOutput, previewFileName("输出规格", name)), render(), "utf8");

const visualEntries = [
  ["design_officevibe", "温暖编辑", "4 页 A4"], ["design_hellotime", "极简数据", "4 页 A4"], ["design_uber", "黑白秩序", "4 页 A4"], ["design_perplexity", "研究手记", "4 页 A4"],
  ["design_intercom", "锐利编辑", "4 页 A4"], ["design_pirsch_analytics", "纸感高亮", "4 页 A4"], ["design_ditto", "创意批注", "4 页 A4"], ["design_caldera", "工业海报", "4 页 A4"],
];
const layoutEntries = [
  ["standard-chronological", "标准经历", "3 页 A4"], ["executive-impact", "管理成果", "4 页 A4"], ["project-led", "项目案例", "4 页 A4"],
  ["technical-skills", "技术能力", "4 页 A4"], ["compact-two-column", "紧凑双栏", "2 页 A4"], ["academic-research", "学术研究", "4 页 A4"],
];
const formatEntries = [
  ["screen-continuous", "网页浏览", "连续响应式"], ["print-a4", "A4 打印", "3 页 A4"], ["slides-4x3", "4:3 演示分页", "9 张静态页"], ["slides-16x9", "16:9 演示分页", "8 张静态页"],
];

const previewTypeByFolder = { "visual-styles": "视觉风格", layouts: "简历版式", formats: "输出规格" };
const cards = (folder, entries) => entries.map(([id,name,meta]) => `<a href="${folder}/${previewFileName(previewTypeByFolder[folder], name)}"><strong>${name}</strong><span>${id} · ${meta}</span></a>`).join("");
const indexHtml = `<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>简历预览资产 · 第二版</title><style>
*{box-sizing:border-box}*,*::before,*::after{animation:none!important;transition:none!important}html{scroll-behavior:auto}body{margin:0;background:#f1f3f6;color:#13213a;font-family:Inter,system-ui,sans-serif}main{width:min(calc(100% - 40px),1080px);margin:36px auto 72px}header{padding:28px;background:#fff;border:1px solid #d8dee8;border-radius:14px}h1{margin:0 0 8px;font-size:28px}h2{margin:30px 0 8px;font-size:20px}p{margin:0;color:#58677b;line-height:1.6}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;margin-top:16px}a{display:block;padding:20px;background:#fff;border:1px solid #d8dee8;border-radius:12px;color:#13213a;text-decoration:none}a strong{display:block;margin-bottom:6px;font-size:18px}a span{color:#66758a;font-size:13px}.note{margin-top:6px;font-size:13px}@media(max-width:720px){main{width:min(calc(100% - 24px),1080px);margin-top:12px}.grid{grid-template-columns:1fr}}
</style></head><body><main><header><h1>简历预览资产 · 第二版</h1><p>三组预览共用同一份虚拟基准简历，通过控制变量分别展示视觉风格、简历版式与输出规格。</p></header><h2>视觉风格</h2><p class="note">固定标准经历版式和 A4 输出。</p><div class="grid">${cards("visual-styles",visualEntries)}</div><h2>简历版式</h2><p class="note">固定中性编辑风格和 A4 输出。</p><div class="grid">${cards("layouts",layoutEntries)}</div><h2>输出规格</h2><p class="note">固定标准经历版式和中性编辑风格，分别按网页、A4、4:3 与 16:9 重新组织。全部为静态 HTML。</p><div class="grid">${cards("formats",formatEntries)}</div></main></body></html>`;
if (process.argv.includes("--with-index")) fs.writeFileSync(path.join(outputRoot, "index.html"), indexHtml, "utf8");

console.log("Generated 4 output-format previews with medium-specific composition.");
