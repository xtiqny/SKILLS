#!/usr/bin/env node

import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const sourcePath = path.join(here, "source", "benchmark-resume-zh.md");
const outputRoot = path.join(here, "output");
const styleOutput = path.join(outputRoot, "visual-styles");
const source = fs.readFileSync(sourcePath, "utf8").replace(/\r\n/g, "\n");

function previewFileName(type, optionName) {
  return `${type}-${optionName.replace(/\s+/g, "")}-预览简历.html`;
}

function esc(value) {
  return value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");
}

function inline(value) {
  return esc(value).replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>").replace(/`(.+?)`/g, "<code>$1</code>");
}

function markdown(markdownSource) {
  const out = [];
  let listOpen = false;
  let paragraph = [];
  const closeList = () => { if (listOpen) { out.push("</ul>"); listOpen = false; } };
  const closeParagraph = () => { if (paragraph.length) { out.push(`<p>${paragraph.join("")}</p>`); paragraph = []; } };
  const flush = () => { closeParagraph(); closeList(); };
  for (const original of markdownSource.trim().split("\n")) {
    const hardBreak = /\s{2,}$/.test(original);
    const line = original.trim();
    if (!line) { flush(); continue; }
    if (line === "---") { flush(); continue; }
    const heading = line.match(/^(#{1,3})\s+(.+)$/);
    if (heading) { flush(); out.push(`<h${heading[1].length}>${inline(heading[2])}</h${heading[1].length}>`); continue; }
    if (line.startsWith(">")) { flush(); out.push(`<p class="source-note">${inline(line.replace(/^>\s?/, ""))}</p>`); continue; }
    const bullet = line.match(/^[-*]\s+(.+)$/);
    if (bullet) {
      closeParagraph();
      if (!listOpen) { out.push("<ul>"); listOpen = true; }
      out.push(`<li>${inline(bullet[1])}</li>`);
      continue;
    }
    closeList();
    paragraph.push(`${inline(line)}${hardBreak ? "<br>" : " "}`);
  }
  flush();
  return out.join("\n");
}

function parseResume(raw) {
  const sectionMatches = [...raw.matchAll(/^##\s+(.+)$/gm)];
  const header = raw.slice(0, sectionMatches[0].index).trim();
  const sections = new Map();
  sectionMatches.forEach((match, index) => {
    const start = match.index + match[0].length;
    const end = index + 1 < sectionMatches.length ? sectionMatches[index + 1].index : raw.length;
    sections.set(match[1].trim(), raw.slice(start, end).trim());
  });
  return { header, sections };
}

function splitH3(raw) {
  return raw.split(/(?=^###\s+)/m).map((part) => part.trim()).filter(Boolean);
}

function bulletValues(raw) {
  return [...raw.matchAll(/^[-*]\s+(.+)$/gm)].map((match) => match[1]);
}

function groupedCapabilities(raw) {
  const groups = [];
  const lines = raw.split("\n");
  let current = null;
  for (const line of lines) {
    const title = line.trim().match(/^\*\*(.+?)\*\*$/);
    if (title) { current = { title: title[1], items: [] }; groups.push(current); continue; }
    const bullet = line.trim().match(/^[-*]\s+(.+)$/);
    if (bullet && current) current.items.push(bullet[1]);
  }
  return groups;
}

const parsed = parseResume(source);
const sections = parsed.sections;
const work = splitH3(sections.get("工作经历"));
const projects = splitH3(sections.get("代表项目"));
const capabilityGroups = groupedCapabilities(sections.get("核心能力"));
const keyResults = bulletValues(sections.get("关键成果"));

const title = source.match(/^#\s+(.+)$/m)[1];
const [personName, roleName] = title.split("｜");
const headerLines = parsed.header.split("\n").map((line) => line.trim()).filter((line) => line && !line.startsWith("#") && !line.startsWith(">") && line !== "---").map((line) => line.replace(/\\@/g, "@").replace(/\\$/, ""));
const sourceNote = [...parsed.header.matchAll(/^>\s?(.*)$/gm)].map((m) => m[1].replace(/\\$/, "")).join(" ");

const sectionHtml = (name) => markdown(sections.get(name));
const workHtml = (index) => markdown(work[index]);
const projectHtml = (index) => markdown(projects[index]);
const contacts = (className, itemTag = "span") => `<div class="${className}">${headerLines.map((line) => `<${itemTag}>${inline(line)}</${itemTag}>`).join("")}</div>`;
const note = (className) => sourceNote ? `<p class="${className}">${inline(sourceNote)}</p>` : "";
const metricValue = (item) => {
  const match = item.match(/\*\*(.+?)\*\*/);
  return match ? match[1] : "—";
};
const metricLabel = (item) => inline(item.replace(/\*\*/g, ""));
const capabilityCards = (prefix, tags = ["article", "article", "article"]) => capabilityGroups.map((group, index) => `<${tags[index]} class="${prefix}-cap ${prefix}-cap-${index + 1}"><span class="${prefix}-cap-no">0${index + 1}</span><h3>${inline(group.title)}</h3><ul>${group.items.map((item) => `<li>${inline(item)}</li>`).join("")}</ul></${tags[index]}>`).join("");
const pageFooter = (prefix, page) => `<footer class="${prefix}-footer"><span>${personName} · ${roleName}</span><span>0${page} / 04</span></footer>`;

const printContract = `
  * { box-sizing: border-box; }
  *, *::before, *::after { animation: none !important; transition: none !important; }
  html { scroll-behavior: auto; background: #d9dde2; }
  body { margin: 0; background: #d9dde2; }
  @page { size: A4 portrait; margin: 0; }
  .resume-book { width: 210mm; margin: 16px auto; }
  .resume-page { position: relative; width: 210mm; height: 297mm; margin: 0 0 16px; padding: var(--page-pad, 13mm 15mm 14mm); background: var(--page-bg, #fff); color: var(--text, #111); }
  .resume-page + .resume-page { break-before: page; page-break-before: always; }
  .resume-item, .project-item { break-inside: avoid; page-break-inside: avoid; }
  @media print {
    html, body { margin: 0; background: #fff; }
    .resume-book { width: auto; margin: 0; }
    .resume-page { display: block; float: none; width: 210mm; height: 297mm; margin: 0; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    .resume-page + .resume-page { break-before: page; page-break-before: always; }
  }
`;

function documentHtml(styleName, styleId, css, pages) {
  return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>视觉风格-${styleName.replace(/\s+/g, "")}-预览简历</title>
  <style>${printContract}${css}</style>
</head>
<body data-preview-style="${styleId}">
  <main class="resume-book" aria-label="${personName}简历">
    ${pages.map((content, index) => `<article class="resume-page">${content}${pageFooter(styleId.replace("design_", ""), index + 1)}</article>`).join("\n")}
  </main>
</body>
</html>`;
}

function officevibe() {
  const css = `
    :root { --page-bg:#f9f8f6; --text:#171417; --navy:#0c1754; --blue:#2545ff; --lav:#eaebf8; --border:#c8bfb6; --page-pad:13mm 15mm 14mm; }
    body { font-family: Inter, ui-sans-serif, system-ui, sans-serif; font-size:9.2pt; line-height:1.5; }
    .resume-page { border-radius:16px; box-shadow:0 12px 34px rgba(12,23,84,.13); }
    .ov-top { display:flex; justify-content:space-between; align-items:center; margin-bottom:7mm; font-size:7.4pt; font-weight:700; letter-spacing:.12em; text-transform:uppercase; }
    .ov-mark { display:flex; align-items:center; gap:6px; color:var(--navy); }
    .ov-mark i { width:9px; height:9px; background:var(--blue); border-radius:50%; }
    .ov-demo { padding:4px 10px; color:var(--navy); background:var(--lav); border-radius:999px; letter-spacing:.06em; }
    .ov-hero { display:grid; grid-template-columns:1.45fr .75fr; gap:9mm; align-items:end; }
    .ov-eyebrow,.ov-kicker { margin:0 0 2mm; font-size:7.2pt; font-weight:700; letter-spacing:.14em; text-transform:uppercase; color:var(--blue); }
    .ov-hero h1 { margin:0; font:italic 400 34pt/1 Georgia,serif; letter-spacing:-.045em; color:var(--navy); }
    .ov-hero h1 span { display:block; margin-top:2mm; font:500 13pt/1.2 Inter,sans-serif; letter-spacing:-.025em; color:#171417; }
    .ov-contact { padding:5mm; background:#fff; border:1px solid var(--border); border-radius:16px; }
    .ov-contact span { display:block; margin-bottom:1.2mm; font-size:8pt; }
    .ov-note { margin:5mm 0 0; padding:3mm 4mm; background:var(--lav); border-radius:999px; color:var(--navy); font-size:7.2pt; }
    .ov-intro { display:grid; grid-template-columns:.45fr 1.55fr; gap:6mm; margin:8mm 0; padding-top:6mm; border-top:1px solid var(--border); }
    .ov-intro h2,.ov-section-title { margin:0; font:italic 400 20pt/1.05 Georgia,serif; color:var(--navy); }
    .ov-intro p { margin:0 0 2mm; }
    .ov-metrics { display:grid; grid-template-columns:repeat(4,1fr); gap:3mm; margin:6mm 0; }
    .ov-metric { min-height:28mm; padding:4mm; border-radius:16px; background:#fff; border:1px solid var(--border); }
    .ov-metric:first-child { background:var(--navy); color:#fff; border-color:var(--navy); }
    .ov-metric strong { display:block; margin-bottom:2mm; font-size:17pt; line-height:1; color:inherit; }
    .ov-metric span { font-size:7.4pt; line-height:1.35; }
    .ov-cap-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:3mm; margin-top:4mm; }
    .ov-cap { padding:5mm; border-radius:16px; border:1px solid var(--border); background:#fff; }
    .ov-cap-1 { background:var(--navy); color:#fff; border-color:var(--navy); }
    .ov-cap-3 { border:1.5px solid var(--blue); }
    .ov-cap-no { display:inline-flex; width:8mm; height:8mm; align-items:center; justify-content:center; border-radius:50%; background:var(--blue); color:#fff; font-weight:700; }
    .ov-cap h3 { margin:4mm 0 2mm; font-size:11pt; color:inherit; }
    .ov-cap ul { margin:0; padding-left:4mm; font-size:7.4pt; line-height:1.45; }
    .ov-page-head { display:grid; grid-template-columns:.65fr 1.35fr; gap:8mm; margin-bottom:6mm; align-items:end; }
    .ov-page-head h1 { margin:0; font:italic 400 28pt/1 Georgia,serif; color:var(--navy); }
    .ov-page-head p { margin:0; color:#55505a; }
    .ov-role { margin-bottom:4mm; padding:5mm; background:#fff; border:1px solid var(--border); border-radius:16px; }
    .ov-role:first-of-type { background:var(--navy); color:#fff; border-color:var(--navy); }
    .ov-role h3,.ov-project h3 { margin:0 0 2mm; font-size:13pt; color:inherit; }
    .ov-role p,.ov-project p { margin:0 0 2mm; }
    .ov-role ul,.ov-project ul { margin:2mm 0 0; padding-left:5mm; }
    .ov-role li,.ov-project li { margin-bottom:1.1mm; }
    .ov-projects { display:grid; grid-template-columns:1.1fr .9fr; gap:4mm; }
    .ov-project { padding:6mm; background:#fff; border:1px solid var(--border); border-radius:16px; }
    .ov-project:first-child { border:1.5px solid var(--blue); }
    .ov-management { margin-top:5mm; padding:5mm 6mm; background:var(--navy); color:#fff; border-radius:16px; columns:2; column-gap:8mm; }
    .ov-management h2 { column-span:all; margin:0 0 3mm; font:italic 400 19pt Georgia,serif; }
    .ov-management ul { margin:0; padding-left:5mm; }
    .ov-bg-grid { display:grid; grid-template-columns:1fr 1fr; gap:4mm; }
    .ov-block { padding:5mm; background:#fff; border:1px solid var(--border); border-radius:16px; }
    .ov-block h2 { margin:0 0 3mm; font:italic 400 16pt Georgia,serif; color:var(--navy); }
    .ov-block p,.ov-block ul { margin:0 0 2mm; }
    .ov-wide { grid-column:1 / -1; }
    .officevibe-footer { position:absolute; left:15mm; right:15mm; bottom:5mm; display:flex; justify-content:space-between; padding-top:2mm; border-top:1px solid var(--border); color:#5f5a62; font-size:7pt; }
  `;
  const pages = [
    `<header class="ov-top"><div class="ov-mark"><i></i>CAREER EDITION</div></header><section class="ov-hero"><div><p class="ov-eyebrow">AI PRODUCT & GROWTH</p><h1>${personName}<span>${roleName}</span></h1></div>${contacts("ov-contact")}</section>${note("ov-note")}<section class="ov-intro"><h2>个人<br><em>简介</em></h2><div>${sectionHtml("个人简介")}</div></section><section><p class="ov-kicker">SELECTED IMPACT</p><div class="ov-metrics">${keyResults.map((item) => `<div class="ov-metric"><strong>${metricValue(item)}</strong><span>${metricLabel(item)}</span></div>`).join("")}</div></section><section><h2 class="ov-section-title">核心<em>能力</em></h2><div class="ov-cap-grid">${capabilityCards("ov")}</div></section>`,
    `<header class="ov-page-head"><h1>工作<em>经历</em></h1><p>从企业效率工具到 AI 产品商业化，职业路径保持连续，责任范围逐步扩大。</p></header>${work.map((_, i) => `<section class="ov-role resume-item">${workHtml(i)}</section>`).join("")}`,
    `<header class="ov-page-head"><h1>代表<em>项目</em></h1><p>项目描述保留背景、本人职责、关键决策与结果，不把普通职责包装成案例。</p></header><div class="ov-projects">${projects.map((_, i) => `<article class="ov-project project-item">${projectHtml(i)}</article>`).join("")}</div><section class="ov-management"><h2>管理与组织经验</h2>${sectionHtml("管理与组织经验")}</section>`,
    `<header class="ov-page-head"><h1>专业<em>背景</em></h1><p>教育、研究、技术与组织活动共同构成完整的职业证据。</p></header><div class="ov-bg-grid"><section class="ov-block"> <h2>教育与研究</h2>${sectionHtml("教育与研究")}</section><section class="ov-block"><h2>研究与专业活动</h2>${sectionHtml("研究与专业活动")}</section><section class="ov-block ov-wide"><h2>专业技能</h2>${sectionHtml("专业技能")}</section><section class="ov-block ov-wide"><h2>荣誉与认证</h2>${sectionHtml("荣誉与认证")}</section></div>`,
  ];
  return documentHtml("温暖编辑", "design_officevibe", css, pages);
}

function hellotime() {
  const css = `
    :root { --page-bg:#fff; --text:#151619; --ink:#151619; --muted:#5d626d; --line:#8a8f99; --mist:#f3f3f5; --dark:#25272d; --blue:#0560fd; --page-pad:12mm 14mm 14mm; }
    body { font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; font-size:9pt; line-height:1.42; }
    .resume-page { box-shadow:0 10px 30px rgba(21,22,25,.12); }
    .ht-top { display:flex; justify-content:space-between; align-items:center; margin-bottom:8mm; font-size:7pt; font-weight:700; letter-spacing:.11em; text-transform:uppercase; }
    .ht-brand { display:flex; gap:6px; align-items:center; }
    .ht-check { width:10px; height:10px; border:2px solid #059669; border-top:0; border-left:0; transform:rotate(45deg); }
    .ht-hero { display:grid; grid-template-columns:1.3fr .7fr; gap:8mm; align-items:start; }
    .ht-hero h1 { margin:0; font-size:34pt; line-height:.96; letter-spacing:-.06em; }
    .ht-highlight { display:inline; color:var(--ink); background:linear-gradient(transparent 58%,#a8c8ff 58%,#a8c8ff 92%,transparent 92%); }
    .ht-lead { margin:5mm 0 0; max-width:115mm; font-size:10.5pt; color:var(--muted); }
    .ht-contact { padding:4mm; border:1px solid var(--line); border-radius:16px; }
    .ht-contact span { display:block; margin-bottom:1.2mm; font-size:7.6pt; }
    .ht-note { margin:5mm 0; padding:3mm 4mm; color:#333740; background:var(--mist); border-radius:8px; font-size:7.2pt; }
    .ht-summary { display:grid; grid-template-columns:1fr 1fr; gap:7mm; padding:5mm 0; border-top:2px solid var(--ink); border-bottom:1px solid var(--line); }
    .ht-summary h2,.ht-page-title { margin:0; font-size:22pt; line-height:1; letter-spacing:-.045em; }
    .ht-summary p { margin:0 0 2mm; }
    .ht-metrics { display:grid; grid-template-columns:repeat(4,1fr); gap:2.5mm; margin:6mm 0; }
    .ht-metric { padding:4mm; background:var(--mist); border:1px solid var(--line); border-radius:16px; }
    .ht-metric strong { display:block; font-size:17pt; line-height:1; }
    .ht-metric span { display:block; margin-top:2mm; color:#4d525c; font-size:7.2pt; }
    .ht-caps { display:grid; grid-template-columns:repeat(3,1fr); gap:3mm; }
    .ht-cap { padding:4.5mm; border:1px solid var(--line); border-radius:16px; }
    .ht-cap-1 { color:#fff; background:var(--dark); border-color:var(--dark); }
    .ht-cap-no { display:block; margin-bottom:4mm; color:#2856b6; font-size:8pt; font-weight:700; }
    .ht-cap h3 { margin:0 0 2mm; font-size:11pt; }
    .ht-cap ul { margin:0; padding-left:4mm; font-size:7.5pt; }
    .ht-page-head { display:flex; justify-content:space-between; align-items:end; margin-bottom:6mm; padding-bottom:4mm; border-bottom:2px solid var(--ink); }
    .ht-page-head span { color:var(--muted); font-size:7.4pt; letter-spacing:.12em; }
    .ht-role { margin-bottom:4mm; padding:5mm; border:1px solid var(--line); border-radius:16px; }
    .ht-role-current { color:#fff; background:var(--dark); border-color:var(--dark); }
    .ht-role h3,.ht-project h3 { margin:0 0 1mm; font-size:14pt; }
    .ht-role p,.ht-project p { margin:0 0 2mm; }
    .ht-role ul,.ht-project ul { margin:2mm 0 0; padding-left:5mm; }
    .ht-role li,.ht-project li { margin-bottom:1mm; }
    .ht-project { margin-bottom:4mm; padding:5mm; border-radius:16px; background:var(--mist); border:1px solid var(--line); }
    .ht-project:first-of-type { background:#fff; border:2px solid var(--ink); }
    .ht-manage { display:grid; grid-template-columns:.55fr 1.45fr; gap:5mm; margin-top:5mm; padding-top:5mm; border-top:2px solid var(--ink); }
    .ht-manage h2 { margin:0; font-size:18pt; line-height:1; }
    .ht-manage ul { margin:0; padding-left:5mm; columns:2; column-gap:8mm; }
    .ht-background { display:grid; grid-template-columns:1fr 1fr; gap:4mm; }
    .ht-block { padding:5mm; border:1px solid var(--line); border-radius:16px; }
    .ht-block h2 { margin:0 0 3mm; font-size:15pt; }
    .ht-block p,.ht-block ul { margin:0 0 2mm; }
    .ht-wide { grid-column:1/-1; background:var(--mist); }
    .hellotime-footer { position:absolute; left:14mm; right:14mm; bottom:5mm; display:flex; justify-content:space-between; padding-top:2mm; border-top:1px solid var(--line); color:#575c67; font-size:7pt; }
  `;
  const pages = [
    `<header class="ht-top"><div class="ht-brand"><i class="ht-check"></i>PROFILE / 2026</div><span>CAREER PROFILE</span></header><section class="ht-hero"><div><h1>${personName}<br><span class="ht-highlight">${roleName}</span></h1><p class="ht-lead">9 年企业软件与数字产品经验，以产品机制、商业结果和组织协作推进企业级 AI 落地。</p></div>${contacts("ht-contact")}</section>${note("ht-note")}<section class="ht-summary"><h2>个人简介</h2><div>${sectionHtml("个人简介")}</div></section><div class="ht-metrics">${keyResults.map((item) => `<div class="ht-metric"><strong>${metricValue(item)}</strong><span>${metricLabel(item)}</span></div>`).join("")}</div><section><h2 class="ht-page-title" style="margin-bottom:4mm">核心能力</h2><div class="ht-caps">${capabilityCards("ht")}</div></section>`,
    `<header class="ht-page-head"><h1 class="ht-page-title">工作经历</h1><span>EXPERIENCE / 02</span></header>${work.map((_, i) => `<section class="ht-role ${i===0?"ht-role-current":""} resume-item">${workHtml(i)}</section>`).join("")}`,
    `<header class="ht-page-head"><h1 class="ht-page-title">项目与管理</h1><span>PROJECTS / 03</span></header>${projects.map((_, i) => `<article class="ht-project project-item">${projectHtml(i)}</article>`).join("")}<section class="ht-manage"><h2>管理与<br>组织经验</h2><div>${sectionHtml("管理与组织经验")}</div></section>`,
    `<header class="ht-page-head"><h1 class="ht-page-title">专业背景</h1><span>BACKGROUND / 04</span></header><div class="ht-background"><section class="ht-block"><h2>教育与研究</h2>${sectionHtml("教育与研究")}</section><section class="ht-block"><h2>研究与专业活动</h2>${sectionHtml("研究与专业活动")}</section><section class="ht-block ht-wide"><h2>专业技能</h2>${sectionHtml("专业技能")}</section><section class="ht-block ht-wide"><h2>荣誉与认证</h2>${sectionHtml("荣誉与认证")}</section></div>`,
  ];
  return documentHtml("极简数据", "design_hellotime", css, pages);
}

function uber() {
  const css = `
    :root { --page-bg:#fff; --text:#000; --black:#000; --gray:#f2f2f2; --muted:#4f4f4f; --line:#767676; --page-pad:0 15mm 14mm; }
    body { font-family:Arial,Helvetica,sans-serif; font-size:9pt; line-height:1.42; }
    .resume-page { box-shadow:0 10px 28px rgba(0,0,0,.15); }
    .ub-bar { margin:0 -15mm 7mm; padding:5mm 15mm; display:flex; justify-content:space-between; align-items:center; color:#fff; background:#000; font-size:7.4pt; }
    .ub-word { font-size:15pt; font-weight:700; letter-spacing:-.04em; }
    .ub-pill { padding:5px 11px; border-radius:999px; background:#fff; color:#000; }
    .ub-hero { display:grid; grid-template-columns:1.2fr .8fr; gap:8mm; align-items:start; }
    .ub-hero h1 { margin:0 0 4mm; font-size:32pt; line-height:1.05; letter-spacing:-.045em; font-weight:500; }
    .ub-hero h1 span { display:block; font-size:14pt; margin-top:2mm; }
    .ub-route { padding:5mm; background:var(--gray); border-radius:8px; }
    .ub-route span { position:relative; display:block; padding:0 0 3mm 7mm; font-size:7.7pt; }
    .ub-route span::before { content:""; position:absolute; left:0; top:3px; width:5px; height:5px; background:#000; border-radius:50%; }
    .ub-route span:not(:last-child)::after { content:""; position:absolute; left:2px; top:8px; bottom:0; border-left:1px solid #000; }
    .ub-note { margin:5mm 0; padding:3mm 0; border-top:1px solid #000; border-bottom:1px solid #000; font-size:7.2pt; }
    .ub-intro { display:grid; grid-template-columns:.5fr 1.5fr; gap:7mm; margin:6mm 0; }
    .ub-intro h2,.ub-title { margin:0; font-size:22pt; line-height:1.04; font-weight:500; }
    .ub-intro p { margin:0 0 2mm; }
    .ub-metrics { display:grid; grid-template-columns:repeat(4,1fr); gap:3mm; }
    .ub-metric { padding:4mm; background:var(--gray); border-radius:8px; }
    .ub-metric strong { display:block; font-size:16pt; }
    .ub-metric span { display:block; margin-top:2mm; font-size:7.2pt; color:var(--muted); }
    .ub-cap-grid { display:grid; grid-template-columns:repeat(3,1fr); gap:3mm; margin-top:6mm; }
    .ub-cap { padding:4mm; border:1px solid #000; border-radius:8px; }
    .ub-cap-no { display:inline-block; margin-bottom:3mm; padding:3px 7px; color:#fff; background:#000; border-radius:999px; font-size:7pt; }
    .ub-cap h3 { margin:0 0 2mm; font-size:11pt; }
    .ub-cap ul { margin:0; padding-left:4mm; font-size:7.5pt; }
    .ub-head { display:flex; justify-content:space-between; align-items:end; margin-bottom:6mm; }
    .ub-head small { color:var(--muted); }
    .ub-timeline { position:relative; padding-left:8mm; }
    .ub-timeline::before { content:""; position:absolute; left:2mm; top:2mm; bottom:2mm; border-left:2px solid #000; }
    .ub-role { position:relative; margin-bottom:4mm; padding:5mm; background:var(--gray); border-radius:8px; }
    .ub-role::before { content:""; position:absolute; left:-7mm; top:6mm; width:4mm; height:4mm; background:#000; }
    .ub-role h3,.ub-project h3 { margin:0 0 1mm; font-size:13pt; }
    .ub-role p,.ub-project p { margin:0 0 2mm; }
    .ub-role ul,.ub-project ul { margin:2mm 0 0; padding-left:5mm; }
    .ub-role li,.ub-project li { margin-bottom:1mm; }
    .ub-project { margin-bottom:4mm; padding:5mm; border:1px solid #000; border-radius:8px; }
    .ub-project:first-of-type { color:#fff; background:#000; }
    .ub-manage { display:grid; grid-template-columns:1fr 1fr; gap:3mm; margin-top:5mm; }
    .ub-manage h2 { margin:0; padding:5mm; color:#fff; background:#000; border-radius:8px; font-size:17pt; }
    .ub-manage div { padding:5mm; background:var(--gray); border-radius:8px; }
    .ub-manage ul { margin:0; padding-left:5mm; }
    .ub-grid { display:grid; grid-template-columns:1fr 1fr; gap:3mm; }
    .ub-block { padding:5mm; background:var(--gray); border-radius:8px; }
    .ub-block h2 { margin:0 0 3mm; font-size:15pt; }
    .ub-block p,.ub-block ul { margin:0 0 2mm; }
    .ub-wide { grid-column:1/-1; border:1px solid #000; background:#fff; }
    .uber-footer { position:absolute; left:15mm; right:15mm; bottom:5mm; display:flex; justify-content:space-between; padding-top:2mm; border-top:1px solid #000; font-size:7pt; }
  `;
  const pages = [
    `<header class="ub-bar"><strong class="ub-word">Career</strong><span class="ub-pill">2026</span></header><section class="ub-hero"><div><h1>${personName}<span>${roleName}</span></h1><p>9 年企业软件与数字产品经验，聚焦 AI 产品、商业化和组织协作。</p></div>${contacts("ub-route")}</section>${note("ub-note")}<section class="ub-intro"><h2>个人简介</h2><div>${sectionHtml("个人简介")}</div></section><div class="ub-metrics">${keyResults.map((item)=>`<div class="ub-metric"><strong>${metricValue(item)}</strong><span>${metricLabel(item)}</span></div>`).join("")}</div><section class="ub-cap-grid">${capabilityCards("ub")}</section>`,
    `<header class="ub-bar"><strong class="ub-word">Experience</strong><span>02 / 04</span></header><div class="ub-head"><h1 class="ub-title">工作经历</h1><small>倒序排列 · 连续职业路径</small></div><div class="ub-timeline">${work.map((_,i)=>`<section class="ub-role resume-item">${workHtml(i)}</section>`).join("")}</div>`,
    `<header class="ub-bar"><strong class="ub-word">Projects</strong><span>03 / 04</span></header><div class="ub-head"><h1 class="ub-title">代表项目</h1><small>背景 · 决策 · 结果</small></div>${projects.map((_,i)=>`<article class="ub-project project-item">${projectHtml(i)}</article>`).join("")}<section class="ub-manage"><h2>管理与组织经验</h2><div>${sectionHtml("管理与组织经验")}</div></section>`,
    `<header class="ub-bar"><strong class="ub-word">Background</strong><span>04 / 04</span></header><div class="ub-head"><h1 class="ub-title">专业背景</h1><small>EDUCATION / RESEARCH / SKILLS</small></div><div class="ub-grid"><section class="ub-block"><h2>教育与研究</h2>${sectionHtml("教育与研究")}</section><section class="ub-block"><h2>研究与专业活动</h2>${sectionHtml("研究与专业活动")}</section><section class="ub-block ub-wide"><h2>专业技能</h2>${sectionHtml("专业技能")}</section><section class="ub-block ub-wide"><h2>荣誉与认证</h2>${sectionHtml("荣誉与认证")}</section></div>`,
  ];
  return documentHtml("黑白秩序", "design_uber", css, pages);
}

function perplexity() {
  const css = `
    :root { --page-bg:#faf8f5; --text:#27251e; --paper:#fdfbfa; --teal:#016a71; --teal-soft:#e3efed; --line:#8f8d85; --muted:#64625c; --page-pad:0; }
    body { font-family:"Avenir Next",Avenir,ui-sans-serif,system-ui,sans-serif; font-size:9pt; line-height:1.48; }
    .resume-page { box-shadow:0 10px 30px rgba(39,37,30,.12); }
    .px-shell { min-height:297mm; display:grid; grid-template-columns:48mm 1fr; }
    .px-side { padding:13mm 6mm 14mm 8mm; background:#f0ede7; border-right:1px solid var(--line); }
    .px-logo { display:flex; gap:7px; align-items:center; margin-bottom:9mm; font-size:10pt; font-weight:600; }
    .px-logo i { width:10px; height:10px; border:2px solid var(--teal); transform:rotate(45deg); }
    .px-side-label { margin:0 0 3mm; color:var(--muted); font-size:7pt; font-weight:600; letter-spacing:.12em; text-transform:uppercase; }
    .px-nav { display:grid; gap:2mm; margin:0 0 8mm; }
    .px-nav span { padding:2mm 3mm; border-radius:8px; color:var(--muted); font-size:7.4pt; }
    .px-nav .active { color:#fff; background:var(--teal); }
    .px-contact { display:grid; gap:2mm; }
    .px-contact span { font-size:7.2pt; line-height:1.35; }
    .px-page-mark { margin-top:12mm; color:var(--teal); font-size:24pt; font-weight:500; }
    .px-main { padding:13mm 13mm 14mm 10mm; }
    .px-hero-kicker { margin:0 0 3mm; color:var(--teal); font-size:7pt; font-weight:700; letter-spacing:.14em; }
    .px-hero h1 { margin:0; font-size:29pt; line-height:1.05; letter-spacing:-.045em; font-weight:500; }
    .px-hero h1 span { display:block; margin-top:2mm; color:var(--muted); font-size:13pt; letter-spacing:-.02em; }
    .px-note { margin:5mm 0; padding:3mm 4mm; background:var(--paper); border:1px solid var(--line); border-radius:12px; color:#3c3932; font-size:7.2pt; }
    .px-query { margin:6mm 0; padding:5mm; background:var(--paper); border:1px solid var(--line); border-radius:14px; box-shadow:0 2px 0 rgba(39,37,30,.05); }
    .px-query-label { display:flex; justify-content:space-between; margin-bottom:3mm; color:var(--teal); font-size:7pt; letter-spacing:.1em; }
    .px-query p { margin:0 0 2mm; }
    .px-metrics { display:grid; grid-template-columns:1fr 1fr; gap:3mm; margin:5mm 0; }
    .px-metric { padding:4mm; background:var(--teal-soft); border-radius:14px; }
    .px-metric strong { display:block; color:var(--teal); font-size:16pt; }
    .px-metric span { font-size:7.2pt; }
    .px-cap-list { display:grid; gap:2.5mm; }
    .px-cap { padding:3.5mm 4mm; background:var(--paper); border:1px solid var(--line); border-radius:14px; }
    .px-cap-no { float:right; color:var(--teal); font-size:7pt; }
    .px-cap h3 { margin:0 0 1.5mm; font-size:10.5pt; }
    .px-cap ul { margin:0; padding-left:4mm; columns:2; column-gap:6mm; font-size:7.5pt; }
    .px-title { margin:0 0 5mm; font-size:21pt; font-weight:500; letter-spacing:-.04em; }
    .px-role { margin-bottom:4mm; padding:4mm; background:var(--paper); border:1px solid var(--line); border-radius:14px; }
    .px-role:first-of-type { border-left:5px solid var(--teal); }
    .px-role h3,.px-project h3 { margin:0 0 1mm; font-size:12pt; }
    .px-role p,.px-project p { margin:0 0 2mm; }
    .px-role ul,.px-project ul { margin:2mm 0 0; padding-left:5mm; }
    .px-role li,.px-project li { margin-bottom:.9mm; }
    .px-project { margin-bottom:4mm; padding:5mm; background:var(--paper); border:1px solid var(--line); border-radius:14px; }
    .px-project:first-of-type { background:var(--teal-soft); }
    .px-manage { padding:5mm; border-left:5px solid var(--teal); background:var(--paper); border-radius:0 14px 14px 0; }
    .px-manage h2,.px-block h2 { margin:0 0 3mm; font-size:13pt; }
    .px-manage ul { margin:0; padding-left:5mm; columns:2; }
    .px-grid { display:grid; grid-template-columns:1fr 1fr; gap:3mm; }
    .px-block { padding:4mm; background:var(--paper); border:1px solid var(--line); border-radius:14px; }
    .px-block p,.px-block ul { margin:0 0 2mm; }
    .px-wide { grid-column:1/-1; }
    .perplexity-footer { position:absolute; left:56mm; right:13mm; bottom:5mm; display:flex; justify-content:space-between; padding-top:2mm; border-top:1px solid var(--line); color:var(--muted); font-size:7pt; }
  `;
  const sidebar = (page, active, includeContact=false) => `<aside class="px-side"><div class="px-logo"><i></i>research desk</div><p class="px-side-label">Sections</p><nav class="px-nav"><span class="${active===1?"active":""}">个人概览</span><span class="${active===2?"active":""}">工作经历</span><span class="${active===3?"active":""}">项目与管理</span><span class="${active===4?"active":""}">专业背景</span></nav>${includeContact?contacts("px-contact"):""}<div class="px-page-mark">0${page}</div></aside>`;
  const pages = [
    `<div class="px-shell">${sidebar(1,1,true)}<main class="px-main"><header class="px-hero"><p class="px-hero-kicker">KNOWLEDGE · PRODUCT · GROWTH</p><h1>${personName}<span>${roleName}</span></h1></header>${note("px-note")}<section class="px-query"><div class="px-query-label"><span>职业摘要</span><span>已核验来源</span></div>${sectionHtml("个人简介")}</section><div class="px-metrics">${keyResults.map((item)=>`<div class="px-metric"><strong>${metricValue(item)}</strong><span>${metricLabel(item)}</span></div>`).join("")}</div><section class="px-cap-list">${capabilityCards("px")}</section></main></div>`,
    `<div class="px-shell">${sidebar(2,2)}<main class="px-main"><h1 class="px-title">工作经历</h1>${work.map((_,i)=>`<section class="px-role resume-item">${workHtml(i)}</section>`).join("")}</main></div>`,
    `<div class="px-shell">${sidebar(3,3)}<main class="px-main"><h1 class="px-title">项目与管理</h1>${projects.map((_,i)=>`<article class="px-project project-item">${projectHtml(i)}</article>`).join("")}<section class="px-manage"><h2>管理与组织经验</h2>${sectionHtml("管理与组织经验")}</section></main></div>`,
    `<div class="px-shell">${sidebar(4,4)}<main class="px-main"><h1 class="px-title">专业背景</h1><div class="px-grid"><section class="px-block"><h2>教育与研究</h2>${sectionHtml("教育与研究")}</section><section class="px-block"><h2>研究与专业活动</h2>${sectionHtml("研究与专业活动")}</section><section class="px-block px-wide"><h2>专业技能</h2>${sectionHtml("专业技能")}</section><section class="px-block px-wide"><h2>荣誉与认证</h2>${sectionHtml("荣誉与认证")}</section></div></main></div>`,
  ];
  return documentHtml("研究手记", "design_perplexity", css, pages);
}

function intercom() {
  const css = `
    :root { --page-bg:#faf9f6; --text:#111; --cream:#faf9f6; --linen:#f1eee9; --line:#8f8a82; --violet:#0007cb; --muted:#555; --page-pad:13mm 15mm 14mm; }
    body { font-family:Inter,"Helvetica Neue",Arial,sans-serif; font-size:9.2pt; line-height:1.5; }
    .resume-page { box-shadow:0 12px 32px rgba(17,17,17,.11); }
    .ic-rail { display:flex; justify-content:space-between; margin-bottom:9mm; padding-bottom:3mm; border-bottom:1px solid var(--line); font:500 7pt/1 ui-monospace,SFMono-Regular,Menlo,monospace; letter-spacing:.14em; text-transform:uppercase; }
    .ic-rail b { color:var(--violet); }
    .ic-hero { display:grid; grid-template-columns:1.45fr .55fr; gap:10mm; }
    .ic-hero h1 { margin:0; font-size:34pt; line-height:.98; letter-spacing:-.055em; font-weight:300; }
    .ic-hero h1 span { display:block; margin-top:3mm; font-size:13pt; line-height:1.2; letter-spacing:-.02em; }
    .ic-contact { border-left:1px solid var(--line); padding-left:5mm; }
    .ic-contact span { display:block; margin-bottom:1.5mm; font-size:7.5pt; }
    .ic-note { margin:7mm 0; padding:3mm 0; border-top:1px solid var(--line); border-bottom:1px solid var(--line); color:var(--muted); font-size:7.2pt; }
    .ic-spread { display:grid; grid-template-columns:.62fr 1.38fr; gap:9mm; margin:7mm 0; }
    .ic-label { margin:0; color:var(--violet); font:500 7pt/1.4 ui-monospace,SFMono-Regular,Menlo,monospace; letter-spacing:.16em; text-transform:uppercase; }
    .ic-spread h2,.ic-title { margin:2mm 0 0; font-size:21pt; line-height:1.05; font-weight:300; letter-spacing:-.04em; }
    .ic-copy p { margin:0 0 2mm; }
    .ic-metrics { display:grid; grid-template-columns:repeat(4,1fr); border-top:1px solid var(--line); border-bottom:1px solid var(--line); }
    .ic-metric { padding:4mm 3mm; border-right:1px solid var(--line); }
    .ic-metric:last-child { border-right:0; }
    .ic-metric strong { display:block; font-size:16pt; font-weight:300; }
    .ic-metric span { font-size:7.1pt; color:var(--muted); }
    .ic-caps { display:grid; grid-template-columns:repeat(3,1fr); gap:5mm; margin-top:7mm; }
    .ic-cap { padding-top:3mm; border-top:3px solid #111; }
    .ic-cap-2 { border-color:var(--violet); }
    .ic-cap-no { font:500 7pt ui-monospace,monospace; color:var(--violet); }
    .ic-cap h3 { margin:4mm 0 2mm; font-size:12pt; font-weight:400; }
    .ic-cap ul { margin:0; padding-left:4mm; font-size:7.5pt; }
    .ic-page-head { display:grid; grid-template-columns:.6fr 1.4fr; gap:8mm; align-items:end; margin-bottom:7mm; }
    .ic-page-head p { margin:0; color:var(--muted); }
    .ic-role { margin-bottom:5mm; padding:4mm 0 0 44mm; border-top:1px solid var(--line); }
    .ic-role h3,.ic-project h3 { margin:0 0 1mm; font-size:13pt; font-weight:300; }
    .ic-role p,.ic-project p { margin:0 0 2mm; }
    .ic-role ul,.ic-project ul { margin:2mm 0 0; padding-left:5mm; }
    .ic-role li,.ic-project li { margin-bottom:1mm; }
    .ic-role h3 { margin-left:-44mm; }
    .ic-role > p:first-of-type { margin-left:-44mm; float:left; width:38mm; color:var(--violet); font:500 7pt/1.45 ui-monospace,monospace; letter-spacing:.06em; }
    .ic-project { margin-bottom:5mm; padding:5mm; background:var(--linen); border-radius:4px; }
    .ic-project:first-of-type { border-left:4px solid var(--violet); }
    .ic-manage { display:grid; grid-template-columns:.55fr 1.45fr; gap:7mm; margin-top:6mm; }
    .ic-manage h2 { margin:0; font-size:18pt; font-weight:300; }
    .ic-manage ul { margin:0; padding-left:5mm; columns:2; }
    .ic-grid { display:grid; grid-template-columns:1fr 1fr; gap:5mm; }
    .ic-block { padding-top:4mm; border-top:1px solid var(--line); }
    .ic-block h2 { margin:0 0 3mm; font-size:15pt; font-weight:300; }
    .ic-block p,.ic-block ul { margin:0 0 2mm; }
    .ic-wide { grid-column:1/-1; }
    .intercom-footer { position:absolute; left:15mm; right:15mm; bottom:5mm; display:flex; justify-content:space-between; padding-top:2mm; border-top:1px solid var(--line); color:var(--muted); font:500 7pt ui-monospace,monospace; letter-spacing:.1em; }
  `;
  const pages = [
    `<header class="ic-rail"><b>CAREER PROFILE</b><span>INTERVIEW EDITION / 2026</span></header><section class="ic-hero"><div><p class="ic-label">AI PRODUCT LEADERSHIP</p><h1>${personName}<span>${roleName}</span></h1></div>${contacts("ic-contact")}</section>${note("ic-note")}<section class="ic-spread"><div><p class="ic-label">01 / PROFILE</p><h2>个人简介</h2></div><div class="ic-copy">${sectionHtml("个人简介")}</div></section><div class="ic-metrics">${keyResults.map((item)=>`<div class="ic-metric"><strong>${metricValue(item)}</strong><span>${metricLabel(item)}</span></div>`).join("")}</div><section class="ic-caps">${capabilityCards("ic")}</section>`,
    `<header class="ic-rail"><b>EXPERIENCE</b><span>02 / 04</span></header><div class="ic-page-head"><div><p class="ic-label">CAREER TIMELINE</p><h1 class="ic-title">工作经历</h1></div><p>责任边界、时间和量化结果均来自基准简历，不使用评价性包装。</p></div>${work.map((_,i)=>`<section class="ic-role resume-item">${workHtml(i)}</section>`).join("")}`,
    `<header class="ic-rail"><b>PROJECTS</b><span>03 / 04</span></header><div class="ic-page-head"><div><p class="ic-label">SELECTED WORK</p><h1 class="ic-title">项目与管理</h1></div><p>以关键决策和可验证结果组织项目证据。</p></div>${projects.map((_,i)=>`<article class="ic-project project-item">${projectHtml(i)}</article>`).join("")}<section class="ic-manage"><h2>管理与组织经验</h2><div>${sectionHtml("管理与组织经验")}</div></section>`,
    `<header class="ic-rail"><b>BACKGROUND</b><span>04 / 04</span></header><div class="ic-page-head"><div><p class="ic-label">EDUCATION & CRAFT</p><h1 class="ic-title">专业背景</h1></div><p>研究、技能与专业活动采用连续文本和细分隔线呈现。</p></div><div class="ic-grid"><section class="ic-block"><h2>教育与研究</h2>${sectionHtml("教育与研究")}</section><section class="ic-block"><h2>研究与专业活动</h2>${sectionHtml("研究与专业活动")}</section><section class="ic-block ic-wide"><h2>专业技能</h2>${sectionHtml("专业技能")}</section><section class="ic-block ic-wide"><h2>荣誉与认证</h2>${sectionHtml("荣誉与认证")}</section></div>`,
  ];
  return documentHtml("锐利编辑", "design_intercom", css, pages);
}

function pirsch() {
  const css = `
    :root { --page-bg:#f8f5ed; --text:#000; --yellow:#ffda6e; --green:#6ece9d; --muted:#565656; --page-pad:13mm 15mm 14mm; }
    body { font-family:"DM Sans",Inter,ui-sans-serif,system-ui,sans-serif; font-size:9pt; line-height:1.48; }
    .resume-page { box-shadow:0 10px 28px rgba(45,40,29,.12); }
    .pr-top { display:flex; justify-content:space-between; align-items:center; margin-bottom:8mm; font-size:7.2pt; letter-spacing:.13em; text-transform:uppercase; }
    .pr-top strong { display:flex; align-items:center; gap:6px; }
    .pr-top strong::before { content:""; width:9px; height:9px; background:var(--yellow); border:1px solid #000; border-radius:50%; }
    .pr-hero { text-align:center; }
    .pr-hero h1 { margin:0; font-size:31pt; line-height:1.04; letter-spacing:-.04em; font-weight:500; }
    .pr-hero h1 span { display:block; margin-top:2mm; font-size:13pt; }
    .pr-contact { display:flex; flex-wrap:wrap; justify-content:center; gap:2mm 5mm; margin-top:5mm; }
    .pr-contact span { padding:1.8mm 3mm; border:1px solid #000; border-radius:999px; font-size:7.4pt; }
    .pr-note { margin:5mm auto; max-width:150mm; padding:3mm 4mm; border:1px solid #000; border-radius:20px; font-size:7.2pt; }
    .pr-section-head { display:flex; gap:4mm; align-items:center; margin:6mm 0 3mm; }
    .pr-number { display:inline-flex; width:8mm; height:8mm; align-items:center; justify-content:center; border:1px solid #000; border-radius:50%; background:var(--yellow); font-size:7pt; font-weight:700; }
    .pr-section-head h2,.pr-title { margin:0; font-size:18pt; font-weight:500; letter-spacing:-.025em; }
    .pr-profile { display:grid; grid-template-columns:1.4fr .6fr; gap:5mm; }
    .pr-profile-copy { padding:5mm; border:1px solid #000; border-radius:24px; }
    .pr-profile-copy p { margin:0 0 2mm; }
    .pr-metric-stack { display:grid; gap:2mm; }
    .pr-metric { padding:3mm; border:1px solid #000; border-radius:18px; background:var(--yellow); }
    .pr-metric:nth-child(even) { background:#fff; }
    .pr-metric strong { display:block; font-size:14pt; }
    .pr-metric span { font-size:7pt; }
    .pr-caps { display:grid; grid-template-columns:repeat(3,1fr); gap:3mm; }
    .pr-cap { padding:4mm; border:1px solid #000; border-radius:24px; background:#fff; }
    .pr-cap-no { display:inline-block; margin-bottom:3mm; padding:3px 8px; border-radius:999px; background:var(--yellow); border:1px solid #000; font-size:7pt; }
    .pr-cap h3 { margin:0 0 2mm; font-size:10.5pt; }
    .pr-cap ul { margin:0; padding-left:4mm; font-size:7.3pt; }
    .pr-page-head { text-align:center; margin-bottom:6mm; }
    .pr-page-head p { margin:2mm 0 0; color:var(--muted); }
    .pr-role { display:grid; grid-template-columns:11mm 1fr; gap:4mm; margin-bottom:4mm; }
    .pr-step { width:9mm; height:9mm; display:flex; align-items:center; justify-content:center; border:1px solid #000; border-radius:50%; background:var(--yellow); font-size:7pt; }
    .pr-role-body { padding:4.5mm; border:1px solid #000; border-radius:24px; background:#fff; }
    .pr-role-body h3,.pr-project h3 { margin:0 0 1mm; font-size:12pt; }
    .pr-role-body p,.pr-project p { margin:0 0 2mm; }
    .pr-role-body ul,.pr-project ul { margin:2mm 0 0; padding-left:5mm; }
    .pr-role-body li,.pr-project li { margin-bottom:.9mm; }
    .pr-project { margin-bottom:4mm; padding:5mm; border:1px solid #000; border-radius:24px; background:#fff; }
    .pr-project:first-of-type { box-shadow:5px 5px 0 var(--yellow); }
    .pr-manage { margin-top:6mm; padding:5mm; border:1px solid #000; border-radius:24px; background:var(--yellow); }
    .pr-manage h2 { margin:0 0 2mm; font-size:15pt; }
    .pr-manage ul { margin:0; padding-left:5mm; columns:2; }
    .pr-grid { display:grid; grid-template-columns:1fr 1fr; gap:3mm; }
    .pr-block { padding:4.5mm; border:1px solid #000; border-radius:24px; background:#fff; }
    .pr-block h2 { margin:0 0 3mm; font-size:14pt; }
    .pr-block p,.pr-block ul { margin:0 0 2mm; }
    .pr-wide { grid-column:1/-1; }
    .pirsch_analytics-footer { position:absolute; left:15mm; right:15mm; bottom:5mm; display:flex; justify-content:space-between; padding-top:2mm; border-top:1px solid #000; color:var(--muted); font-size:7pt; }
  `;
  const pages = [
    `<header class="pr-top"><strong>CAREER NOTES</strong><span>ISSUE 01 / 2026</span></header><section class="pr-hero"><h1>${personName}<span>${roleName}</span></h1>${contacts("pr-contact")}</section>${note("pr-note")}<div class="pr-section-head"><span class="pr-number">01</span><h2>个人简介与关键成果</h2></div><section class="pr-profile"><div class="pr-profile-copy">${sectionHtml("个人简介")}</div><div class="pr-metric-stack">${keyResults.map((item)=>`<div class="pr-metric"><strong>${metricValue(item)}</strong><span>${metricLabel(item)}</span></div>`).join("")}</div></section><div class="pr-section-head"><span class="pr-number">02</span><h2>核心能力</h2></div><section class="pr-caps">${capabilityCards("pr")}</section>`,
    `<header class="pr-page-head"><span class="pr-number">03</span><h1 class="pr-title">工作经历</h1><p>按时间倒序展开，保留职责与结果的对应关系。</p></header>${work.map((_,i)=>`<section class="pr-role resume-item"><span class="pr-step">0${i+1}</span><div class="pr-role-body">${workHtml(i)}</div></section>`).join("")}`,
    `<header class="pr-page-head"><span class="pr-number">04</span><h1 class="pr-title">项目与管理</h1><p>项目过程与结果放在同一纸面关系中。</p></header>${projects.map((_,i)=>`<article class="pr-project project-item">${projectHtml(i)}</article>`).join("")}<section class="pr-manage"><h2>管理与组织经验</h2>${sectionHtml("管理与组织经验")}</section>`,
    `<header class="pr-page-head"><span class="pr-number">05</span><h1 class="pr-title">专业背景</h1><p>教育、研究、工具与专业活动。</p></header><div class="pr-grid"><section class="pr-block"><h2>教育与研究</h2>${sectionHtml("教育与研究")}</section><section class="pr-block"><h2>研究与专业活动</h2>${sectionHtml("研究与专业活动")}</section><section class="pr-block pr-wide"><h2>专业技能</h2>${sectionHtml("专业技能")}</section><section class="pr-block pr-wide"><h2>荣誉与认证</h2>${sectionHtml("荣誉与认证")}</section></div>`,
  ];
  return documentHtml("纸感高亮", "design_pirsch_analytics", css, pages);
}

function ditto() {
  const css = `
    :root { --page-bg:#f7f5f3; --text:#000; --paper:#fff; --warm:#575149; --line:#6a6559; --yellow:#ffdd33; --orange:#ff6137; --purple:#b26dc2; --blue:#0097e6; --pink:#f5c4cc; --page-pad:13mm 15mm 14mm; }
    body { font-family:Arial,"Helvetica Neue",sans-serif; font-size:9pt; line-height:1.45; }
    .resume-page { box-shadow:0 10px 30px rgba(34,34,34,.13); }
    .dt-top { display:flex; justify-content:space-between; margin-bottom:7mm; font:700 7pt ui-monospace,SFMono-Regular,Menlo,monospace; letter-spacing:.1em; text-transform:uppercase; }
    .dt-stage { position:relative; padding:6mm 0 4mm; border-top:2px solid #000; border-bottom:2px solid #000; }
    .dt-stage h1 { margin:0; font-size:34pt; line-height:.92; letter-spacing:-.065em; }
    .dt-stage h1 span { display:block; margin-top:3mm; font-size:14pt; line-height:1.1; letter-spacing:-.03em; }
    .dt-sticker { position:absolute; right:0; top:5mm; padding:2mm 4mm; border-radius:999px; background:var(--blue); color:#000; font-size:7pt; font-weight:900; transform:rotate(4deg); }
    .dt-contact { display:flex; flex-wrap:wrap; gap:2mm 5mm; margin-top:5mm; }
    .dt-contact span { font-size:7.4pt; }
    .dt-note { margin:5mm 0; padding:3mm 4mm; background:var(--paper); border:1px solid var(--line); border-radius:12px; font-size:7.2pt; }
    .dt-heading { display:flex; align-items:center; gap:3mm; margin:6mm 0 3mm; }
    .dt-heading h2,.dt-title { margin:0; font-size:19pt; line-height:1; letter-spacing:-.04em; }
    .dt-mark { display:inline-block; padding:1mm 3mm; border-radius:999px; background:var(--yellow); font-size:7pt; font-weight:900; transform:rotate(-2deg); }
    .dt-profile { display:grid; grid-template-columns:1.25fr .75fr; gap:4mm; }
    .dt-copy { padding:5mm; background:var(--paper); border:1px solid var(--line); border-radius:12px; }
    .dt-copy p { margin:0 0 2mm; }
    .dt-metrics { display:grid; gap:2mm; }
    .dt-metric { padding:3mm; border:2px solid #000; border-radius:999px; background:var(--yellow); }
    .dt-metric:nth-child(2) { background:var(--pink); transform:rotate(1deg); }
    .dt-metric:nth-child(3) { background:#d8c0df; transform:rotate(-1deg); }
    .dt-metric:nth-child(4) { background:#b8dff4; }
    .dt-metric strong { display:block; font-size:13pt; }
    .dt-metric span { font-size:7pt; }
    .dt-caps { display:grid; grid-template-columns:repeat(3,1fr); gap:3mm; }
    .dt-cap { padding:4mm; background:var(--paper); border:1px solid #000; border-radius:12px; }
    .dt-cap-no { display:inline-block; padding:3px 8px; border-radius:999px; background:var(--orange); color:#000; font-size:7pt; transform:rotate(-2deg); }
    .dt-cap-2 .dt-cap-no { background:var(--purple); }
    .dt-cap-3 .dt-cap-no { background:var(--blue); }
    .dt-cap h3 { margin:3mm 0 2mm; font-size:11pt; }
    .dt-cap ul { margin:0; padding-left:4mm; font-size:7.3pt; }
    .dt-page-head { display:flex; justify-content:space-between; align-items:end; margin-bottom:6mm; padding-bottom:3mm; border-bottom:2px solid #000; }
    .dt-page-head span { padding:1.5mm 3mm; border-radius:999px; background:var(--yellow); font-size:7pt; font-weight:700; }
    .dt-role { position:relative; margin-bottom:4mm; padding:5mm; background:var(--paper); border:1px solid var(--line); border-radius:12px; }
    .dt-role::after { content:"REVIEWED"; position:absolute; right:4mm; top:4mm; padding:1mm 2mm; border:2px solid var(--orange); color:#8a2307; font-size:7pt; font-weight:900; transform:rotate(3deg); }
    .dt-role h3,.dt-project h3 { margin:0 22mm 1mm 0; font-size:13pt; }
    .dt-role p,.dt-project p { margin:0 0 2mm; }
    .dt-role ul,.dt-project ul { margin:2mm 0 0; padding-left:5mm; }
    .dt-role li,.dt-project li { margin-bottom:.9mm; }
    .dt-project { margin-bottom:4mm; padding:5mm; background:var(--paper); border-left:7px solid var(--blue); border-radius:0 12px 12px 0; }
    .dt-project:nth-of-type(2) { border-left-color:var(--purple); }
    .dt-manage { margin-top:5mm; padding:5mm; border:2px solid #000; border-radius:12px; background:var(--yellow); }
    .dt-manage h2 { margin:0 0 2mm; font-size:15pt; }
    .dt-manage ul { margin:0; padding-left:5mm; columns:2; }
    .dt-grid { display:grid; grid-template-columns:1fr 1fr; gap:3mm; }
    .dt-block { padding:4mm; background:var(--paper); border:1px solid var(--line); border-radius:12px; }
    .dt-block h2 { display:inline-block; margin:0 0 3mm; padding:1mm 2mm; background:var(--pink); font-size:13pt; transform:rotate(-1deg); }
    .dt-block:nth-child(2) h2 { background:#b8dff4; }
    .dt-block p,.dt-block ul { margin:0 0 2mm; }
    .dt-wide { grid-column:1/-1; }
    .ditto-footer { position:absolute; left:15mm; right:15mm; bottom:5mm; display:flex; justify-content:space-between; padding-top:2mm; border-top:2px solid #000; color:var(--warm); font-size:7pt; }
  `;
  const pages = [
    `<header class="dt-top"><strong>MARKED-UP CAREER FILE</strong><span>2026</span></header><section class="dt-stage"><span class="dt-sticker">PROFILE / 2026</span><h1>${personName}<span>${roleName}</span></h1>${contacts("dt-contact")}</section>${note("dt-note")}<div class="dt-heading"><span class="dt-mark">PROFILE</span><h2>个人简介与成果</h2></div><section class="dt-profile"><div class="dt-copy">${sectionHtml("个人简介")}</div><div class="dt-metrics">${keyResults.map((item)=>`<div class="dt-metric"><strong>${metricValue(item)}</strong><span>${metricLabel(item)}</span></div>`).join("")}</div></section><div class="dt-heading"><span class="dt-mark">CAPABILITY</span><h2>核心能力</h2></div><section class="dt-caps">${capabilityCards("dt")}</section>`,
    `<header class="dt-page-head"><h1 class="dt-title">工作经历</h1><span>CAREER / 02</span></header>${work.map((_,i)=>`<section class="dt-role resume-item">${workHtml(i)}</section>`).join("")}`,
    `<header class="dt-page-head"><h1 class="dt-title">项目与管理</h1><span>PROJECT / 03</span></header>${projects.map((_,i)=>`<article class="dt-project project-item">${projectHtml(i)}</article>`).join("")}<section class="dt-manage"><h2>管理与组织经验</h2>${sectionHtml("管理与组织经验")}</section>`,
    `<header class="dt-page-head"><h1 class="dt-title">专业背景</h1><span>BACKGROUND / 04</span></header><div class="dt-grid"><section class="dt-block"><h2>教育与研究</h2>${sectionHtml("教育与研究")}</section><section class="dt-block"><h2>研究与专业活动</h2>${sectionHtml("研究与专业活动")}</section><section class="dt-block dt-wide"><h2>专业技能</h2>${sectionHtml("专业技能")}</section><section class="dt-block dt-wide"><h2>荣誉与认证</h2>${sectionHtml("荣誉与认证")}</section></div>`,
  ];
  return documentHtml("创意批注", "design_ditto", css, pages);
}

function caldera() {
  const css = `
    :root { --page-bg:#e2e2df; --text:#070607; --lime:#f7f6f2; --ember:#fc5000; --violet:#524ae9; --yellow:#f5f28e; --page-pad:12mm 14mm 14mm; }
    body { font-family:"DM Sans",Inter,ui-sans-serif,system-ui,sans-serif; font-size:9pt; line-height:1.42; font-weight:500; }
    .resume-page { box-shadow:0 10px 30px rgba(7,6,7,.15); }
    .cd-top { display:flex; justify-content:space-between; align-items:center; margin-bottom:6mm; font-size:7pt; text-transform:uppercase; letter-spacing:.12em; }
    .cd-top strong { padding:2mm 4mm; border:1.5px solid #070607; border-radius:999px; background:var(--lime); }
    .cd-hero { display:grid; grid-template-columns:1.25fr .75fr; gap:5mm; }
    .cd-name { padding:6mm; background:var(--ember); border-radius:32px; }
    .cd-name h1 { margin:0; font-family:Impact,"Arial Narrow",sans-serif; font-size:34pt; line-height:.92; letter-spacing:.02em; text-transform:uppercase; }
    .cd-name h1 span { display:block; margin-top:3mm; font:500 12pt/1.2 "DM Sans",sans-serif; letter-spacing:0; text-transform:none; }
    .cd-halftone { min-height:46mm; padding:6mm; border-radius:32px; color:#fff; background-color:var(--violet); background-image:radial-gradient(#fc5000 1.2px,transparent 1.2px); background-size:9px 9px; }
    .cd-halftone p { width:max-content; margin:0 0 3mm; padding:1mm 2mm; border-radius:6px; background:#302a91; font-size:8pt; }
    .cd-halftone strong { display:block; width:max-content; padding:2mm; border-radius:10px; background:#302a91; font-family:Impact,"Arial Narrow",sans-serif; font-size:23pt; letter-spacing:.03em; }
    .cd-contact { display:flex; flex-wrap:wrap; gap:2mm; margin:4mm 0; }
    .cd-contact span { padding:1.5mm 3mm; border:1.5px solid #070607; border-radius:999px; background:var(--lime); font-size:7.1pt; }
    .cd-note { margin:4mm 0; padding:3mm 4mm; border-radius:999px; background:var(--yellow); font-size:7.1pt; }
    .cd-title { margin:0; font-family:Impact,"Arial Narrow",sans-serif; font-size:22pt; line-height:1; letter-spacing:.03em; text-transform:uppercase; }
    .cd-profile { display:grid; grid-template-columns:1.25fr .75fr; gap:4mm; margin:4mm 0; }
    .cd-copy { padding:5mm; background:var(--lime); border-radius:28px; }
    .cd-copy p { margin:0 0 2mm; }
    .cd-metrics { display:grid; grid-template-columns:1fr 1fr; gap:2mm; }
    .cd-metric { padding:3mm; border-radius:20px; background:var(--ember); }
    .cd-metric:nth-child(2),.cd-metric:nth-child(3) { background:var(--yellow); }
    .cd-metric strong { display:block; font-family:Impact,"Arial Narrow",sans-serif; font-size:16pt; letter-spacing:.03em; }
    .cd-metric span { font-size:7pt; }
    .cd-caps { display:grid; grid-template-columns:repeat(3,1fr); gap:3mm; margin-top:4mm; }
    .cd-cap { padding:4mm; border-radius:28px; background:var(--lime); }
    .cd-cap-1 { background:var(--ember); }
    .cd-cap-no { display:inline-block; padding:3px 8px; border-radius:999px; background:var(--yellow); font-size:7pt; }
    .cd-cap h3 { margin:3mm 0 2mm; font-family:Impact,"Arial Narrow",sans-serif; font-size:13pt; letter-spacing:.03em; text-transform:uppercase; }
    .cd-cap ul { margin:0; padding-left:4mm; font-size:7.2pt; }
    .cd-head { display:flex; justify-content:space-between; align-items:end; margin-bottom:5mm; padding-bottom:3mm; border-bottom:2px dotted #070607; }
    .cd-head span { padding:1.5mm 3mm; background:var(--yellow); border-radius:999px; font-size:7pt; }
    .cd-role { margin-bottom:4mm; padding:5mm; background:var(--lime); border-radius:28px; }
    .cd-role:first-of-type { background:var(--ember); }
    .cd-role h3,.cd-project h3 { margin:0 0 1mm; font-family:Impact,"Arial Narrow",sans-serif; font-size:14pt; letter-spacing:.03em; text-transform:uppercase; }
    .cd-role p,.cd-project p { margin:0 0 2mm; }
    .cd-role ul,.cd-project ul { margin:2mm 0 0; padding-left:5mm; }
    .cd-role li,.cd-project li { margin-bottom:.9mm; }
    .cd-projects { display:grid; grid-template-columns:1.1fr .9fr; gap:4mm; }
    .cd-project { padding:5mm; background:var(--lime); border-radius:28px; }
    .cd-project:first-child { color:#fff; background:var(--violet); }
    .cd-manage { margin-top:5mm; padding:5mm; border-radius:28px; background:var(--ember); }
    .cd-manage h2 { margin:0 0 2mm; font-family:Impact,"Arial Narrow",sans-serif; font-size:17pt; letter-spacing:.03em; text-transform:uppercase; }
    .cd-manage ul { margin:0; padding-left:5mm; columns:2; }
    .cd-grid { display:grid; grid-template-columns:1fr 1fr; gap:3mm; }
    .cd-block { padding:5mm; background:var(--lime); border-radius:28px; }
    .cd-block h2 { margin:0 0 3mm; font-family:Impact,"Arial Narrow",sans-serif; font-size:15pt; letter-spacing:.03em; text-transform:uppercase; }
    .cd-block p,.cd-block ul { margin:0 0 2mm; }
    .cd-wide { grid-column:1/-1; }
    .caldera-footer { position:absolute; left:14mm; right:14mm; bottom:5mm; display:flex; justify-content:space-between; padding-top:2mm; border-top:2px dotted #070607; font-size:7pt; }
  `;
  const pages = [
    `<header class="cd-top"><strong>CAREER PROFILE</strong><span>2026</span></header><section class="cd-hero"><div class="cd-name"><h1>${personName}<span>${roleName}</span></h1></div><div class="cd-halftone"><p>AI PRODUCT</p><strong>9 YEARS<br>EXPERIENCE</strong></div></section>${contacts("cd-contact")}${note("cd-note")}<h2 class="cd-title">Profile & Impact</h2><section class="cd-profile"><div class="cd-copy">${sectionHtml("个人简介")}</div><div class="cd-metrics">${keyResults.map((item)=>`<div class="cd-metric"><strong>${metricValue(item)}</strong><span>${metricLabel(item)}</span></div>`).join("")}</div></section><section class="cd-caps">${capabilityCards("cd")}</section>`,
    `<header class="cd-head"><h1 class="cd-title">Work Experience</h1><span>02 / 04</span></header>${work.map((_,i)=>`<section class="cd-role resume-item">${workHtml(i)}</section>`).join("")}`,
    `<header class="cd-head"><h1 class="cd-title">Projects & Leadership</h1><span>03 / 04</span></header><div class="cd-projects">${projects.map((_,i)=>`<article class="cd-project project-item">${projectHtml(i)}</article>`).join("")}</div><section class="cd-manage"><h2>管理与组织经验</h2>${sectionHtml("管理与组织经验")}</section>`,
    `<header class="cd-head"><h1 class="cd-title">Background</h1><span>04 / 04</span></header><div class="cd-grid"><section class="cd-block"><h2>教育与研究</h2>${sectionHtml("教育与研究")}</section><section class="cd-block"><h2>研究与专业活动</h2>${sectionHtml("研究与专业活动")}</section><section class="cd-block cd-wide"><h2>专业技能</h2>${sectionHtml("专业技能")}</section><section class="cd-block cd-wide"><h2>荣誉与认证</h2>${sectionHtml("荣誉与认证")}</section></div>`,
  ];
  return documentHtml("工业海报", "design_caldera", css, pages);
}

const outputs = [
  ["design_officevibe", "温暖编辑", officevibe],
  ["design_hellotime", "极简数据", hellotime],
  ["design_uber", "黑白秩序", uber],
  ["design_perplexity", "研究手记", perplexity],
  ["design_intercom", "锐利编辑", intercom],
  ["design_pirsch_analytics", "纸感高亮", pirsch],
  ["design_ditto", "创意批注", ditto],
  ["design_caldera", "工业海报", caldera],
];

fs.mkdirSync(styleOutput, { recursive: true });
for (const [, name, renderer] of outputs) {
  fs.writeFileSync(path.join(styleOutput, previewFileName("视觉风格", name)), renderer(), "utf8");
}

const index = `<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>视觉风格预览 · 第二版</title><style>
*{box-sizing:border-box}*,*::before,*::after{animation:none!important;transition:none!important}html{scroll-behavior:auto}body{margin:0;background:#f1f3f6;color:#13213a;font-family:Inter,system-ui,sans-serif}main{width:min(calc(100% - 40px),1080px);margin:36px auto 72px}header{padding:28px;background:#fff;border:1px solid #d8dee8;border-radius:14px}h1{margin:0 0 8px;font-size:28px}p{margin:0;color:#58677b;line-height:1.6}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;margin-top:24px}a{display:block;padding:20px;background:#fff;border:1px solid #d8dee8;border-radius:12px;color:#13213a;text-decoration:none}a strong{display:block;margin-bottom:6px;font-size:18px}a span{color:#66758a;font-size:13px}@media(max-width:720px){main{width:min(calc(100% - 24px),1080px);margin-top:12px}.grid{grid-template-columns:1fr}}
</style></head><body><main><header><h1>视觉风格预览 · 第二版</h1><p>同一份虚拟基准简历、标准经历版式、四页 A4。每个风格独立构图，本轮只检查视觉风格，不包含版式与输出规格旧稿。</p></header><div class="grid">${outputs.map(([id,name])=>`<a href="visual-styles/${previewFileName("视觉风格", name)}"><strong>${name}</strong><span>${id} · 4 页 A4</span></a>`).join("")}</div></main></body></html>`;
if (process.argv.includes("--with-index")) fs.writeFileSync(path.join(outputRoot, "index.html"), index, "utf8");

console.log(`Generated ${outputs.length} independently composed visual-style previews.`);
