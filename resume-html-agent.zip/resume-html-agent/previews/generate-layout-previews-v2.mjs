#!/usr/bin/env node

import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const sourcePath = path.join(here, "source", "benchmark-resume-zh.md");
const outputRoot = path.join(here, "output");
const layoutOutput = path.join(outputRoot, "layouts");
const source = fs.readFileSync(sourcePath, "utf8").replace(/\r\n/g, "\n");

function previewFileName(type, optionName) {
  return `${type}-${optionName.replace(/\s+/g, "")}-预览简历.html`;
}

function esc(value) {
  return value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");
}

function inline(value) {
  return esc(value).replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>").replace(/`(.+?)`/g, "<code>$1</code>");
}

function markdown(markdownSource) {
  const out = [];
  let listOpen = false;
  let paragraph = [];
  const closeList = () => { if (listOpen) { out.push("</ul>"); listOpen = false; } };
  const closeParagraph = () => { if (paragraph.length) { out.push(`<p>${paragraph.join("")}</p>`); paragraph = []; } };
  const flush = () => { closeParagraph(); closeList(); };
  for (const original of markdownSource.trim().split("\n")) {
    const hardBreak = /\s{2,}$/.test(original);
    const line = original.trim();
    if (!line) { flush(); continue; }
    if (line === "---") { flush(); continue; }
    const heading = line.match(/^(#{1,3})\s+(.+)$/);
    if (heading) { flush(); out.push(`<h${heading[1].length}>${inline(heading[2])}</h${heading[1].length}>`); continue; }
    if (line.startsWith(">")) { flush(); out.push(`<p class="source-note">${inline(line.replace(/^>\s?/, ""))}</p>`); continue; }
    const bullet = line.match(/^[-*]\s+(.+)$/);
    if (bullet) {
      closeParagraph();
      if (!listOpen) { out.push("<ul>"); listOpen = true; }
      out.push(`<li>${inline(bullet[1])}</li>`);
      continue;
    }
    closeList();
    paragraph.push(`${inline(line)}${hardBreak ? "<br>" : " "}`);
  }
  flush();
  return out.join("\n");
}

function parseResume(raw) {
  const sectionMatches = [...raw.matchAll(/^##\s+(.+)$/gm)];
  const header = raw.slice(0, sectionMatches[0].index).trim();
  const sections = new Map();
  sectionMatches.forEach((match, index) => {
    const start = match.index + match[0].length;
    const end = index + 1 < sectionMatches.length ? sectionMatches[index + 1].index : raw.length;
    sections.set(match[1].trim(), raw.slice(start, end).trim());
  });
  return { header, sections };
}

function splitH3(raw) {
  return raw.split(/(?=^###\s+)/m).map((part) => part.trim()).filter(Boolean);
}

function bulletValues(raw) {
  return [...raw.matchAll(/^[-*]\s+(.+)$/gm)].map((match) => match[1]);
}

function groupedCapabilities(raw) {
  const groups = [];
  let current = null;
  for (const line of raw.split("\n")) {
    const title = line.trim().match(/^\*\*(.+?)\*\*$/);
    if (title) { current = { title: title[1], items: [] }; groups.push(current); continue; }
    const bullet = line.trim().match(/^[-*]\s+(.+)$/);
    if (bullet && current) current.items.push(bullet[1]);
  }
  return groups;
}

const parsed = parseResume(source);
const sections = parsed.sections;
const work = splitH3(sections.get("工作经历"));
const projects = splitH3(sections.get("代表项目"));
const capabilityGroups = groupedCapabilities(sections.get("核心能力"));
const keyResults = bulletValues(sections.get("关键成果"));
const title = source.match(/^#\s+(.+)$/m)[1];
const [personName, roleName] = title.split("｜");
const headerLines = parsed.header.split("\n")
  .map((line) => line.trim())
  .filter((line) => line && !line.startsWith("#") && !line.startsWith(">") && line !== "---")
  .map((line) => line.replace(/\\@/g, "@").replace(/\\$/, ""));
const sourceNote = [...parsed.header.matchAll(/^>\s?(.*)$/gm)].map((m) => m[1].replace(/\\$/, "")).join(" ");

const sectionHtml = (name) => markdown(sections.get(name));
const workHtml = (index) => markdown(work[index]);
const projectHtml = (index) => markdown(projects[index]);

function masthead(kicker = "") {
  return `<header class="masthead"><div class="identity">${kicker ? `<p class="kicker">${kicker}</p>` : ""}<h1>${personName}</h1><p class="role">${roleName}</p></div><div class="contact-list">${headerLines.map((line) => `<span>${inline(line)}</span>`).join("")}</div></header>`;
}

function sourceNotice() {
  return sourceNote ? `<p class="source-notice">${inline(sourceNote)}</p>` : "";
}

function sectionBlock(titleText, content, className = "") {
  return `<section class="content-section ${className}"><h2 class="section-title">${titleText}</h2><div class="section-body">${content}</div></section>`;
}

function capabilityList(className = "capability-list") {
  return `<div class="${className}">${capabilityGroups.map((group, index) => `<section class="capability-group"><p class="sequence">0${index + 1}</p><h3>${inline(group.title)}</h3><ul>${group.items.map((item) => `<li>${inline(item)}</li>`).join("")}</ul></section>`).join("")}</div>`;
}

function resultsTable(className = "results-table") {
  return `<div class="${className}">${keyResults.map((item, index) => `<div class="result-row"><span>0${index + 1}</span><p>${inline(item)}</p></div>`).join("")}</div>`;
}

function workList(indexes = work.map((_, index) => index), className = "experience-list") {
  return `<div class="${className}">${indexes.map((index) => `<section class="experience-item resume-item">${workHtml(index)}</section>`).join("")}</div>`;
}

function projectList(indexes = projects.map((_, index) => index), className = "project-list") {
  return `<div class="${className}">${indexes.map((index) => `<article class="project-item">${projectHtml(index)}</article>`).join("")}</div>`;
}

const printContract = `
  * { box-sizing: border-box; }
  *, *::before, *::after { animation: none !important; transition: none !important; }
  html { scroll-behavior: auto; background: #d9dde2; }
  body { margin: 0; background: #d9dde2; }
  @page { size: A4 portrait; margin: 0; }
  .resume-book { width: 210mm; margin: 16px auto; }
  .resume-page { position: relative; width: 210mm; height: 297mm; margin: 0 0 16px; padding: 13mm 16mm 15mm; background: #fff; color: #171a20; }
  .resume-page + .resume-page { break-before: page; page-break-before: always; }
  .resume-item, .project-item, .content-section { break-inside: avoid; page-break-inside: avoid; }
  .section-title { break-after: avoid; page-break-after: avoid; }
  @media print {
    html, body { margin: 0; background: #fff; }
    .resume-book { width: auto; margin: 0; }
    .resume-page { display: block; float: none; width: 210mm; height: 297mm; margin: 0; box-shadow: none; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    .resume-page + .resume-page { break-before: page; page-break-before: always; }
  }
`;

const neutralVisual = `
  :root { --ink:#171a20; --muted:#555d66; --accent:#264f78; --line:#aeb5bc; --soft:#edf0f2; --paper:#fff; }
  body { font-family:-apple-system,BlinkMacSystemFont,"Segoe UI","Noto Sans CJK SC",sans-serif; font-size:9.2pt; line-height:1.48; color:var(--ink); }
  .resume-page { box-shadow:0 8px 22px rgba(31,40,49,.12); }
  p { margin:0 0 2mm; }
  ul { margin:2mm 0 0; padding-left:5mm; }
  li { margin-bottom:.9mm; }
  strong { font-weight:700; }
  .masthead { display:grid; grid-template-columns:1.35fr .65fr; gap:10mm; align-items:start; margin-bottom:5mm; padding-bottom:5mm; border-bottom:1px solid var(--ink); }
  .kicker,.sequence { margin:0 0 2mm; color:var(--accent); font-size:7pt; font-weight:700; letter-spacing:.12em; text-transform:uppercase; }
  .identity h1 { margin:0; font:700 27pt/1.02 Georgia,"Songti SC",serif; letter-spacing:-.035em; }
  .role { margin:2mm 0 0; font-size:12.5pt; font-weight:600; }
  .contact-list { padding-top:1mm; }
  .contact-list span { display:block; margin-bottom:1.2mm; color:#343a41; font-size:7.4pt; }
  .source-notice { margin:0 0 5mm; padding:2.5mm 0; border-top:1px solid var(--line); border-bottom:1px solid var(--line); color:#444b53; font-size:7.2pt; }
  .section-title { margin:0 0 3mm; font:700 16pt/1.1 Georgia,"Songti SC",serif; letter-spacing:-.02em; }
  .section-body h3,.experience-item h3,.project-item h3 { margin:0 0 1mm; font-size:11.8pt; line-height:1.25; }
  .section-body p,.experience-item p,.project-item p { margin:0 0 1.8mm; }
  .content-section { margin-bottom:5mm; }
  .capability-list { display:grid; grid-template-columns:repeat(3,1fr); gap:6mm; }
  .capability-group { padding-top:3mm; border-top:1px solid var(--ink); }
  .capability-group h3 { margin:0 0 2mm; font-size:10.4pt; }
  .capability-group ul { margin:0; font-size:9pt; }
  .results-table { border-top:1px solid var(--ink); }
  .result-row { display:grid; grid-template-columns:10mm 1fr; gap:3mm; padding:2.2mm 0; border-bottom:1px solid var(--line); }
  .result-row > span { color:var(--accent); font-size:7pt; font-weight:700; }
  .result-row p { margin:0; }
  .experience-item,.project-item { padding:3.5mm 0; border-top:1px solid var(--line); }
  .experience-item:first-child,.project-item:first-child { border-top:1px solid var(--ink); }
  .page-heading { display:flex; justify-content:space-between; align-items:end; margin-bottom:5mm; padding-bottom:3mm; border-bottom:1px solid var(--ink); }
  .page-heading h1 { margin:0; font:700 20pt/1 Georgia,"Songti SC",serif; }
  .page-heading span { color:var(--muted); font-size:7pt; letter-spacing:.1em; }
  .page-footer { position:absolute; left:16mm; right:16mm; bottom:5mm; display:flex; justify-content:space-between; padding-top:2mm; border-top:1px solid var(--line); color:#4f565e; font-size:7pt; }
  .two-column { display:grid; grid-template-columns:1fr 1fr; gap:7mm; }
  .three-column { display:grid; grid-template-columns:repeat(3,1fr); gap:6mm; }
  .compact-text { font-size:9pt; line-height:1.42; }
`;

function pageHeading(titleText, label) {
  return `<header class="page-heading"><h1>${titleText}</h1><span>${label}</span></header>`;
}

function documentHtml(layoutName, layoutId, pages, css = "") {
  const total = pages.length;
  return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>简历版式-${layoutName.replace(/\s+/g, "")}-预览简历</title>
  <style>${printContract}${neutralVisual}${css}</style>
</head>
<body data-preview-layout="${layoutId}">
  <main class="resume-book" aria-label="${personName}简历">
    ${pages.map((content, index) => `<article class="resume-page">${content}<footer class="page-footer"><span>${personName} · ${roleName}</span><span>${String(index + 1).padStart(2, "0")} / ${String(total).padStart(2, "0")}</span></footer></article>`).join("\n")}
  </main>
</body>
</html>`;
}

function standardChronological() {
  const css = `
    .std-intro { display:grid; grid-template-columns:.75fr 1.25fr; gap:8mm; margin-bottom:5mm; }
    .std-intro .section-title { margin-top:1mm; }
    .std-results { display:grid; grid-template-columns:1fr 1fr; column-gap:7mm; }
    .std-results .result-row { grid-template-columns:8mm 1fr; }
    .std-projects { display:grid; grid-template-columns:1.05fr .95fr; gap:7mm; }
    .std-supplement { display:grid; grid-template-columns:1fr 1fr; gap:5mm 7mm; margin-top:5mm; }
    .std-supplement .content-section { margin:0; padding-top:3mm; border-top:1px solid var(--line); }
    .std-supplement .wide { grid-column:1/-1; }
    .std-supplement .section-title { font-size:12.5pt; }
  `;
  const pages = [
    `${masthead()}${sourceNotice()}<div class="std-intro"><h2 class="section-title">个人简介</h2><div>${sectionHtml("个人简介")}</div></div>${sectionBlock("核心能力", capabilityList())}${sectionBlock("关键成果", resultsTable("results-table std-results"))}`,
    `${pageHeading("工作经历", "EXPERIENCE")}${workList()}`,
    `${pageHeading("项目与专业背景", "PROJECTS & BACKGROUND")}<div class="std-projects">${projectList([0])}${projectList([1])}</div>${sectionBlock("管理与组织经验", sectionHtml("管理与组织经验"))}<div class="std-supplement"><section class="content-section"><h2 class="section-title">教育与研究</h2>${sectionHtml("教育与研究")}</section><section class="content-section"><h2 class="section-title">研究与专业活动</h2>${sectionHtml("研究与专业活动")}</section><section class="content-section wide"><h2 class="section-title">专业技能</h2>${sectionHtml("专业技能")}</section><section class="content-section wide"><h2 class="section-title">荣誉与认证</h2>${sectionHtml("荣誉与认证")}</section></div>`,
  ];
  return documentHtml("标准经历", "standard-chronological", pages, css);
}

function executiveImpact() {
  const css = `
    .exec-summary { display:grid; grid-template-columns:.72fr 1.28fr; gap:9mm; margin:5mm 0 6mm; }
    .exec-facts { display:grid; grid-template-columns:1fr 1fr; border-top:1px solid var(--ink); }
    .exec-facts .result-row { grid-template-columns:8mm 1fr; padding:3mm 4mm 3mm 0; }
    .exec-facts .result-row:nth-child(odd) { border-right:1px solid var(--line); }
    .exec-facts .result-row:nth-child(even) { padding-left:4mm; }
    .exec-scope { margin-top:6mm; padding:4mm 0; background:var(--soft); }
    .exec-scope .capability-list { padding:0 5mm; }
    .exec-current { display:grid; grid-template-columns:42mm 1fr; gap:7mm; }
    .exec-current .section-title { font-size:13pt; }
    .exec-current .experience-item { padding-top:0; border-top:0; }
    .exec-history { margin-top:7mm; }
    .exec-project-grid { display:grid; grid-template-columns:1.08fr .92fr; gap:7mm; }
    .exec-background { display:grid; grid-template-columns:1fr 1fr; gap:6mm 8mm; }
    .exec-background .content-section { margin:0; padding-top:3mm; border-top:1px solid var(--line); }
    .exec-background .wide { grid-column:1/-1; }
    .exec-background .section-title { font-size:13pt; }
  `;
  const pages = [
    `${masthead()}${sourceNotice()}<section class="exec-summary"><h2 class="section-title">职业摘要</h2><div>${sectionHtml("个人简介")}</div></section><h2 class="section-title">关键事实</h2>${resultsTable("results-table exec-facts")}<section class="exec-scope"><h2 class="section-title" style="padding:0 5mm">责任范围与核心能力</h2>${capabilityList()}</section>`,
    `${pageHeading("当前职责与职业路径", "EXPERIENCE")}<div class="exec-current"><h2 class="section-title">当前岗位</h2>${workList([0])}</div><div class="exec-history"><h2 class="section-title">历史工作经历</h2>${workList([1,2])}</div>`,
    `${pageHeading("项目与组织建设", "PROJECTS")}<div class="exec-project-grid">${projectList([0])}${projectList([1])}</div>${sectionBlock("管理与组织经验", sectionHtml("管理与组织经验"))}`,
    `${pageHeading("专业背景", "BACKGROUND")}<div class="exec-background"><section class="content-section"><h2 class="section-title">教育与研究</h2>${sectionHtml("教育与研究")}</section><section class="content-section"><h2 class="section-title">研究与专业活动</h2>${sectionHtml("研究与专业活动")}</section><section class="content-section wide"><h2 class="section-title">专业技能</h2>${sectionHtml("专业技能")}</section><section class="content-section wide"><h2 class="section-title">荣誉与认证</h2>${sectionHtml("荣誉与认证")}</section></div>`,
  ];
  return documentHtml("管理成果", "executive-impact", pages, css);
}

function projectLed() {
  const css = `
    .proj-opening { display:grid; grid-template-columns:1.2fr .8fr; gap:8mm; }
    .proj-opening .capability-list { display:block; }
    .proj-opening .capability-group { margin-bottom:4mm; }
    .proj-feature { padding:0 0 5mm; border-bottom:1px solid var(--ink); }
    .proj-feature h3 { font:700 17pt/1.15 Georgia,"Songti SC",serif; }
    .proj-feature p { max-width:156mm; }
    .proj-secondary { display:grid; grid-template-columns:1fr .72fr; gap:8mm; margin-top:6mm; }
    .proj-secondary .results-table { margin-top:0; }
    .proj-work { display:grid; grid-template-columns:1fr; }
    .proj-tail { display:grid; grid-template-columns:1fr 1fr; gap:6mm 8mm; }
    .proj-tail .content-section { margin:0; padding-top:3mm; border-top:1px solid var(--line); }
    .proj-tail .wide { grid-column:1/-1; }
    .proj-tail .section-title { font-size:13pt; }
  `;
  const pages = [
    `${masthead()}${sourceNotice()}<div class="proj-opening"><div>${sectionBlock("个人简介", sectionHtml("个人简介"))}</div><div>${sectionBlock("核心能力", capabilityList())}</div></div>`,
    `${pageHeading("代表项目", "SELECTED WORK")}<article class="proj-feature project-item">${projectHtml(0)}</article><div class="proj-secondary"><div>${projectList([1])}</div><div><h2 class="section-title">相关成果</h2>${resultsTable()}</div></div>`,
    `${pageHeading("工作经历", "EXPERIENCE")}<div class="proj-work">${workList()}</div>${sectionBlock("管理与组织经验", sectionHtml("管理与组织经验"))}`,
    `${pageHeading("教育、技能与活动", "BACKGROUND")}<div class="proj-tail"><section class="content-section"><h2 class="section-title">教育与研究</h2>${sectionHtml("教育与研究")}</section><section class="content-section"><h2 class="section-title">研究与专业活动</h2>${sectionHtml("研究与专业活动")}</section><section class="content-section wide"><h2 class="section-title">专业技能</h2>${sectionHtml("专业技能")}</section><section class="content-section wide"><h2 class="section-title">荣誉与认证</h2>${sectionHtml("荣誉与认证")}</section></div>`,
  ];
  return documentHtml("项目案例", "project-led", pages, css);
}

function technicalSkills() {
  const css = `
    .tech-page { display:grid; grid-template-columns:39mm 1fr; column-gap:8mm; }
    .tech-page > .tech-rail { padding-right:6mm; border-right:1px solid var(--line); }
    .tech-rail h2 { margin:0 0 3mm; font:700 13pt/1.15 Georgia,"Songti SC",serif; }
    .tech-rail p,.tech-rail li { font-size:8.8pt; }
    .tech-main .page-heading { margin-bottom:5mm; }
    .tech-summary { margin-bottom:6mm; }
    .tech-stack .section-body p { margin-bottom:2.5mm; }
    .tech-capabilities .capability-list { display:block; }
    .tech-capabilities .capability-group { margin-bottom:5mm; }
    .tech-results .result-row { grid-template-columns:8mm 1fr; }
    .tech-background { display:grid; grid-template-columns:1fr 1fr; gap:6mm 8mm; }
    .tech-background .content-section { margin:0; padding-top:3mm; border-top:1px solid var(--line); }
    .tech-background .wide { grid-column:1/-1; }
    .tech-background .section-title { font-size:13pt; }
  `;
  const pages = [
    `<div class="tech-page"><aside class="tech-rail"><h2>${personName}</h2><p>${roleName}</p><div class="contact-list">${headerLines.map((line) => `<span>${inline(line)}</span>`).join("")}</div></aside><main class="tech-main">${sourceNotice()}${sectionBlock("技术摘要", sectionHtml("个人简介"), "tech-summary")}${sectionBlock("技术栈与专业技能", sectionHtml("专业技能"), "tech-stack")}</main></div><div class="tech-page" style="margin-top:6mm"><aside class="tech-rail"><h2>专业能力</h2></aside><main class="tech-main tech-capabilities">${capabilityList()}</main></div>`,
    `<div class="tech-page"><aside class="tech-rail"><p class="kicker">02 / EXPERIENCE</p><h2>工作经历</h2><p>按时间倒序保留产品、数据与技术协同证据。</p></aside><main class="tech-main">${workList()}</main></div>`,
    `<div class="tech-page"><aside class="tech-rail"><p class="kicker">03 / PROJECTS</p><h2>技术项目与架构实践</h2><div class="tech-results">${resultsTable()}</div></aside><main class="tech-main">${projectList()}${sectionBlock("管理与组织经验", sectionHtml("管理与组织经验"))}</main></div>`,
    `<div class="tech-page"><aside class="tech-rail"><p class="kicker">04 / BACKGROUND</p><h2>教育、研究与认证</h2></aside><main class="tech-main"><div class="tech-background"><section class="content-section"><h2 class="section-title">教育与研究</h2>${sectionHtml("教育与研究")}</section><section class="content-section"><h2 class="section-title">研究与专业活动</h2>${sectionHtml("研究与专业活动")}</section><section class="content-section wide"><h2 class="section-title">荣誉与认证</h2>${sectionHtml("荣誉与认证")}</section></div></main></div>`,
  ];
  return documentHtml("技术能力", "technical-skills", pages, css);
}

function compactTwoColumn() {
  const css = `
    .compact-page { display:grid; grid-template-columns:minmax(0,1.8fr) minmax(0,1fr); gap:8mm; }
    .compact-main { min-width:0; }
    .compact-side { min-width:0; padding-left:7mm; border-left:1px solid var(--line); font-size:9pt; line-height:1.32; }
    .compact-side .content-section { margin-bottom:3mm; }
    .compact-side .section-title { font-size:12.5pt; }
    .compact-side .capability-list { display:block; }
    .compact-side .capability-group { margin-bottom:2.5mm; padding-top:2mm; }
    .compact-side .capability-group ul { font-size:9pt; }
    .compact-side .capability-group li { margin-bottom:.35mm; }
    .compact-side .contact-list { margin-bottom:3mm; }
    .compact-side .contact-list span { margin-bottom:.6mm; }
    .compact-main .identity { margin-bottom:4mm; padding-bottom:4mm; border-bottom:1px solid var(--ink); }
    .compact-main .identity h1 { font:700 24pt/1 Georgia,"Songti SC",serif; }
    .compact-main .section-title { font-size:14pt; }
    .compact-main .experience-item,.compact-main .project-item { padding:3mm 0; }
    .compact-side .result-row { display:block; padding:1.2mm 0; }
    .compact-side .result-row > span { display:block; margin-bottom:.5mm; }
    .compact-side .source-notice { font-size:7pt; }
    .compact-side .section-body h3 { font-size:10.5pt; }
  `;
  const pages = [
    `<div class="compact-page"><main class="compact-main"><div class="identity"><h1>${personName}</h1><p class="role">${roleName}</p></div>${sectionBlock("个人简介", sectionHtml("个人简介"))}${sectionBlock("工作经历", workList([0,1]))}</main><aside class="compact-side">${sourceNotice()}<div class="contact-list">${headerLines.map((line) => `<span>${inline(line)}</span>`).join("")}</div>${sectionBlock("核心能力", capabilityList())}${sectionBlock("关键成果", resultsTable())}</aside></div>`,
    `<div class="compact-page"><main class="compact-main">${pageHeading("项目与履历", "02 / 02")}${workList([2])}${projectList()}${sectionBlock("管理与组织经验", sectionHtml("管理与组织经验"))}</main><aside class="compact-side">${sectionBlock("教育与研究", sectionHtml("教育与研究"))}${sectionBlock("专业技能", sectionHtml("专业技能"))}${sectionBlock("研究与专业活动", sectionHtml("研究与专业活动"))}${sectionBlock("荣誉与认证", sectionHtml("荣誉与认证"))}</aside></div>`,
  ];
  return documentHtml("紧凑双栏", "compact-two-column", pages, css);
}

function academicResearch() {
  const css = `
    .academic-page { font-family:Georgia,"Songti SC","Noto Serif CJK SC",serif; }
    .academic-page .masthead { grid-template-columns:1.2fr .8fr; }
    .academic-page .contact-list,.academic-page .source-notice,.academic-page .page-footer { font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; }
    .academic-lead { display:grid; grid-template-columns:.68fr 1.32fr; gap:9mm; margin-bottom:6mm; }
    .academic-entry { display:grid; grid-template-columns:10mm 1fr; gap:4mm; padding:4mm 0; border-top:1px solid var(--line); }
    .academic-entry > span { color:var(--accent); font:700 8pt/1.4 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif; }
    .academic-entry h3 { margin:0 0 1mm; font-size:12pt; }
    .academic-columns { display:grid; grid-template-columns:1fr 1fr; gap:8mm; }
    .academic-columns .content-section { margin:0; }
    .academic-results .result-row { grid-template-columns:8mm 1fr; }
    .academic-capabilities { display:grid; grid-template-columns:1fr 1fr; gap:7mm; }
    .academic-capabilities .capability-list { display:contents; }
    .academic-capabilities .capability-group:last-child { grid-column:1/-1; }
  `;
  const pages = [
    `<div class="academic-page">${masthead()}${sourceNotice()}<section class="academic-lead"><h2 class="section-title">专业与研究方向</h2><div>${sectionHtml("个人简介")}</div></section>${sectionBlock("教育与研究", sectionHtml("教育与研究"))}</div>`,
    `<div class="academic-page">${pageHeading("研究、项目与专业活动", "RESEARCH")}<div class="academic-columns"><div>${sectionBlock("研究与专业活动", sectionHtml("研究与专业活动"))}</div><div>${projectList()}</div></div></div>`,
    `<div class="academic-page">${pageHeading("职业与实践经历", "PRACTICE")}${workList()}${sectionBlock("管理与组织经验", sectionHtml("管理与组织经验"))}</div>`,
    `<div class="academic-page">${pageHeading("专业能力与认证", "BACKGROUND")}<div class="academic-columns"><section><h2 class="section-title">专业技能</h2>${sectionHtml("专业技能")}</section><section class="academic-results"><h2 class="section-title">实践成果</h2>${resultsTable()}</section></div><section class="academic-capabilities" style="margin-top:7mm"><h2 class="section-title" style="grid-column:1/-1">核心能力</h2>${capabilityList()}</section>${sectionBlock("荣誉与认证", sectionHtml("荣誉与认证"))}</div>`,
  ];
  return documentHtml("学术研究", "academic-research", pages, css);
}

const outputs = [
  ["standard-chronological", "标准经历", standardChronological],
  ["executive-impact", "管理成果", executiveImpact],
  ["project-led", "项目案例", projectLed],
  ["technical-skills", "技术能力", technicalSkills],
  ["compact-two-column", "紧凑双栏", compactTwoColumn],
  ["academic-research", "学术研究", academicResearch],
];

fs.mkdirSync(layoutOutput, { recursive: true });
for (const [, name, render] of outputs) {
  fs.writeFileSync(path.join(layoutOutput, previewFileName("简历版式", name)), render(), "utf8");
}

const visualEntries = [
  ["design_officevibe", "温暖编辑"], ["design_hellotime", "极简数据"], ["design_uber", "黑白秩序"], ["design_perplexity", "研究手记"],
  ["design_intercom", "锐利编辑"], ["design_pirsch_analytics", "纸感高亮"], ["design_ditto", "创意批注"], ["design_caldera", "工业海报"],
];

const indexHtml = `<!doctype html>
<html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>简历预览资产 · 第二版</title><style>
*{box-sizing:border-box}*,*::before,*::after{animation:none!important;transition:none!important}html{scroll-behavior:auto}body{margin:0;background:#f1f3f6;color:#13213a;font-family:Inter,system-ui,sans-serif}main{width:min(calc(100% - 40px),1080px);margin:36px auto 72px}header{padding:28px;background:#fff;border:1px solid #d8dee8;border-radius:14px}h1{margin:0 0 8px;font-size:28px}h2{margin:30px 0 8px;font-size:20px}p{margin:0;color:#58677b;line-height:1.6}.grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;margin-top:16px}a{display:block;padding:20px;background:#fff;border:1px solid #d8dee8;border-radius:12px;color:#13213a;text-decoration:none}a strong{display:block;margin-bottom:6px;font-size:18px}a span{color:#66758a;font-size:13px}.note{margin-top:6px;font-size:13px}@media(max-width:720px){main{width:min(calc(100% - 24px),1080px);margin-top:12px}.grid{grid-template-columns:1fr}}
</style></head><body><main><header><h1>简历预览资产 · 第二版</h1><p>共用同一份虚拟基准简历。视觉风格组固定标准经历版式；简历版式组固定中性编辑风格和 A4 输出。</p></header><h2>视觉风格</h2><p class="note">8 份独立视觉构图，均为 4 页 A4。</p><div class="grid">${visualEntries.map(([id,name]) => `<a href="visual-styles/${previewFileName("视觉风格", name)}"><strong>${name}</strong><span>${id} · 4 页 A4</span></a>`).join("")}</div><h2>简历版式</h2><p class="note">6 种信息结构，不使用大量圆角卡片或单边粗色条。页数按版式和内容密度自动决定。</p><div class="grid">${outputs.map(([id,name,render]) => { const pages = (render().match(/class="resume-page"/g) || []).length; return `<a href="layouts/${previewFileName("简历版式", name)}"><strong>${name}</strong><span>${id} · ${pages} 页 A4</span></a>`; }).join("")}</div></main></body></html>`;

if (process.argv.includes("--with-index")) fs.writeFileSync(path.join(outputRoot, "index.html"), indexHtml, "utf8");
console.log("Generated 6 layout previews with one restrained neutral visual system.");
