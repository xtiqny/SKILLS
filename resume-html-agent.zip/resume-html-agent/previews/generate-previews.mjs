#!/usr/bin/env node

import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const here = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.dirname(here);
const sourcePath = path.join(here, "source", "benchmark-resume-zh.md");
const outputRoot = path.join(here, "output");
const source = fs.readFileSync(sourcePath, "utf8").replace(/\r\n/g, "\n");

const styleProfiles = {
  design_officevibe: {
    name: "温暖编辑",
    canvas: "#ece9e4",
    paper: "#f9f8f6",
    ink: "#171417",
    muted: "#65606a",
    accent: "#2545ff",
    accentSoft: "#eaebf8",
    border: "#8d847c",
    dark: "#0c1754",
    onDark: "#ffffff",
    noteText: "#2e2a34",
    radius: "16px",
    smallRadius: "999px",
    headingFont: "Georgia, 'Times New Roman', serif",
    bodyFont: "Inter, ui-sans-serif, system-ui, -apple-system, 'Segoe UI', sans-serif",
    headingWeight: "500",
    extra: `
      .identity h1 { font-style: italic; letter-spacing: -.035em; }
      .resume-section > h2::after { content: ""; display: inline-block; width: 22px; height: 3px; margin-left: 8px; background: var(--accent); vertical-align: middle; border-radius: 9px; }
      .section-key-results li { border-color: #c9cffa; }
    `,
  },
  design_hellotime: {
    name: "极简数据",
    canvas: "#eceef2",
    paper: "#ffffff",
    ink: "#151619",
    muted: "#5f6570",
    accent: "#0560fd",
    accentSoft: "#eef4ff",
    border: "#8a8f99",
    dark: "#25272d",
    onDark: "#ffffff",
    noteText: "#333740",
    radius: "14px",
    smallRadius: "8px",
    headingFont: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
    bodyFont: "-apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif",
    headingWeight: "750",
    extra: `
      .identity h1 { font-size: 27pt; letter-spacing: -.055em; }
      .resume-section > h2 { border-bottom: 2px solid var(--ink); padding-bottom: 3px; }
      .section-key-results strong, .resume-section li strong { color: #034fcf; }
    `,
  },
  design_uber: {
    name: "黑白秩序",
    canvas: "#dedede",
    paper: "#ffffff",
    ink: "#000000",
    muted: "#4f4f4f",
    accent: "#000000",
    accentSoft: "#f2f2f2",
    border: "#767676",
    dark: "#000000",
    onDark: "#ffffff",
    noteText: "#111111",
    radius: "8px",
    smallRadius: "8px",
    headingFont: "Arial, Helvetica, sans-serif",
    bodyFont: "Arial, Helvetica, sans-serif",
    headingWeight: "700",
    identityDark: true,
    extra: `
      .identity { margin: -12mm -14mm 6mm; padding: 11mm 14mm 7mm; background: #000000; color: #ffffff; border-radius: 0; }
      .identity p, .identity h1, .identity a { color: #ffffff; }
      .identity .source-note { background: #ffffff; color: #111111; border-color: #ffffff; }
      .resume-section > h2 { border-bottom: 1px solid #000000; }
      .section-key-results li { border: 1px solid #000000; }
    `,
  },
  design_perplexity: {
    name: "研究手记",
    canvas: "#e9e6e0",
    paper: "#faf8f5",
    ink: "#27251e",
    muted: "#64625c",
    accent: "#016a71",
    accentSoft: "#e6f1ef",
    border: "#8f8d85",
    dark: "#27251e",
    onDark: "#ffffff",
    noteText: "#333129",
    radius: "16px",
    smallRadius: "999px",
    headingFont: "Avenir Next, Avenir, ui-sans-serif, system-ui, sans-serif",
    bodyFont: "Avenir Next, Avenir, ui-sans-serif, system-ui, sans-serif",
    headingWeight: "600",
    extra: `
      .identity { border-left: 6px solid var(--accent); }
      .resume-section > h2 { font-size: 10.5pt; letter-spacing: .02em; color: #016a71; }
      .resume-item { border-left: 1px solid var(--border); padding-left: 10px; }
    `,
  },
  design_intercom: {
    name: "锐利编辑",
    canvas: "#e7e3dd",
    paper: "#faf9f6",
    ink: "#111111",
    muted: "#555555",
    accent: "#0007cb",
    accentSoft: "#eeeee9",
    border: "#8f8a82",
    dark: "#111111",
    onDark: "#ffffff",
    noteText: "#333333",
    radius: "4px",
    smallRadius: "4px",
    headingFont: "Inter, 'Helvetica Neue', Arial, sans-serif",
    bodyFont: "Inter, 'Helvetica Neue', Arial, sans-serif",
    headingWeight: "300",
    extra: `
      .identity h1 { font-weight: 300; letter-spacing: -.05em; }
      .resume-section > h2 { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: 8.5pt; letter-spacing: .16em; text-transform: uppercase; color: #0007cb; }
      .resume-section > h3, .resume-item h3 { font-weight: 400; }
      .section-key-results li { border-radius: 4px; }
    `,
  },
  design_pirsch_analytics: {
    name: "纸感高亮",
    canvas: "#e8e2d5",
    paper: "#f8f5ed",
    ink: "#000000",
    muted: "#565656",
    accent: "#d69e00",
    accentSoft: "#ffda6e",
    border: "#000000",
    dark: "#000000",
    onDark: "#ffffff",
    noteText: "#1f1f1f",
    radius: "24px",
    smallRadius: "999px",
    headingFont: "'DM Sans', Inter, ui-sans-serif, system-ui, sans-serif",
    bodyFont: "'DM Sans', Inter, ui-sans-serif, system-ui, sans-serif",
    headingWeight: "600",
    extra: `
      .identity { border: 1px solid #000000; }
      .resume-section > h2 { display: inline-block; background: #ffda6e; color: #000000; padding: 3px 8px; border: 1px solid #000000; border-radius: 999px; }
      .section-key-results li { border: 1px solid #000000; box-shadow: 4px 4px 0 #ffda6e; }
      strong { color: #000000; }
    `,
  },
  design_ditto: {
    name: "创意批注",
    canvas: "#e6e0da",
    paper: "#f7f5f3",
    ink: "#000000",
    muted: "#575149",
    accent: "#3e6b15",
    accentSoft: "#ffdd33",
    border: "#222222",
    dark: "#000000",
    onDark: "#ffffff",
    noteText: "#25211d",
    radius: "12px",
    smallRadius: "999px",
    headingFont: "Arial Rounded MT Bold, Arial, sans-serif",
    bodyFont: "Arial, Helvetica, sans-serif",
    headingWeight: "800",
    extra: `
      .identity h1 { letter-spacing: -.05em; }
      .resume-section > h2 { display: inline-block; padding: 1px 6px 2px; background: #ffdd33; color: #000000; transform: rotate(-.35deg); }
      .resume-section:nth-of-type(4n+2) > h2 { background: #f5c4cc; }
      .resume-section:nth-of-type(4n+3) > h2 { background: #b8d8f0; }
      .resume-section:nth-of-type(4n) > h2 { background: #d7c0df; }
      .section-key-results li { border-width: 2px; }
    `,
  },
  design_caldera: {
    name: "工业海报",
    canvas: "#c9c9c5",
    paper: "#e2e2df",
    ink: "#070607",
    muted: "#4a4947",
    accent: "#d94700",
    accentSoft: "#f5f28e",
    border: "#070607",
    dark: "#524ae9",
    onDark: "#ffffff",
    noteText: "#242320",
    radius: "28px",
    smallRadius: "999px",
    headingFont: "Impact, 'Arial Narrow', sans-serif",
    bodyFont: "'DM Sans', Inter, ui-sans-serif, system-ui, sans-serif",
    headingWeight: "800",
    extra: `
      .identity { background-color: #fc5000; background-image: radial-gradient(#070607 0.7px, transparent 0.7px); background-size: 8px 8px; border: 2px solid #070607; }
      .identity h1 { font-family: Impact, 'Arial Narrow', sans-serif; font-size: 28pt; letter-spacing: .015em; text-transform: uppercase; }
      .resume-section > h2 { font-family: Impact, 'Arial Narrow', sans-serif; font-size: 13pt; letter-spacing: .035em; text-transform: uppercase; }
      .section-capabilities > p strong { color: #070607; text-decoration: underline; text-decoration-color: #fc5000; text-decoration-thickness: 2px; }
      .section-key-results li { background: #fc5000; color: #070607; border: 2px solid #070607; }
      .section-key-results li:nth-child(2), .section-key-results li:nth-child(4) { background: #f5f28e; }
    `,
  },
};

const layoutNames = {
  "standard-chronological": "标准经历",
  "executive-impact": "管理成果",
  "project-led": "项目案例",
  "technical-skills": "技术能力",
  "compact-two-column": "紧凑双栏",
  "academic-research": "学术研究",
};

const formatNames = {
  "screen-continuous": "网页浏览",
  "print-a4": "A4 打印",
  "slides-4x3": "4:3 演示分页",
  "slides-16x9": "16:9 演示分页",
};

function escapeHtml(value) {
  return value
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;");
}

function inlineMarkdown(value) {
  return escapeHtml(value)
    .replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>")
    .replace(/`(.+?)`/g, "<code>$1</code>");
}

function markdownToHtml(markdown) {
  const lines = markdown.trim().split("\n");
  const out = [];
  let paragraph = [];
  let inList = false;
  let quote = [];

  const closeList = () => {
    if (inList) {
      out.push("</ul>");
      inList = false;
    }
  };
  const flushParagraph = () => {
    if (!paragraph.length) return;
    out.push(`<p>${paragraph.join("")}</p>`);
    paragraph = [];
  };
  const flushQuote = () => {
    if (!quote.length) return;
    out.push(`<div class="source-note">${quote.join("<br>")}</div>`);
    quote = [];
  };
  const flushAll = () => {
    flushParagraph();
    flushQuote();
    closeList();
  };

  for (const original of lines) {
    const raw = original.replace(/\s+$/, (space) => space.includes("  ") ? "  " : "");
    const line = raw.trim();
    if (!line) {
      flushAll();
      continue;
    }
    if (line === "---") {
      flushAll();
      out.push("<hr>");
      continue;
    }
    const heading = line.match(/^(#{1,3})\s+(.+)$/);
    if (heading) {
      flushAll();
      const level = heading[1].length;
      out.push(`<h${level}>${inlineMarkdown(heading[2])}</h${level}>`);
      continue;
    }
    if (line.startsWith(">")) {
      flushParagraph();
      closeList();
      quote.push(inlineMarkdown(line.replace(/^>\s?/, "")));
      continue;
    }
    const bullet = line.match(/^[-*]\s+(.+)$/);
    if (bullet) {
      flushParagraph();
      flushQuote();
      if (!inList) {
        out.push("<ul>");
        inList = true;
      }
      out.push(`<li>${inlineMarkdown(bullet[1])}</li>`);
      continue;
    }
    flushQuote();
    closeList();
    paragraph.push(`${inlineMarkdown(line)}${raw.endsWith("  ") ? "<br>" : " "}`);
  }
  flushAll();
  return out.join("\n");
}

function parseResume(markdown) {
  const matches = [...markdown.matchAll(/^##\s+(.+)$/gm)];
  const header = markdown.slice(0, matches[0].index).trim().replace(/\n---\s*$/, "");
  const sections = new Map();
  matches.forEach((match, index) => {
    const start = match.index + match[0].length;
    const end = index + 1 < matches.length ? matches[index + 1].index : markdown.length;
    sections.set(match[1].trim(), markdown.slice(start, end).trim());
  });
  return { header, sections };
}

const resume = parseResume(source);

function splitH3(markdown) {
  return markdown
    .split(/(?=^###\s+)/m)
    .map((chunk) => chunk.trim())
    .filter(Boolean);
}

const workChunks = splitH3(resume.sections.get("工作经历"));
const projectChunks = splitH3(resume.sections.get("代表项目"));

const sectionClasses = {
  "个人简介": "section-profile",
  "核心能力": "section-capabilities",
  "关键成果": "section-key-results",
  "工作经历": "section-work",
  "代表项目": "section-projects",
  "管理与组织经验": "section-management",
  "教育与研究": "section-education",
  "研究与专业活动": "section-research",
  "专业技能": "section-skills",
  "荣誉与认证": "section-honors",
};

function renderSection(name) {
  const raw = resume.sections.get(name);
  if (!raw) return "";
  return `<section class="resume-section ${sectionClasses[name] || ""}">
    <h2>${escapeHtml(name)}</h2>
    ${markdownToHtml(raw)}
  </section>`;
}

function renderChunkSection(name, chunks) {
  return `<section class="resume-section ${sectionClasses[name] || ""}">
    <h2>${escapeHtml(name)}</h2>
    ${chunks.map((chunk) => `<article class="resume-item">${markdownToHtml(chunk)}</article>`).join("\n")}
  </section>`;
}

function renderHeader() {
  return `<header class="identity">${markdownToHtml(resume.header)}</header>`;
}

function renderAllSections() {
  return [
    "个人简介",
    "核心能力",
    "关键成果",
    "工作经历",
    "代表项目",
    "管理与组织经验",
    "教育与研究",
    "研究与专业活动",
    "专业技能",
    "荣誉与认证",
  ].map(renderSection).join("\n");
}

function a4PagesForLayout(layoutId) {
  const s = renderSection;
  const work = (chunks) => renderChunkSection("工作经历", chunks);
  const projects = (chunks) => renderChunkSection("代表项目", chunks);

  switch (layoutId) {
    case "executive-impact":
      return [
        `${renderHeader()}${s("个人简介")}${s("关键成果")}${s("核心能力")}${work(workChunks.slice(0, 1))}${s("管理与组织经验")}`,
        `${work(workChunks.slice(1))}${projects(projectChunks)}${s("教育与研究")}${s("研究与专业活动")}${s("专业技能")}${s("荣誉与认证")}`,
      ];
    case "project-led":
      return [
        `${renderHeader()}${s("个人简介")}${s("核心能力")}${projects(projectChunks)}${s("关键成果")}`,
        `${work(workChunks)}${s("管理与组织经验")}${s("教育与研究")}${s("研究与专业活动")}${s("专业技能")}${s("荣誉与认证")}`,
      ];
    case "technical-skills":
      return [
        `${renderHeader()}${s("个人简介")}${s("专业技能")}${s("核心能力")}${work(workChunks.slice(0, 1))}${projects(projectChunks.slice(0, 1))}`,
        `${work(workChunks.slice(1))}${projects(projectChunks.slice(1))}${s("关键成果")}${s("管理与组织经验")}${s("教育与研究")}${s("研究与专业活动")}${s("荣誉与认证")}`,
      ];
    case "compact-two-column":
      return [
        `${renderHeader()}<div class="layout-columns compact-layout"><aside>${s("专业技能")}${s("教育与研究")}</aside><main>${s("个人简介")}${s("关键成果")}${work(workChunks.slice(0, 2))}</main></div>`,
        `<div class="layout-columns compact-layout"><aside>${s("研究与专业活动")}${s("荣誉与认证")}</aside><main>${work(workChunks.slice(2))}${projects(projectChunks)}${s("管理与组织经验")}${s("核心能力")}</main></div>`,
      ];
    case "academic-research":
      return [
        `${renderHeader()}${s("个人简介")}${s("教育与研究")}${s("研究与专业活动")}${projects(projectChunks)}`,
        `${work(workChunks)}${s("核心能力")}${s("关键成果")}${s("管理与组织经验")}${s("专业技能")}${s("荣誉与认证")}`,
      ];
    case "standard-chronological":
    default:
      return [
        `${renderHeader()}${s("个人简介")}${s("核心能力")}${s("关键成果")}${work(workChunks.slice(0, 1))}`,
        `${work(workChunks.slice(1))}${projects(projectChunks)}${s("管理与组织经验")}${s("教育与研究")}${s("研究与专业活动")}${s("专业技能")}${s("荣誉与认证")}`,
      ];
  }
}

function cssVariables(profile) {
  return `
    :root {
      --canvas: ${profile.canvas};
      --paper: ${profile.paper};
      --ink: ${profile.ink};
      --muted: ${profile.muted};
      --accent: ${profile.accent};
      --accent-soft: ${profile.accentSoft};
      --border: ${profile.border};
      --dark: ${profile.dark};
      --on-dark: ${profile.onDark};
      --note-text: ${profile.noteText};
      --radius: ${profile.radius};
      --small-radius: ${profile.smallRadius};
      --heading-font: ${profile.headingFont};
      --body-font: ${profile.bodyFont};
      --heading-weight: ${profile.headingWeight};
    }
  `;
}

function commonCss(profile) {
  return `
    ${cssVariables(profile)}
    * { box-sizing: border-box; }
    *, *::before, *::after { animation: none !important; transition: none !important; }
    html { scroll-behavior: auto; background: var(--canvas); }
    body { margin: 0; min-width: 0; background: var(--canvas); color: var(--ink); font-family: var(--body-font); font-size: 14px; line-height: 1.4; }
    h1, h2, h3 { margin: 0; color: var(--ink); font-family: var(--heading-font); font-weight: var(--heading-weight); break-after: avoid; page-break-after: avoid; }
    h1 { font-size: 32px; line-height: 1.02; letter-spacing: -.035em; }
    h2 { margin-bottom: 2.5mm; font-size: 15px; line-height: 1.12; }
    h3 { margin-bottom: 1mm; font-size: 13px; line-height: 1.2; }
    p { margin: 0 0 1.5mm; }
    ul { margin: 1mm 0 0; padding-left: 4.5mm; }
    li { margin: 0 0 .8mm; padding-left: .5mm; }
    strong { font-weight: 700; }
    code { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: .92em; }
    hr { display: none; }
    .identity { margin-bottom: 5mm; padding: 5mm; color: var(--ink); background: var(--accent-soft); border: 1px solid var(--border); border-radius: var(--radius); }
    .identity h1 { margin-bottom: 2.5mm; }
    .identity p { color: inherit; }
    .identity p:last-child { margin-bottom: 0; }
    .source-note { margin: 0 0 2.5mm; padding: 2.2mm 3mm; color: var(--note-text); background: var(--paper); border: 1px solid var(--border); border-radius: var(--small-radius); font-size: 11px; line-height: 1.35; }
    .resume-section { margin-bottom: 4mm; }
    .resume-section:last-child { margin-bottom: 0; }
    .resume-item, .project-item { margin-bottom: 3mm; break-inside: avoid; page-break-inside: avoid; }
    .resume-item:last-child { margin-bottom: 0; }
    .resume-item > p:first-of-type { color: var(--muted); }
    .section-profile p { max-width: 96%; }
    .section-capabilities > p { margin-top: 2mm; color: var(--ink); }
    .section-capabilities > p strong { color: var(--accent); }
    .section-key-results ul { display: grid; grid-template-columns: 1fr 1fr; gap: 2mm; padding: 0; list-style: none; }
    .section-key-results li { margin: 0; padding: 2.2mm 2.6mm; color: var(--ink); background: var(--accent-soft); border: 1px solid var(--border); border-radius: var(--small-radius); }
    .section-skills p { margin-bottom: 1mm; }
    .layout-columns { display: grid; grid-template-columns: minmax(0, .34fr) minmax(0, .66fr); gap: 6mm; align-items: start; }
    .compact-layout aside { padding: 4mm; color: var(--ink); background: var(--accent-soft); border: 1px solid var(--border); border-radius: var(--radius); }
    .compact-layout aside .resume-section { margin-bottom: 5mm; }
    .page-footer, .slide-footer { color: var(--muted); font-size: 10px; letter-spacing: .04em; }
    ${profile.extra || ""}
  `;
}

function htmlDocument({ title, styleId, body, formatCss = "", bodyClass = "" }) {
  const profile = styleProfiles[styleId];
  return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${escapeHtml(title)}</title>
  <style>
    ${commonCss(profile)}
    ${formatCss}
  </style>
</head>
<body class="${bodyClass}" data-preview-style="${styleId}">
${body}
</body>
</html>
`;
}

function a4Css() {
  return `
    @page { size: A4 portrait; margin: 0; }
    body { font-size: 9pt; }
    h1 { font-size: 24pt; }
    h2 { font-size: 11.5pt; }
    h3 { font-size: 10pt; }
    .source-note { font-size: 7.4pt; }
    .resume-book { width: 210mm; margin: 18px auto; }
    .resume-page { position: relative; width: 210mm; height: 297mm; margin: 0 auto 18px; padding: 12mm 14mm 13mm; background: var(--paper); box-shadow: 0 10px 28px rgba(20, 20, 25, .14); }
    .resume-page + .resume-page { break-before: page; page-break-before: always; }
    .page-footer { position: absolute; right: 14mm; bottom: 5mm; left: 14mm; display: flex; justify-content: space-between; border-top: 1px solid var(--border); padding-top: 2mm; font-size: 7pt; }
    @media print {
      html, body { margin: 0; background: #ffffff; }
      .resume-book { display: block; width: auto; margin: 0; }
      .resume-page { display: block; position: relative; float: none; width: 210mm; height: 297mm; margin: 0; box-shadow: none; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
      .resume-page + .resume-page { break-before: page; page-break-before: always; }
    }
  `;
}

function renderA4({ title, styleId, layoutId }) {
  const pages = a4PagesForLayout(layoutId);
  const body = `<main class="resume-book" data-layout="${layoutId}">
    ${pages.map((content, index) => `<article class="resume-page">
      ${content}
      <footer class="page-footer"><span>周予安｜AI 产品与增长负责人</span><span>${index + 1} / ${pages.length}</span></footer>
    </article>`).join("\n")}
  </main>`;
  return htmlDocument({ title, styleId, body, formatCss: a4Css(), bodyClass: "format-print-a4" });
}

function screenCss() {
  return `
    body { font-size: 15px; line-height: 1.58; }
    .resume-document { width: min(calc(100% - 40px), 980px); margin: 32px auto; padding: 48px 56px; background: var(--paper); border: 1px solid var(--border); border-radius: var(--radius); box-shadow: 0 14px 42px rgba(20, 20, 25, .12); }
    .resume-document h1 { font-size: clamp(34px, 5vw, 58px); }
    .resume-document h2 { font-size: 21px; }
    .resume-document h3 { font-size: 17px; }
    .resume-document .source-note { font-size: 12px; }
    .resume-document .resume-section { margin-bottom: 32px; }
    .resume-document .resume-item { margin-bottom: 24px; }
    .resume-document .section-key-results li { padding: 12px 16px; }
    .resume-document .page-footer { margin-top: 32px; padding-top: 12px; border-top: 1px solid var(--border); font-size: 12px; }
    @media (max-width: 720px) {
      .resume-document { width: min(calc(100% - 24px), 980px); margin: 12px auto; padding: 24px 20px; }
      .layout-columns, .section-key-results ul { grid-template-columns: 1fr; }
      .identity { padding: 18px; }
    }
  `;
}

function renderScreen({ title, styleId }) {
  const body = `<main class="resume-document" data-layout="standard-chronological">
    ${renderHeader()}
    ${renderAllSections()}
    <footer class="page-footer">周予安｜虚拟基准简历｜网页浏览预览</footer>
  </main>`;
  return htmlDocument({ title, styleId, body, formatCss: screenCss(), bodyClass: "format-screen-continuous" });
}

function slidesCss(format) {
  const is43 = format === "slides-4x3";
  const width = is43 ? "10in" : "13.333in";
  const padding = is43 ? ".48in .55in" : ".5in .7in";
  return `
    @page { size: ${width} 7.5in; margin: 0; }
    body { font-size: 13pt; line-height: 1.42; }
    .resume-deck { width: ${width}; margin: 18px auto; }
    .resume-slide { position: relative; width: ${width}; height: 7.5in; margin: 0 auto 18px; padding: ${padding}; background: var(--paper); box-shadow: 0 10px 28px rgba(20, 20, 25, .14); }
    .resume-slide + .resume-slide { break-before: page; page-break-before: always; }
    .resume-slide h1 { font-size: 36pt; }
    .resume-slide h2 { font-size: 22pt; margin-bottom: .16in; }
    .resume-slide h3 { font-size: 15pt; }
    .resume-slide p { margin-bottom: .08in; }
    .resume-slide li { margin-bottom: .045in; }
    .resume-slide .source-note { font-size: 10pt; }
    .resume-slide .resume-section { margin-bottom: .18in; }
    .resume-slide .resume-item { margin-bottom: .16in; }
    .slide-kicker { margin-bottom: .12in; color: var(--accent); font-size: 10pt; font-weight: 700; letter-spacing: .12em; text-transform: uppercase; }
    .slide-footer { position: absolute; right: ${is43 ? ".55in" : ".7in"}; bottom: .24in; left: ${is43 ? ".55in" : ".7in"}; display: flex; justify-content: space-between; border-top: 1px solid var(--border); padding-top: .08in; font-size: 10pt; }
    .slide-grid { display: grid; grid-template-columns: 1fr 1fr; gap: .28in; align-items: start; }
    .resume-slide .section-key-results ul { gap: .1in; }
    .resume-slide .section-key-results li { padding: .1in .13in; }
    @media print {
      html, body { margin: 0; background: #ffffff; }
      .resume-deck { width: auto; margin: 0; }
      .resume-slide { display: block; width: ${width}; height: 7.5in; margin: 0; box-shadow: none; -webkit-print-color-adjust: exact; print-color-adjust: exact; }
      .resume-slide + .resume-slide { break-before: page; page-break-before: always; }
    }
  `;
}

function slide(label, content) {
  return `<section class="resume-slide"><div class="slide-kicker">${escapeHtml(label)}</div>${content}</section>`;
}

function renderSlides({ title, styleId, format }) {
  const s = renderSection;
  const work = (chunks) => renderChunkSection("工作经历", chunks);
  const projects = (chunks) => renderChunkSection("代表项目", chunks);
  let slides;
  if (format === "slides-4x3") {
    slides = [
      slide("个人概览", `${renderHeader()}${s("个人简介")}${s("关键成果")}`),
      slide("能力与工具", `${s("核心能力")}${s("专业技能")}`),
      slide("当前经历", work(workChunks.slice(0, 1))),
      slide("历史经历", work(workChunks.slice(1, 2))),
      slide("早期经历与管理", `${work(workChunks.slice(2))}${s("管理与组织经验")}`),
      slide("代表项目", projects(projectChunks.slice(0, 1))),
      slide("项目、教育与活动", `${projects(projectChunks.slice(1))}<div class="slide-grid"><div>${s("教育与研究")}${s("荣誉与认证")}</div><div>${s("研究与专业活动")}</div></div>`),
    ];
  } else {
    slides = [
      slide("个人概览", `<div class="slide-grid"><div>${renderHeader()}${s("个人简介")}</div><div>${s("关键成果")}</div></div>`),
      slide("能力与工具", `<div class="slide-grid"><div>${s("核心能力")}</div><div>${s("专业技能")}</div></div>`),
      slide("当前经历", work(workChunks.slice(0, 1))),
      slide("历史经历", `<div class="slide-grid"><div>${work(workChunks.slice(1, 2))}</div><div>${work(workChunks.slice(2))}${s("管理与组织经验")}</div></div>`),
      slide("代表项目", `<div class="slide-grid"><div>${projects(projectChunks.slice(0, 1))}</div><div>${projects(projectChunks.slice(1))}</div></div>`),
      slide("教育与专业活动", `<div class="slide-grid"><div>${s("教育与研究")}${s("荣誉与认证")}</div><div>${s("研究与专业活动")}</div></div>`),
    ];
  }
  const total = slides.length;
  const body = `<main class="resume-deck" data-output-format="${format}">
    ${slides.map((item, index) => item.replace("</section>", `<footer class="slide-footer"><span>周予安｜AI 产品与增长负责人</span><span>${index + 1} / ${total}</span></footer></section>`)).join("\n")}
  </main>`;
  return htmlDocument({ title, styleId, body, formatCss: slidesCss(format), bodyClass: `format-${format}` });
}

function write(relativePath, contents) {
  const fullPath = path.join(outputRoot, relativePath);
  fs.mkdirSync(path.dirname(fullPath), { recursive: true });
  fs.writeFileSync(fullPath, contents, "utf8");
  return fullPath;
}

function renderIndex(entries) {
  const groups = [
    ["视觉风格", entries.filter((entry) => entry.group === "visual-styles")],
    ["简历版式", entries.filter((entry) => entry.group === "layouts")],
    ["输出规格", entries.filter((entry) => entry.group === "formats")],
  ];
  return `<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>HTML 简历预览文件</title>
  <style>
    * { box-sizing: border-box; }
    *, *::before, *::after { animation: none !important; transition: none !important; }
    html { scroll-behavior: auto; }
    body { margin: 0; background: #f3f5f8; color: #13213a; font-family: Inter, ui-sans-serif, system-ui, -apple-system, 'Segoe UI', sans-serif; }
    main { width: min(calc(100% - 40px), 1120px); margin: 40px auto 72px; }
    header { margin-bottom: 36px; padding: 28px 30px; background: #ffffff; border: 1px solid #dce2ea; border-radius: 14px; }
    h1 { margin: 0 0 8px; font-size: 30px; }
    h2 { margin: 32px 0 14px; font-size: 20px; }
    p { margin: 0; color: #526176; line-height: 1.6; }
    .grid { display: grid; grid-template-columns: repeat(3, minmax(0, 1fr)); gap: 14px; }
    a { display: block; min-height: 108px; padding: 18px; color: #13213a; text-decoration: none; background: #ffffff; border: 1px solid #dce2ea; border-radius: 12px; }
    a strong { display: block; margin-bottom: 7px; font-size: 16px; }
    a span { color: #66758a; font-size: 13px; line-height: 1.5; }
    @media (max-width: 760px) { main { width: min(calc(100% - 24px), 1120px); margin-top: 12px; } .grid { grid-template-columns: 1fr; } }
  </style>
</head>
<body>
  <main>
    <header>
      <h1>HTML 简历预览文件</h1>
      <p>共 ${entries.length} 个独立预览：8 个视觉风格、6 个简历版式、4 个输出规格。点击选项打开对应 HTML 后即可截图。</p>
    </header>
    ${groups.map(([name, items]) => `<section><h2>${name}</h2><div class="grid">${items.map((item) => `<a href="${item.href}"><strong>${item.name}</strong><span>${item.detail}</span></a>`).join("")}</div></section>`).join("\n")}
  </main>
</body>
</html>`;
}

fs.rmSync(outputRoot, { recursive: true, force: true });
fs.mkdirSync(outputRoot, { recursive: true });

const entries = [];

for (const [styleId, profile] of Object.entries(styleProfiles)) {
  const relativePath = path.join("visual-styles", `${styleId}.html`);
  write(relativePath, renderA4({
    title: `${profile.name}｜视觉风格预览`,
    styleId,
    layoutId: "standard-chronological",
  }));
  entries.push({
    group: "visual-styles",
    name: profile.name,
    href: relativePath,
    detail: `${styleId} · 标准经历 · A4`,
  });
}

for (const [layoutId, name] of Object.entries(layoutNames)) {
  const relativePath = path.join("layouts", `${layoutId}.html`);
  write(relativePath, renderA4({
    title: `${name}｜简历版式预览`,
    styleId: "design_hellotime",
    layoutId,
  }));
  entries.push({
    group: "layouts",
    name,
    href: relativePath,
    detail: `${layoutId} · 极简数据 · A4`,
  });
}

for (const [formatId, name] of Object.entries(formatNames)) {
  const relativePath = path.join("formats", `${formatId}.html`);
  let html;
  if (formatId === "screen-continuous") {
    html = renderScreen({ title: `${name}｜输出规格预览`, styleId: "design_hellotime" });
  } else if (formatId === "print-a4") {
    html = renderA4({ title: `${name}｜输出规格预览`, styleId: "design_hellotime", layoutId: "standard-chronological" });
  } else {
    html = renderSlides({ title: `${name}｜输出规格预览`, styleId: "design_hellotime", format: formatId });
  }
  write(relativePath, html);
  entries.push({
    group: "formats",
    name,
    href: relativePath,
    detail: `${formatId} · 极简数据 · 标准经历`,
  });
}

write("index.html", renderIndex(entries));

console.log(`Generated ${entries.length} previews in ${outputRoot}`);
