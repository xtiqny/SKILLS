# HTML 简历验收清单

## 1. 事实

- 姓名、联系方式、目标职位一致。
- 公司、职位、日期、城市一致。
- 学校、专业、学历和时间一致。
- 项目名称和责任动词一致。
- 所有数字、金额、比例和单位一致。
- 原文声明完整保留。
- 没有新增评分、匹配度、人才等级或推测性结论。

## 2. 内容

- 无重复段落和重复业绩。
- 无广告口号式标题。
- 无空泛 AI 总结。
- 英文标签数量克制。
- 所选版式的章节顺序和压缩规则得到执行。

## 3. 通用静态 HTML

- 完整 HTML5 文档，语言、charset、viewport、title 存在。
- CSS 内联，无 HTTP/HTTPS 外部依赖。
- 核心内容不依赖 JavaScript。
- 不使用小于 7pt 的正文。
- 所选输出规格与 HTML 结构一致。
- 不存在 `@keyframes`、有效的 CSS 动画或转场、平滑滚动、SVG 动画或 JavaScript 动画 API。

## 4. 网页浏览检查（`screen-continuous`）

- 存在一个承载正文的 `.resume-document`。
- 不生成 `.resume-page`、A4 `@page` 或强制分页规则。
- 不设置 `297mm` 固定页高，也不模拟纸张裁切。
- 至少为窄屏提供一组响应式规则。
- 分别在 375px、768px、1440px 宽度检查可读性。
- 不出现横向滚动、文字遮挡或双栏被过度挤压。

在浏览器中检查：

```javascript
({
  viewport: document.documentElement.clientWidth,
  content: document.documentElement.scrollWidth,
  horizontalOverflow:
    document.documentElement.scrollWidth > document.documentElement.clientWidth + 1
});
```

`horizontalOverflow` 必须为 `false`。

## 5. A4 打印检查（`print-a4`）

- `.resume-page` 数量大于零。
- 存在 A4 纵向 `@page` 规则。
- 第二页开始存在强制分页规则。
- 每个 `.resume-page` 是独立页面容器，正文保持普通文档流。
- 页容器未统一绝对定位，未用 `overflow:hidden` 截断内容。

在浏览器中逐页检查：

```javascript
[...document.querySelectorAll('.resume-page')].map((page, index) => ({
  page: index + 1,
  clientHeight: page.clientHeight,
  scrollHeight: page.scrollHeight,
  overflow: page.scrollHeight > page.clientHeight + 1
}));
```

任何 `overflow: true` 都必须重排。不得用隐藏溢出解决。

## 6. PPT 分页检查（`slides-4x3` / `slides-16x9`）

- 存在 `.resume-deck`，且 `data-output-format` 与所选规格一致。
- `.resume-slide` 数量大于零，第二张开始存在强制分页规则。
- 4:3 使用 10in × 7.5in；16:9 使用 13.333in × 7.5in。
- `@page` 尺寸、幻灯片 CSS 尺寸和 `data-output-format` 三者一致。
- 每张幻灯片聚焦一个主要主题，不把 A4 页面机械缩放成宽屏。
- 正文不低于 12pt，辅助文字不低于 10pt。
- 不使用动画、转场、自动播放、平滑滚动或逐步出现效果。

在浏览器中逐页检查：

```javascript
const expectedRatio =
  document.querySelector('.resume-deck')?.dataset.outputFormat === 'slides-4x3'
    ? 4 / 3
    : 16 / 9;

[...document.querySelectorAll('.resume-slide')].map((slide, index) => ({
  slide: index + 1,
  ratio: slide.clientWidth / slide.clientHeight,
  ratioMatches: Math.abs(slide.clientWidth / slide.clientHeight - expectedRatio) < 0.01,
  overflow: slide.scrollHeight > slide.clientHeight + 1
}));
```

任何 `ratioMatches: false` 或 `overflow: true` 都必须修复。

## 7. 对比度

- 普通文字不低于 4.5:1。
- 大号或粗体文字不低于 3:1。
- 重要边框与图形不低于 3:1。
- 浅色子卡片必须显式使用深色文字。
- 深色表面的小号辅助文字仍需达到标准。
- 渐变文字按最浅端检查。
- 页脚和声明按普通文字标准检查。

## 8. 分页预览（`print-a4` 与 PPT 规格）

- A4 使用 A4 纵向；PPT 使用所选固定比例；均按 100% 或实际大小。
- 页数等于 `.resume-page` 或 `.resume-slide` 数量。
- 无页面重叠、意外空白页、裁切或页脚越界。
- 关闭浏览器页眉页脚。
- 开启背景图形时风格完整。
- 关键正文不应依赖背景填充才可阅读。

## 失败条件

上述任一事实错误、输出规格错配、动画或转场、比例错误、内容截断、页面重叠、横向溢出、对比度失败、字号过小或分页数量错误均禁止交付。修复后重新执行静态与渲染检查。
