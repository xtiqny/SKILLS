#!/usr/bin/env python3
"""Static guardrails for resume-html-agent output.

Usage:
  python3 validate_resume_html.py output.html [--source resume.md]
      [--format auto|screen-continuous|print-a4|slides-4x3|slides-16x9]

This deliberately checks only deterministic invariants. Browser layout,
computed color inheritance, overflow, and fixed-page preview still require render QA.
"""

from __future__ import annotations

import argparse
import html as html_module
import re
import sys
from html.parser import HTMLParser
from pathlib import Path


OUTPUT_FORMATS = (
    "auto",
    "screen-continuous",
    "print-a4",
    "slides-4x3",
    "slides-16x9",
)


class VisibleTextParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []
        self.hidden_depth = 0

    def handle_starttag(self, tag: str, attrs) -> None:
        if tag.lower() in {"style", "script", "noscript"}:
            self.hidden_depth += 1

    def handle_endtag(self, tag: str) -> None:
        if tag.lower() in {"style", "script", "noscript"} and self.hidden_depth:
            self.hidden_depth -= 1

    def handle_data(self, data: str) -> None:
        if not self.hidden_depth:
            self.parts.append(data)

    def text(self) -> str:
        return " ".join(self.parts)


def normalize(value: str) -> str:
    value = html_module.unescape(value)
    value = value.replace("\\@", "@").replace("\\", "")
    value = re.sub(r"[\s\u00a0]+", "", value)
    return value


def unique_matches(pattern: str, text: str, flags: int = 0) -> list[str]:
    found = re.findall(pattern, text, flags)
    values = ["".join(item) if isinstance(item, tuple) else item for item in found]
    return list(dict.fromkeys(values))


def source_tokens(source: str) -> dict[str, list[str]]:
    clean = source.replace("\\@", "@")
    return {
        "email": unique_matches(r"[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}", clean, re.I),
        "phone": unique_matches(r"(?<!\d)(?:\+?\d[\d\s()-]{6,}\d)(?!\d)", clean),
        "date": unique_matches(r"(?<!\d)(?:19|20)\d{2}[.\-/年](?:0?[1-9]|1[0-2])(?:月)?", clean),
        "percent": unique_matches(r"(?<!\d)\d+(?:\.\d+)?\s*%", clean),
        "quantity": unique_matches(
            r"(?<![\w.])\d+(?:[.,]\d+)?\+?\s*(?:万|亿|元|家|人次|人|次|天|小时|个月|个)(?![\w])",
            clean,
        ),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description="Validate static HTML resume invariants.")
    parser.add_argument("html", type=Path, help="Generated HTML file")
    parser.add_argument("--source", type=Path, help="Original Markdown or plain-text resume")
    parser.add_argument(
        "--format",
        choices=OUTPUT_FORMATS,
        default="auto",
        help="Expected output format; auto infers it from the HTML structure.",
    )
    args = parser.parse_args()

    errors: list[str] = []
    warnings: list[str] = []

    if not args.html.is_file():
        print(f"ERROR: HTML file not found: {args.html}", file=sys.stderr)
        return 2

    raw = args.html.read_text(encoding="utf-8")
    lower = raw.lower()

    if not re.match(r"\s*<!doctype\s+html>", raw, re.I):
        errors.append("Missing HTML5 doctype.")
    if not re.search(r"<html[^>]+lang=[\"']zh-CN[\"']", raw, re.I):
        errors.append('Missing <html lang="zh-CN">.')
    if not re.search(r"<meta[^>]+charset=[\"']?utf-8", raw, re.I):
        errors.append("Missing UTF-8 charset meta tag.")
    if not re.search(r"<meta[^>]+name=[\"']viewport[\"']", raw, re.I):
        errors.append("Missing viewport meta tag.")
    if not re.search(r"<title>\s*[^<]+\s*</title>", raw, re.I):
        errors.append("Missing non-empty title.")
    if "</html>" not in lower:
        errors.append("Missing closing </html> tag.")

    external = re.findall(
        r"<(?:link|script|img|iframe)\b[^>]*(?:href|src)=[\"']https?://[^\"']+",
        raw,
        re.I,
    )
    if external:
        errors.append(f"Remote dependencies found: {len(external)}.")

    if re.search(r"@(?:-webkit-)?keyframes\b", raw, re.I):
        errors.append("CSS keyframes are not allowed in any output format.")

    for property_name in ("animation", "transition"):
        values = re.findall(
            rf"(?<![\w-]){property_name}(?:-[\w-]+)?\s*:\s*([^;}}{{]+)",
            raw,
            re.I,
        )
        active_values = []
        for value in values:
            cleaned = re.sub(r"\s*!important\s*$", "", value.strip(), flags=re.I)
            if cleaned.lower() != "none":
                active_values.append(cleaned)
        if active_values:
            errors.append(
                f"Active CSS {property_name} declarations are not allowed: "
                + "; ".join(dict.fromkeys(active_values))
            )

    if re.search(r"scroll-behavior\s*:\s*smooth", raw, re.I):
        errors.append("Smooth scrolling is not allowed in any output format.")
    if re.search(r"<(?:animate|animatemotion|animatetransform|set)\b", raw, re.I):
        errors.append("Animated SVG elements are not allowed.")
    if re.search(r"\brequestAnimationFrame\s*\(|\.animate\s*\(", raw, re.I):
        errors.append("JavaScript animation APIs are not allowed.")

    page_count = len(
        re.findall(r"class=[\"'][^\"']*\bresume-page\b[^\"']*[\"']", raw, re.I)
    )
    slide_count = len(
        re.findall(r"class=[\"'][^\"']*\bresume-slide\b[^\"']*[\"']", raw, re.I)
    )
    deck_count = len(
        re.findall(r"class=[\"'][^\"']*\bresume-deck\b[^\"']*[\"']", raw, re.I)
    )
    document_count = len(
        re.findall(r"class=[\"'][^\"']*\bresume-document\b[^\"']*[\"']", raw, re.I)
    )
    format_markers = re.findall(
        r"data-output-format=[\"'](slides-(?:4x3|16x9))[\"']", raw, re.I
    )
    format_marker = format_markers[0].lower() if format_markers else None
    if len(set(value.lower() for value in format_markers)) > 1:
        errors.append("Conflicting data-output-format markers found.")

    has_any_page_rule = bool(re.search(r"@page\s*\{", raw, re.I))
    has_a4_page = bool(
        re.search(r"@page\s*\{[^}]*size\s*:\s*A4(?:\s+portrait)?", raw, re.I | re.S)
    )
    has_4x3_page = bool(
        re.search(
            r"@page\s*\{[^}]*size\s*:\s*10(?:\.0+)?in\s+7\.5(?:0+)?in",
            raw,
            re.I | re.S,
        )
    )
    has_16x9_page = bool(
        re.search(
            r"@page\s*\{[^}]*size\s*:\s*13\.33(?:3+)?in\s+7\.5(?:0+)?in",
            raw,
            re.I | re.S,
        )
    )
    has_forced_break = bool(
        re.search(r"page-break-before\s*:\s*always|break-before\s*:\s*page", raw, re.I)
    )

    if format_marker:
        detected_format = format_marker
    elif slide_count and has_4x3_page:
        detected_format = "slides-4x3"
    elif slide_count and has_16x9_page:
        detected_format = "slides-16x9"
    elif slide_count:
        detected_format = "slides-16x9"
    elif page_count or has_a4_page:
        detected_format = "print-a4"
    else:
        detected_format = "screen-continuous"
    output_format = detected_format if args.format == "auto" else args.format

    if output_format == "print-a4":
        if page_count == 0:
            errors.append("No .resume-page elements found for print-a4 output.")
        if slide_count or deck_count:
            errors.append("print-a4 output must not contain presentation slide containers.")
        if not has_a4_page:
            errors.append("Missing @page A4 portrait rule for print-a4 output.")
        if page_count > 1 and not has_forced_break:
            errors.append("Missing forced page break for subsequent print pages.")
    elif output_format == "screen-continuous":
        if document_count == 0:
            errors.append("No .resume-document element found for screen-continuous output.")
        if page_count:
            errors.append("screen-continuous output must not contain .resume-page elements.")
        if slide_count or deck_count:
            errors.append("screen-continuous output must not contain presentation slide containers.")
        if has_any_page_rule:
            errors.append("screen-continuous output must not contain an @page rule.")
        if has_forced_break:
            errors.append("screen-continuous output must not force page breaks.")
        if re.search(r"(?:min-|max-)?height\s*:\s*297mm", raw, re.I):
            errors.append("screen-continuous output must not use a fixed 297mm page height.")
        if not re.search(r"@media\s*(?:screen\s+and\s*)?\([^)]*max-width", raw, re.I):
            errors.append("screen-continuous output is missing a narrow-screen responsive rule.")
    else:
        expected_marker = output_format
        if deck_count == 0:
            errors.append(f"No .resume-deck element found for {output_format} output.")
        if slide_count == 0:
            errors.append(f"No .resume-slide elements found for {output_format} output.")
        if page_count:
            errors.append(f"{output_format} output must not contain .resume-page elements.")
        if format_marker != expected_marker:
            errors.append(
                f'Expected data-output-format="{expected_marker}", found {format_marker or "none"}.'
            )
        if slide_count > 1 and not has_forced_break:
            errors.append("Missing forced page break for subsequent presentation slides.")

        expected_width = (
            r"10(?:\.0+)?in" if output_format == "slides-4x3" else r"13\.33(?:3+)?in"
        )
        expected_page_size = has_4x3_page if output_format == "slides-4x3" else has_16x9_page
        if not expected_page_size:
            errors.append(f"Missing matching @page size for {output_format} output.")
        slide_rules = re.findall(r"\.resume-slide(?:[^,{]*)\{([^}]*)\}", raw, re.I | re.S)
        has_matching_slide_size = any(
            re.search(rf"width\s*:\s*{expected_width}", declarations, re.I)
            and re.search(r"height\s*:\s*7\.5(?:0+)?in", declarations, re.I)
            for declarations in slide_rules
        )
        if not has_matching_slide_size:
            errors.append(f"Missing matching .resume-slide dimensions for {output_format} output.")

    if output_format == "print-a4":
        page_rules = re.findall(r"\.resume-page(?:[^,{]*)\{([^}]*)\}", raw, re.I | re.S)
        for index, declarations in enumerate(page_rules, 1):
            if re.search(r"position\s*:\s*absolute", declarations, re.I):
                errors.append(f".resume-page CSS rule {index} uses position:absolute.")
            if re.search(r"overflow\s*:\s*(?:hidden|clip)", declarations, re.I):
                errors.append(f".resume-page CSS rule {index} hides overflow.")
    elif output_format.startswith("slides-"):
        slide_rules = re.findall(r"\.resume-slide(?:[^,{]*)\{([^}]*)\}", raw, re.I | re.S)
        for index, declarations in enumerate(slide_rules, 1):
            if re.search(r"position\s*:\s*absolute", declarations, re.I):
                errors.append(f".resume-slide CSS rule {index} uses position:absolute.")
            if re.search(r"overflow\s*:\s*(?:hidden|clip)", declarations, re.I):
                errors.append(f".resume-slide CSS rule {index} hides overflow.")

    tiny_sizes = [float(value) for value in re.findall(r"font-size\s*:\s*(\d+(?:\.\d+)?)pt", raw, re.I)]
    if tiny_sizes and min(tiny_sizes) < 7:
        errors.append(f"Font size below 7pt found: {min(tiny_sizes):g}pt.")
    if output_format.startswith("slides-") and tiny_sizes:
        if min(tiny_sizes) < 10:
            errors.append(f"Presentation text below 10pt found: {min(tiny_sizes):g}pt.")
        elif min(tiny_sizes) < 12:
            warnings.append(
                f"Presentation text below the recommended 12pt body size found: {min(tiny_sizes):g}pt."
            )

    text_parser = VisibleTextParser()
    text_parser.feed(raw)
    visible_text = normalize(text_parser.text())

    if args.source:
        if not args.source.is_file():
            errors.append(f"Source file not found: {args.source}")
        else:
            source = args.source.read_text(encoding="utf-8")
            missing: list[str] = []
            for category, values in source_tokens(source).items():
                for value in values:
                    if normalize(value) not in visible_text:
                        missing.append(f"{category}: {value.strip()}")
            if missing:
                errors.append("Source tokens missing from HTML: " + "; ".join(missing))

    print(f"HTML: {args.html}")
    print(f"Output format: {output_format}")
    if output_format == "print-a4":
        print(f"Resume pages: {page_count}")
    elif output_format.startswith("slides-"):
        print(f"Resume slides: {slide_count}")
    for warning in warnings:
        print(f"WARNING: {warning}")
    for error in errors:
        print(f"ERROR: {error}")

    if errors:
        print(f"FAIL: {len(errors)} error(s), {len(warnings)} warning(s).")
        return 1

    print(f"PASS: static checks complete with {len(warnings)} warning(s).")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
