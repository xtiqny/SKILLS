# Evolve CLI

The `evolve` CLI is the deterministic kernel underneath the [Evolve Skill](evolve-skill.md).
It discovers the runtime's evolvable surfaces, uploads session logs as evidence,
renders local diff previews, and applies approved proposals to files. The cloud
does the thinking (sessions → signals → genes → proposals); the CLI does the
local must-never-go-wrong parts.

Use the CLI directly when you want to script the lifecycle, drive it from CI, or
inspect what the skill is doing under the hood.

## Install

```bash
pip install --user <evolve_cli-*.whl>
```

The wheel ships inside the skill upload zips
(`evolve-setup-{trae,claude_code,openclaw}.zip` → `evolve-setup/evolve_cli-*.whl`)
and is the same package the IDE skill installs on first run. There is no public
PyPI release yet.

Verify:

```bash
python3 -m evolve_cli --help
```

Always invoke as `python3 -m evolve_cli` rather than the bare `evolve` shim —
customer machines often have a stale `evolve` from an earlier install on a
different interpreter sitting earlier on PATH.

## The seven commands

| # | Command | Writes? | Use for |
|---|---|---|---|
| 1 | `evolve init --connector C --runtime-root R --base-url U [--api-key K] [--agent-id A] [--refresh]` | cloud + `~/.evolve/` | First-time setup, or after the runtime's surfaces changed. |
| 2 | `evolve status` | no | Is evolve set up? Any pending proposals? |
| 3 | `evolve import [--from PATH] [--limit N] [--no-wait]` | cloud | Upload recent session logs as evidence; poll the async pipeline. |
| 4 | `evolve proposals [--status not_applied\|applied\|pending] [--limit N]` | no | List suggestions. |
| 5 | `evolve proposal <id>` | no | Inspect one import (`ep_…`) or one proposal (`p_…`); render local diff previews. |
| 6 | `evolve capability [<target_id>] [--auto-apply true\|false]` | cloud only when toggling | List evolvable surfaces or set auto-apply. |
| 7 | `evolve apply <proposal_id> [--dry-run]` | **runtime file** | Preview (`--dry-run`) then apply. The only command that writes the runtime. |

There is no `rollback`, `reviews`, or standalone `dry-run` command. Apply lands
a removable `<!-- evolvor:chg_<hex> --> … <!-- /evolvor:chg_<hex> -->` chunk in
the runtime file; delete the chunk to undo it.

## Configuration

Each command reads from three sources, most explicit wins:

1. Per-command flag (e.g. `--api-key`)
2. Environment variable (e.g. `EVOLVE_API_KEY`)
3. `~/.evolve/config.yaml` (persisted by the most recent `evolve init`)

### Environment variables

| Variable | Used by | Notes |
|---|---|---|
| `EVOLVE_BASE_URL` | every command | Self-evolve API gateway URL; ends in `/case-platform`. |
| `EVOLVE_API_KEY` | every command | Ark API key, sent as `Authorization: Bearer`. Falls back to `ARK_API_KEY`. |
| `EVOLVE_RUNTIME_ROOT` | `init` | Directory containing the agent's instruction files. |
| `EVOLVE_AGENT_ID` | `init` | Optional UUID; auto-generated if omitted. |
| `EVOLVE_INSECURE` | `init` (when using the installer) | `1` to allow plaintext `http://` — needed today while the gateway is HTTP. |

The backend environment is bound at CLI install time (see `_BOUND_ENV` in
`cli/src/evolve_cli/main.py`) and is not a customer knob — every install is
hardwired to one rollout backend. There is no `--env` flag or `EVOLVE_ENV`
variable.

### Connectors

The `--connector` flag tells the CLI which runtime conventions to follow.

| Connector | Evolvable surface(s) | Default `--runtime-root` |
|---|---|---|
| `trae` | `AGENTS.md` | project directory |
| `claude_code` | `CLAUDE.md`, `CLAUDE.local.md`, `~/.claude/CLAUDE.md` | project directory |
| `openclaw` | `AGENTS.md`, `SOUL.md`, `IDENTITY.md`, `USER.md`, `TOOLS.md`, `BOOTSTRAP.md`, `HEARTBEAT.md`, `MEMORY.md`, `skills/` | `~/.openclaw/workspace` |

### The CLI workspace

`evolve init` writes `~/.evolve/`:

```
~/.evolve/
  config.yaml                # base_url, agent_id, env, connector, runtime_root, ...
  capability_snapshot.json   # the surfaces registered with the cloud
  binding.json               # target_id → file_path + digest
  previews/{import_id}/*.diff  # local diff previews rendered by `evolve proposal`
  apply-journal.jsonl        # one line per `evolve apply` for auditability
```

Subsequent commands read `config.yaml` automatically — you don't re-pass the
init flags.

## Typical lifecycle

```bash
# One-time setup
export EVOLVE_BASE_URL=https://sd8fq9c4cuac30otu789g.apigateway-cn-beijing.volceapi.com/case-platform
export EVOLVE_API_KEY=ark-xxxxxxxx-...
python3 -m evolve_cli init --connector claude_code --runtime-root "$PWD"

# Learn from recent sessions (uploads evidence to the cloud)
python3 -m evolve_cli import --limit 5

# List what came back
python3 -m evolve_cli proposals
python3 -m evolve_cli proposal ep_abc...

# Preview then apply
python3 -m evolve_cli apply p_xyz... --dry-run
python3 -m evolve_cli apply p_xyz...

# Confirm it landed
python3 -m evolve_cli proposals --status applied
```

## Auth model

A real backend rejects every command without a valid Ark API key
(`{"detail":"Invalid or expired token"}`). The Ark account that owns the key
becomes the **owner** of the agent's CapabilityMap on first `init`; every
subsequent call must come from the same account. There is no separate
account-id or user-name field — the backend reads them from `GetAPIKeyMeta`.

The local mock backend (in `tests/mock_backend.py`) ignores the key entirely,
useful for offline development.

## Common errors

| Output | Meaning | Fix |
|---|---|---|
| `No Evolve workspace at ~/.evolve/config.yaml` | `init` hasn't been run for this user | Run `evolve init` |
| `register_capability_map failed (HTTP 401): {"detail":"Invalid or expired token"}` | Ark key isn't recognized by the env the CLI is bound to | Use a key registered in the env's Ark service (`ark` / `ark_stg` / `ark_boe`). The env is set at CLI install time via `_BOUND_ENV`; keys from one env 401 against another. |
| `register_capability_map failed (HTTP 500): Unknown column '…display_name'` | Backend DB is missing a recent migration | Operator runs `case_platform/scripts/migrate_self_evolve.py` against the backend's DB |
| `connector 'X' found no capabilities under <root>` | Wrong `--runtime-root` (no `AGENTS.md` / `CLAUDE.md` there) | Point `--runtime-root` at a directory that contains the runtime's instruction file |
| `cloud_reachable: False` in `status` | Backend or URL is unreachable | Verify `EVOLVE_BASE_URL`; curl the URL directly to confirm routing |
| `warning: --api-key differs from $EVOLVE_API_KEY in the environment` | Stale env file overriding the flag | Update `~/.evolve-skill.env` (or whichever file you source); the flag won and the call proceeded |

## Test harness

| Suite | Command | What it covers |
|---|---|---|
| Drift guards | `python -m pytest evolve_skill/tests/test_skill_docs.py -q` | The three runtime manifests reference the same seven commands, no bogus commands resurface. Fast, offline. |
| Lifecycle smoke | `python evolve_skill/tests/eval_suite.py --only cc_happy oc_happy trae_happy` | Init → import → proposals → apply against an in-process mock backend. ~8 s per runtime. |
| Trae manual | See [`evolve_skill/trae/MANUAL_TESTS.md`](../trae/MANUAL_TESTS.md) | 11-step human-in-the-loop journey in real Trae chat. The only layer that catches agent-behavior regressions. |

## When to use the skill instead

If you don't need scripting, [Evolve Skill](evolve-skill.md) wraps the same
commands in a natural-language layer with built-in confirmation prompts and
proposal explanations. Most customers want the skill; the CLI is for power
users, CI, and debugging.
