# Evolve CLI

`evolve` CLI 是 [Evolve 技能](evolve-skill.md) 之下的确定性内核。
它发现运行时的可演进表面，将会话日志作为证据上传，
渲染本地 diff 预览，并将已批准的提案应用到文件。云端
负责思考（sessions → signals → genes → proposals）；CLI 负责
本地必须绝不出错的部分。

当您想脚本化生命周期、从 CI 驱动，或
检查技能在底层做什么时，请直接使用 CLI。

## 安装

```bash
pip install --user <evolve_cli-*.whl>
```

wheel 随技能上传 zip 提供
（`evolve-setup-{trae,claude_code,openclaw}.zip` → `evolve-setup/evolve_cli-*.whl`），
也是 IDE 技能首次运行时安装的同一个 package。目前还没有公开
PyPI release。

验证：

```bash
python3 -m evolve_cli --help
```

始终以 `python3 -m evolve_cli` 调用，而不是裸 `evolve` shim —
客户机器上通常有早期安装遗留的陈旧 `evolve`，位于 PATH 中
不同解释器之前的位置。

## 七个命令

| # | 命令 | 写入？ | 用途 |
|---|---|---|---|
| 1 | `evolve init --connector C --runtime-root R --base-url U [--api-key K] [--agent-id A] [--refresh]` | cloud + `~/.evolve/` | 首次设置，或运行时表面发生变化后使用。 |
| 2 | `evolve status` | no | evolve 是否已设置？是否有待处理提案？ |
| 3 | `evolve import [--from PATH] [--limit N] [--no-wait]` | cloud | 上传最近会话日志作为证据；轮询异步 pipeline。 |
| 4 | `evolve proposals [--status not_applied\|applied\|pending] [--limit N]` | no | 列出建议。 |
| 5 | `evolve proposal <id>` | no | 检查一个 import（`ep_…`）或一个提案（`p_…`）；渲染本地 diff 预览。 |
| 6 | `evolve capability [<target_id>] [--auto-apply true\|false]` | 仅切换时写 cloud | 列出可演进表面或设置 auto-apply。 |
| 7 | `evolve apply <proposal_id> [--dry-run]` | **runtime file** | 预览（`--dry-run`）后应用。唯一写入运行时的命令。 |

没有 `rollback`、`reviews` 或独立的 `dry-run` 命令。Apply 会在
运行时文件中落下一个可移除的 `<!-- evolvor:chg_<hex> --> … <!-- /evolvor:chg_<hex> -->` 块；
删除该块即可撤销。

## 配置

每个命令从三个来源读取配置，最显式者胜出：

1. 每命令 flag（例如 `--api-key`）
2. 环境变量（例如 `EVOLVE_API_KEY`）
3. `~/.evolve/config.yaml`（由最近一次 `evolve init` 持久化）

### 环境变量

| 变量 | 使用方 | 说明 |
|---|---|---|
| `EVOLVE_BASE_URL` | every command | Self-evolve API gateway URL；以 `/case-platform` 结尾。 |
| `EVOLVE_API_KEY` | every command | Ark API key，以 `Authorization: Bearer` 发送。回退到 `ARK_API_KEY`。 |
| `EVOLVE_RUNTIME_ROOT` | `init` | 包含 Agent 指令文件的目录。 |
| `EVOLVE_AGENT_ID` | `init` | 可选 UUID；省略时自动生成。 |
| `EVOLVE_INSECURE` | `init`（使用 installer 时） | `1` 允许明文 `http://` — 当前 gateway 为 HTTP 时需要。 |

后端环境在 CLI 安装时绑定（参见 `cli/src/evolve_cli/main.py` 中的
`_BOUND_ENV`），不是客户可调旋钮 — 每次安装都硬绑定到一个 rollout
后端。没有 `--env` flag，也没有 `EVOLVE_ENV` 变量。

### Connectors

`--connector` flag 告诉 CLI 要遵循哪种运行时约定。

| Connector | 可演进表面 | 默认 `--runtime-root` |
|---|---|---|
| `trae` | `AGENTS.md` | project directory |
| `claude_code` | `CLAUDE.md`, `CLAUDE.local.md`, `~/.claude/CLAUDE.md` | project directory |
| `openclaw` | `AGENTS.md`, `SOUL.md`, `IDENTITY.md`, `USER.md`, `TOOLS.md`, `BOOTSTRAP.md`, `HEARTBEAT.md`, `MEMORY.md`, `skills/` | `~/.openclaw/workspace` |

### CLI 工作区

`evolve init` 会写入 `~/.evolve/`：

```
~/.evolve/
  config.yaml                # base_url, agent_id, env, connector, runtime_root, ...
  capability_snapshot.json   # the surfaces registered with the cloud
  binding.json               # target_id → file_path + digest
  previews/{import_id}/*.diff  # local diff previews rendered by `evolve proposal`
  apply-journal.jsonl        # one line per `evolve apply` for auditability
```

后续命令会自动读取 `config.yaml`，您不需要重新传入
init flags。

## 典型生命周期

```bash
# One-time setup
export EVOLVE_BASE_URL=https://sd8fq9c4cuac30otu789g.apigateway-cn-beijing.volceapi.com/case-platform
export EVOLVE_API_KEY=ark-xxxxxxxx-...
python3 -m evolve_cli init --connector claude_code --runtime-root "$PWD"

# Learn from recent sessions (uploads evidence to the cloud)
python3 -m evolve_cli import --limit 5

# List what came back
python3 -m evolve_cli proposals
python3 -m evolve_cli proposal ep_abc...

# Preview then apply
python3 -m evolve_cli apply p_xyz... --dry-run
python3 -m evolve_cli apply p_xyz...

# Confirm it landed
python3 -m evolve_cli proposals --status applied
```

## 认证模型

真实后端会拒绝任何没有有效 Ark API key 的命令
（`{"detail":"Invalid or expired token"}`）。拥有该 key 的 Ark account
会在首次 `init` 时成为 Agent 的 CapabilityMap 的 **owner**；之后
每次调用都必须来自同一 account。没有单独的
account-id 或 user-name 字段；后端从 `GetAPIKeyMeta` 读取它们。

本地 mock 后端（在 `tests/mock_backend.py` 中）完全忽略 key，
用于离线开发。

## 常见错误

| 输出 | 含义 | 修复 |
|---|---|---|
| `No Evolve workspace at ~/.evolve/config.yaml` | 该用户尚未运行 `init` | 运行 `evolve init` |
| `register_capability_map failed (HTTP 401): {"detail":"Invalid or expired token"}` | Ark key 未被 CLI 绑定的 env 的 Ark 服务识别 | 使用注册在该 env 的 Ark 服务（`ark` / `ark_stg` / `ark_boe`）中的 key。env 在 CLI 安装时通过 `_BOUND_ENV` 设定；一个 env 的 key 在另一个 env 上会 401。 |
| `register_capability_map failed (HTTP 500): Unknown column '…display_name'` | 后端 DB 缺少最近的 migration | Operator 针对后端 DB 运行 `case_platform/scripts/migrate_self_evolve.py` |
| `connector 'X' found no capabilities under <root>` | 错误的 `--runtime-root`（那里没有 `AGENTS.md` / `CLAUDE.md`） | 将 `--runtime-root` 指向包含运行时指令文件的目录 |
| `cloud_reachable: False` in `status` | 后端或 URL 不可达 | 验证 `EVOLVE_BASE_URL`；直接 curl 该 URL 确认路由 |
| `warning: --api-key differs from $EVOLVE_API_KEY in the environment` | 陈旧 env 文件覆盖了 flag | 更新 `~/.evolve-skill.env`（或您 source 的任何文件）；flag 已胜出且调用已继续 |

## 测试工具

| Suite | 命令 | 覆盖范围 |
|---|---|---|
| Drift guards | `python -m pytest evolve_skill/tests/test_skill_docs.py -q` | 三个运行时清单文件引用相同的七个命令，没有伪命令重新出现。快速、离线。 |
| Lifecycle smoke | `python evolve_skill/tests/eval_suite.py --only cc_happy oc_happy trae_happy` | 针对进程内 mock 后端执行 Init → import → proposals → apply。每个运行时约 8 s。 |
| Trae manual | 参见 [`evolve_skill/trae/MANUAL_TESTS.md`](../../trae/MANUAL_TESTS.md) | 真实 Trae 聊天中的 11 步 human-in-the-loop 旅程。唯一能捕获 Agent 行为回归的层。 |

## 何时改用技能

如果您不需要脚本化，[Evolve 技能](evolve-skill.md) 会用
带内置确认提示和提案解释的自然语言层包装相同命令。
大多数客户需要技能；CLI 面向高级用户、CI 和调试。