# Evolve 技能

`evolve-setup` 技能是您的编码 Agent 接入 self-evolve 服务的自然语言入口。
您说 *"set me up for evolve"* 或 *"apply that proposal"*；
Agent 会运行正确的 `evolve` CLI 命令，在将发生变更时请求确认，
并解释结果。

## 哪种运行时？

选择与您的 Agent 匹配的集成。每个集成都是一次拖放上传，
无需 shell 命令。

| 运行时 | 上传路径 | Bundle |
|---|---|---|
| **Trae** | Settings → Skills & Commands → Create → Upload | [`evolve-setup-trae.zip`](#downloads) |
| **Claude Code** | 放入 `~/.claude/skills/`（先解压） | [`evolve-setup-claude_code.zip`](#downloads) |
| **OpenClaw** | 放入 `~/.openclaw/workspace/skills/`（先解压） | [`evolve-setup-openclaw.zip`](#downloads) |

每个 zip 都包含该运行时的 `SKILL.md` 清单文件、预构建的 `evolve_cli` wheel
（约 26 KB），以及 Agent 引用的共享 playbook + contract。Agent
首次运行时会从打包的 wheel 安装 CLI，无需单独的 pip 步骤。

## 前置条件

- 上述 Agent 运行时，运行在带有 `python3`（≥ 3.9）和 `pip` 的机器上。
- 一个注册在后端 Ark 服务中的 **Ark API key**（prod 用 `ark`，
  stg 用 `ark_stg`，boe 用 `ark_boe`）。客户仅从这个
  key 推导身份，不需要单独的 account id 或 user name。
- 您的开发机到 self_evolve 网关的网络访问（当前是
  Volcengine API gateway endpoint；HTTPS 即将支持）。

## 设置

在 IDE UI 中分三步：

1. **在 IDE 中打开项目文件夹**。如果根目录没有 `AGENTS.md`（Trae / OpenClaw）
   或 `CLAUDE.md`（Claude Code），请创建一个。该技能需要至少
   一个可演进表面。
2. **上传 zip**，使用上表中的上传路径。IDE 会读取 YAML frontmatter 中的
   `name` 和 `description` 并注册该技能。
3. **配置环境。** 在技能设置中设置：
   - `EVOLVE_BASE_URL` — self_evolve 网关 URL
   - `EVOLVE_API_KEY` — 您的 Ark API key
   - `EVOLVE_INSECURE=1` — 网关 URL 仍为明文 `http://` 时必需
     （HTTPS 落地后移除）

   后端环境在 CLI 安装时绑定（参见 `cli/src/evolve_cli/main.py` 中的
   `_BOUND_ENV`）— 没有 `--env` flag，也没有 `EVOLVE_ENV` 供客户设置。

就是这样。您第一次要求 Agent 执行任何 evolve 相关操作时，它会
在您一行 “yes” 确认后从打包的 wheel 安装 CLI，运行
`evolve init`，并在您尚未设置 Ark key 时提示输入。

## 用法

用自然语言与您的 Agent 对话。该技能会将您的意图映射到
七个 CLI 命令之一，并通过 IDE 内置终端运行。

| 对 Agent 说 | 技能会运行 |
|---|---|
| *"Set me up for evolve"* | `evolve status`，如果尚未初始化则随后运行 `evolve init` |
| *"Is evolve set up?"* | `evolve status` |
| *"Learn from my recent sessions"* | `evolve import --limit 5`（披露路径和数量后） |
| *"What suggestions are there?"* | `evolve proposals` |
| *"Explain that proposal"* | `evolve proposal <id>` — 解释目标文件、理由、证据引用、风险、置信度、diff |
| *"Show me the diff"* | `evolve apply <pid> --dry-run` |
| *"Apply it"* | dry-run 后并获得您的明确 yes 后：`evolve apply <pid>` |
| *"Which surfaces are evolvable?"* | `evolve capability` |

Agent 会在任何写入云端或本地文件的操作前**始终确认**
（`init`、`import`、`apply`、`capability --auto-apply true`）。
`apply` 是两步仪式：dry-run、您说 yes、然后 apply，并且没有
`rollback` 命令。要撤销已应用的提案，请删除 apply 添加到
运行时文件中的 `<!-- evolvor:chg_… -->` 块。

## 限制与预期

- 在刚部署的环境中，基因库完成种子填充前，**零提案是正常的**。
  您的 `evolve import` 会报告 `signals=N, proposals=0`，
  这是正确结果。
- `evolve import` 期间，**会话会离开您的机器**。技能会在请求确认前披露
  路径和会话数量。
- **技能绝不会直接编辑您的运行时文件。** 只有 `evolve apply` 会写入
  `AGENTS.md` / `CLAUDE.md`，并且只会在 dry-run 后获得您的明确 yes 时写入。
- **没有 rollback 命令。** 已应用的提案会落成可移除的
  `<!-- evolvor:chg_… -->` 块。删除该块即可回退。

## 手动验收测试

针对 Trae，`trae/MANUAL_TESTS.md` 随附一条 11 步手动旅程
（发现、描述匹配、确认门禁、dry-run 仪式、伪命令拒绝、
按需静默、跨 IDE `.agents/skills/` fallback），由测试人员
在真实 Trae 聊天中运行。底部的报告模板允许比较多次运行结果。

## 下载

签名 TOS URL，会定期刷新。当前集合：请参见
[`evolve_skill/QUICKSTART.md`](../../QUICKSTART.md) 获取实时链接。

如果 QUICKSTART 中的 URL 已过期，请让 operator 通过以下命令重新发布：
`python3 evolve_skill/scripts/build_upload_zips.py --label vN --days 30`。

## 何时下探到 CLI

如果您想脚本化生命周期、从 CI 运行，或跨多个
Agent 批量应用，请参见 [Evolve CLI](evolve-cli.md)。该技能只是相同命令的
一个会话式包装。