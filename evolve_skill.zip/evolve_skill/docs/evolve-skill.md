# Evolve Skill

The `evolve-setup` skill is the natural-language entrance to the self-evolve service
for your coding agent. You say *"set me up for evolve"* or *"apply that proposal"*;
the agent runs the right `evolve` CLI command, asks for confirmation when something
will change, and explains the result.

## Which runtime?

Pick the integration that matches your agent. Each one is a single drag-and-drop
upload — no shell commands.

| Runtime | Upload path | Bundle |
|---|---|---|
| **Trae** | Settings → Skills & Commands → Create → Upload | [`evolve-setup-trae.zip`](#downloads) |
| **Claude Code** | Drop into `~/.claude/skills/` (unzip first) | [`evolve-setup-claude_code.zip`](#downloads) |
| **OpenClaw** | Drop into `~/.openclaw/workspace/skills/` (unzip first) | [`evolve-setup-openclaw.zip`](#downloads) |

Each zip contains the runtime's `SKILL.md` manifest, a prebuilt `evolve_cli` wheel
(~26 KB), and the shared playbook + contract the agent references. The agent
installs the CLI from the bundled wheel on first run — no separate pip step.

## Prerequisites

- The agent runtime above, on a machine with `python3` (≥ 3.9) and `pip`.
- An **Ark API key** registered in the backend's Ark service (`ark` for prod,
  `ark_stg` for stg, `ark_boe` for boe). The customer derives identity from this
  key alone — no separate account id or user name needed.
- Network access from your dev machine to the self_evolve gateway (today, a
  Volcengine API gateway endpoint; HTTPS soon).

## Setup

Three steps in the IDE UI:

1. **Open a project folder** in your IDE. Create an `AGENTS.md` (Trae / OpenClaw)
   or `CLAUDE.md` (Claude Code) in the root if there isn't one. The skill needs at
   least one surface to evolve.
2. **Upload the zip** using the upload path in the table above. The IDE reads the
   `name` and `description` from the YAML frontmatter and registers the skill.
3. **Configure the environment.** In the skill's settings, set:
   - `EVOLVE_BASE_URL` — the self_evolve gateway URL
   - `EVOLVE_API_KEY` — your Ark API key
   - `EVOLVE_INSECURE=1` — required while the gateway URL is plaintext `http://`
     (drop once HTTPS lands)

   The backend environment is bound at CLI install time (see `_BOUND_ENV` in
   `cli/src/evolve_cli/main.py`) — there is no `--env` flag or `EVOLVE_ENV`
   for customers to set.

That's it. The first time you ask the agent to do anything evolve-related, it
will install the CLI from the bundled wheel under your one-line "yes", run
`evolve init`, and prompt you for your Ark key if you haven't set it.

## Usage

Talk to your agent in natural language. The skill maps your intent to one of the
seven CLI commands and runs it through the IDE's built-in terminal.

| Say to the agent | The skill runs |
|---|---|
| *"Set me up for evolve"* | `evolve status`, then `evolve init` if not already initialized |
| *"Is evolve set up?"* | `evolve status` |
| *"Learn from my recent sessions"* | `evolve import --limit 5` (after disclosing the path + count) |
| *"What suggestions are there?"* | `evolve proposals` |
| *"Explain that proposal"* | `evolve proposal <id>` — explains target file, rationale, evidence quote, risk, confidence, diff |
| *"Show me the diff"* | `evolve apply <pid> --dry-run` |
| *"Apply it"* | After a dry-run + your explicit yes: `evolve apply <pid>` |
| *"Which surfaces are evolvable?"* | `evolve capability` |

The agent will **always confirm** before anything that writes the cloud or your
local files (`init`, `import`, `apply`, `capability --auto-apply true`).
`apply` is a two-step ritual — dry-run, you say yes, then apply — and there is
no `rollback` command. To undo an applied proposal, delete the
`<!-- evolvor:chg_… -->` chunk the apply added to your runtime file.

## Limits & expectations

- **Zero proposals is normal** on a freshly-deployed environment until the gene
  library is seeded. Your `evolve import` will report `signals=N, proposals=0`
  and that's correct.
- **Sessions leave your machine** during `evolve import`. The skill discloses the
  path and session count before asking for confirmation.
- **The skill never edits your runtime files directly.** Only `evolve apply` writes
  to `AGENTS.md` / `CLAUDE.md`, and only on your explicit yes after a dry-run.
- **No rollback command.** Applied proposals land as removable
  `<!-- evolvor:chg_… -->` chunks. Delete the chunk to revert.

## Manual acceptance tests

For Trae specifically, `trae/MANUAL_TESTS.md` ships an 11-step manual journey
(discovery, description match, confirmation gates, dry-run ritual, bogus-command
refusal, on-demand silence, cross-IDE `.agents/skills/` fallback) that a tester
runs in a real Trae chat. The reporting template at the bottom lets multiple
runs be compared.

## Downloads

Signed TOS URLs, refreshed periodically. Current set: see
[`evolve_skill/QUICKSTART.md`](../QUICKSTART.md) for the live links.

If the URL in QUICKSTART has expired, ask the operator to re-publish via
`python3 evolve_skill/scripts/build_upload_zips.py --label vN --days 30`.

## When to drop down to the CLI

If you want to script the lifecycle, run it from CI, or batch-apply across many
agents, see [Evolve CLI](evolve-cli.md). The skill is just a conversational
wrapper around the same commands.
