# Evolve Skill — user journeys

Each journey is: a user utterance → what the skill should do → the CLI calls →
confirmations → the explanation it gives. These double as the acceptance script for
the ECS tests. "CC" = Claude Code (`SKILL.md`), "OC" = OpenClaw (`SKILL.toml`); a
journey applies to both unless noted.

Legend: 🟢 read-only (no confirm) · 🟡 confirm first · 🔴 confirm + show diff first.

---

## J1 — First-time setup ("set me up for evolve")
1. 🟢 `evolve status` — expect "No Evolve workspace…" (not initialized).
2. Resolve flags: connector from runtime; runtime_root/base_url/account/user from `EVOLVE_*` env or ask. Propose `agent_id=<connector>-main`. (No `--env` flag — the backend environment is baked into the CLI at install time.)
3. 🟡 Confirm the resolved init command, then `evolve init …`.
4. 🟢 `evolve status` → expect `capability_synced: True`, `cloud_reachable: True`.
5. Report: where `~/.evolve/config.yaml` was written, target count, capability_id.

**Edge:** init prints `connector 'claude_code' found no capabilities under R` → wrong runtime-root (no CLAUDE.md/AGENTS.md). Re-ask for the correct root; do not proceed.

## J2 — Already set up ("is evolve configured?")
1. 🟢 `evolve status` → summarize connector, runtime_root, capability_synced, pending_proposals, last_apply. No writes, no confirm.

## J3 — Re-sync after surfaces changed ("I added a new memory file / refresh evolve")
1. 🟢 `evolve status` to confirm it's set up.
2. 🟡 Confirm, then `evolve init … --refresh` (re-discovers surfaces; new file flips `usable`).
3. Report new target count vs before.

## J4 — Learn from recent sessions ("learn from what I've been doing")
1. 🟢 `evolve status` (must be set up; else → J1).
2. 🟡 Confirm scope: state it uploads session logs to the cloud; suggest `--limit 5` for a first run. Tell the user the count.
3. `evolve import --limit 5` → stream the poll; report `signals / proposals / expressions`.
4. If proposals > 0 → `evolve proposal <import_id>` and offer to explain (→ J7).
5. If proposals == 0 → explain the sessions were benign (no failures to learn from); **not** an error.

## J5 — Import a specific file or window ("import just yesterday's session X")
1. 🟡 Confirm. Use `--from <path>` and/or `--session-id <id>` and/or `--limit`.
2. Same reporting as J4. If the path has no sessions → "no sessions found to import"; ask for the right path.

## J6 — Background import ("kick it off, I'll check later")
1. 🟡 Confirm, then `evolve import --no-wait` → returns `import_id` immediately.
2. Tell the user the analysis runs async; check later with `evolve proposal <import_id>` (→ J7).

## J7 — Explain a proposal ("what does this suggestion mean?")
1. 🟢 `evolve proposals` to find the id (or `evolve proposal <import_id>` for one import).
2. Explain with the rubric: proposal_id (+import_id), target file/surface, op, rationale, evidence (the real quote), risk, confidence, the diff path, recommended next step.
3. Never paraphrase beyond the CLI output; if a field is absent, say so.

## J8 — Browse proposals by state ("what's still pending / what did I already apply?")
1. 🟢 `evolve proposals --status not_applied` (or `applied` / `pending`), `--limit N`.
2. Summarize each as one line; offer to drill into any (→ J7).

## J9 — Preview only ("show me the change but don't touch anything")
1. 🟢 `evolve proposal <import_id>` (renders diffs under `~/.evolve/previews/`) **or** 🟢 `evolve apply <pid> --dry-run` for one proposal.
2. Show the unified diff; emphasize nothing was written.

## J10 — Apply an approved proposal ("looks good, apply it")
1. 🔴 `evolve apply <pid> --dry-run` → show the diff.
2. State plainly: **no rollback command**; apply writes a removable `<!-- evolvor:chg_… -->` chunk (append) or edits in place (replace).
3. Get explicit "yes" → `evolve apply <pid>`.
4. 🟢 `evolve proposals --status applied` to confirm it flipped.
5. Report which file changed and that Claude Code/OpenClaw re-reads it next session (no restart).

## J11 — Apply when a target isn't on this runtime
- During apply, `skip <target_id>: not a known runtime target` for an expression → explain that proposal targets a surface this runtime doesn't expose; the rest still applied. Not a failure.

## J12 — Auto-apply policy ("stop asking me for low-risk memory edits")
1. 🟢 `evolve capability` to list surfaces + current auto_apply.
2. 🟡 Warn: auto-apply lets future proposals on that surface apply without review. Confirm.
3. `evolve capability <target_id> --auto-apply true`; read it back.

## J13 — Turn auto-apply back off ("I want to review everything again")
1. 🟡 `evolve capability <target_id> --auto-apply false`; confirm the change.

## J14 — Not initialized yet (any command before init)
- Any command returns "No Evolve workspace at ~/.evolve/config.yaml" → route to J1; don't retry the original command blindly.

## J15 — Backend unreachable
- `evolve status` shows `cloud_reachable: False`, or a command fails `… (HTTP …)` → tell the user it's a backend/`--base-url`/identity problem; surface the exact error; suggest checking `EVOLVE_BASE_URL` and that the backend is up. Do not loop-retry.

## J16 — Wrong/ambiguous runtime root
- init `found no capabilities` → the root has no surface files. For CC, default to the project dir; for OC, `~/.openclaw/workspace`. Re-confirm and retry.

## J17 — "Just evolve everything for me" (over-broad request)
- Decline to blanket-apply. Walk the lifecycle: import → proposals → explain each → apply one at a time with dry-run+confirm. Never batch-apply without per-proposal review (unless a surface is explicitly auto-apply, J12).

## J18 — User asks for a command that doesn't exist ("run evolve rollback / evolve approve")
- Explain those commands don't exist. Rollback is manual (delete the `evolvor` chunk); "approve" is folded into `apply`. Offer the real path.

## J19 — User asks the skill to edit CLAUDE.md/SOUL.md directly ("just add this line yourself")
- Refuse to hand-edit a runtime surface. Explain edits must flow through a proposal + `evolve apply` so they're tracked, reversible, and reported to the cloud. Offer to import evidence so the cloud proposes it.

## J20 — Cross-runtime mental model ("does this work the same in OpenClaw / Cursor?")
- Explain: same seven commands and lifecycle everywhere; only the connector + surface files differ (CC: CLAUDE.md…; OC: AGENTS.md/SOUL.md/MEMORY.md…). One skill concept, one CLI; per-runtime packaging (SKILL.md vs SKILL.toml). Trae/Cursor add a thin manifest later.

## J21 — Smoke / health check ("is evolve healthy end to end?")
1. 🟢 `evolve status` → set up + reachable.
2. 🟢 `evolve capability` → surfaces present.
3. 🟢 `evolve proposals --limit 3` → API answers.
- Report green/red per check; no writes.

## J22 — Dry-run a proposal you won't apply ("I'm just curious what it'd do")
- 🟢 `evolve apply <pid> --dry-run`, show diff, stop. No confirm needed (no write).

---

## Adversarial / edge journeys (from coco review)

## J23 — Stale approval after switching proposals ("yes apply it")
1. 🟢 `evolve apply <pid-A> --dry-run` → show diff for A.
2. 🟢 `evolve apply <pid-B> --dry-run` → show diff for B.
3. User says "yes apply it" → do **not** apply. Ask for approval that names the proposal: "yes, apply <pid-B>".
- Key: approval binds to the latest shown proposal_id/target/op/diff, never to a dangling "it".

## J24 — Diff drift between preview and apply ("apply the one I previewed earlier")
1. Re-run 🟢 `evolve apply <pid> --dry-run` immediately before writing.
2. If the diff differs from what the user saw earlier, stop and re-confirm with the fresh diff.
- Key: a stale preview is not consent; the diff shown at confirm time must be the one applied.

## J25 — Re-apply / idempotency ("apply that same proposal again")
1. 🟢 `evolve proposals --status applied` — if `<pid>` is already applied, warn that re-applying may duplicate the append chunk (or repeat an in-place replace).
2. Only proceed on an explicit confirm of the repeated write.
- Key: never treat re-apply as harmless.

## J26 — Proposal id from another agent/account ("apply this id I copied")
1. 🟢 `evolve status` (show agent_id/connector/runtime_root), then 🟢 `evolve apply <foreign_pid> --dry-run`.
2. `proposal … not found` → it likely belongs to another agent/account/env; explain, don't retry.
3. Previews but targets unknown surfaces → stop, explain the mismatch.
- Key: prove a copied id belongs to this runtime before applying.

## J27 — Multi-expression proposal, mixed targets ("apply this one with several edits")
1. 🔴 `evolve apply <pid> --dry-run` → show **all** expression diffs; summarize each (target, op, risk, exists-locally?).
2. Confirm the whole proposal + target list, then `evolve apply <pid>`.
- Key: the user must understand every expression, not just the first diff.

## J28 — Partial apply / cloud-reporting failure ("apply failed halfway")
1. 🔴 `evolve apply <pid>` (after the normal ritual). If it prints some `applied …` lines then errors → stop.
2. 🟢 `evolve status` + 🟢 `evolve proposals --status applied` to see what actually landed.
- Key: local files may have changed before cloud reporting finished; inspect the journal/targets before any retry.

## J29 — Network timeout mid-apply ("backend timed out while applying")
1. On HTTP timeout, do **not** auto-retry.
2. 🟢 `evolve status`, 🟢 `evolve proposals --status applied`, then 🟢 `evolve apply <pid> --dry-run` to see the current local diff before asking whether to retry.
- Key: distinguish cloud state from local file state before retry.

## J30 — Manual surface edit after sync ("I hand-edited CLAUDE.md; evolve looks stale")
1. 🟢 `evolve status` + 🟢 `evolve capability`.
2. 🟡 Confirm, then `evolve init … --refresh` to re-discover surfaces + rebind digests.
- Key: refresh bindings before previewing/applying against a changed surface (the apply drift-check keys on the digest).

## J31 — Very large import ("import all my sessions")
1. Warn that sessions leave the machine and a huge import is slow.
2. 🟡 Confirm a bounded first pass: `evolve import --from <path> --limit 20`; offer `--no-wait` for the full async run.
- Key: never surprise the user with a bulk upload; prefer explicit path + bounded limit.

## J32 — Time-window import ("learn only from last week")
1. 🟡 Confirm the window, then `evolve import --started-at <ts> --ended-at <ts> --limit N`, then `evolve proposal <import_id>`.
- Key: state the exact window before upload.

## J33 — Auto-apply surprise ("why did this change without asking?")
1. 🟢 `evolve capability` → find surfaces with `auto_apply=True`; 🟢 `evolve proposals --status applied` to show what landed.
2. Offer 🟡 `evolve capability <target_id> --auto-apply false`.
- Key: explain auto-apply as a prior policy choice; never hand-edit the file to "undo".

## J34 — Cross-runtime surface mismatch ("this proposal targets MEMORY.md but I'm in Claude Code")
1. 🟢 `evolve status` + 🟢 `evolve capability` (list local targets), then 🟢 `evolve apply <pid> --dry-run`.
2. If the target is skipped/absent → it belongs to another runtime's surface; don't apply. Re-init with the right connector/root only after confirming.
- Key: a cross-runtime proposal must never silently write the wrong agent's surface.
