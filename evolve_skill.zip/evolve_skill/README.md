# Evolve Skill

The natural-language **entrance point** that connects a coding agent to the
self-evolve service. It wraps the deterministic [`evolve` CLI](cli/) (shipped in
the same folder) so a user can, in plain language, set up evolve, learn from past
sessions, review and explain evolution proposals, preview a change, and apply an
approved proposal to the agent's own instruction/memory files — all without the
agent ever hand-editing those files or inventing proposals.

> **Setup / teardown:** see [`INSTALL.md`](INSTALL.md) for the conversational install
> (one-line `curl` + signed TOS link) and `bash uninstall.sh` to remove. The
> `install.sh` / `uninstall.sh` scripts in this folder are what those flows run.

> The cloud (`self_evolve` backend) does the thinking — session evidence → signals →
> genes → expressions → critic → **proposals**. The CLI does the deterministic local
> work (discover surfaces, upload evidence, render diffs, apply). The skill is the
> conversational layer that maps intent to CLI commands and explains results.

## Layout — one skill concept, one shared core, per-runtime manifests

```
evolve_skill/
  cli/                 # the `evolve` CLI Python package (installable: pip install ./cli)
    src/evolve_cli/    # source for the `evolve` console script
    pyproject.toml
  shared/
    PLAYBOOK.md        # CANONICAL behavior spec — the source of truth (change here first)
    contract.json      # machine-readable command/policy contract the tests validate against
  claude_code/
    SKILL.md           # Claude Code manifest (YAML frontmatter + instructions; runs `evolve` via Bash)
  openclaw/
    SKILL.toml         # OpenClaw manifest ([skill] + prompts[] + [[tools]] shell entries)
  trae/
    SKILL.md           # Trae manifest (YAML frontmatter + Markdown body; Trae's built-in terminal runs `evolve`)
    MANUAL_TESTS.md    # 10-step manual acceptance journey for Trae (covers what the lifecycle smoke can't)
  journeys/
    USER_JOURNEYS.md   # 34 user journeys (happy paths, errors, refusals, adversarial edges)
  tests/
    test_skill_docs.py    # drift guard: manifests vs the real CLI + the contract
    eval_suite.py         # lifecycle smoke — runs `cc_happy / oc_happy / trae_happy` against the mock backend
    mock_backend.py       # self-contained mock self_evolve backend (no case_platform/TOS)
    ecs_skill_test.py     # E2E: drive the skill on real ECS with Claude Code/OpenClaw on Doubao
  install.sh            # conversational installer (also runs standalone via curl)
  uninstall.sh          # safe, prompt-driven removal
  INSTALL.md            # user-facing setup + teardown guide
```

The three runtimes package skills differently (Claude Code reads markdown
instructions; OpenClaw needs TOML tool definitions; Trae uses Claude-shape
markdown but separates tools out into MCP), so each gets a thin manifest, but
all derive from `shared/PLAYBOOK.md` so behavior stays identical.

## The command surface (exactly seven)

`init`, `status`, `import`, `proposals`, `proposal`, `capability`, `apply`. `apply` is
the only command that writes a runtime file (a removable `<!-- evolvor:chg_… -->`
chunk). There is **no** `rollback`/`reviews`/`approve` command — the `prd.md` in this
folder is an early sketch and is wrong about command names; trust `PLAYBOOK.md`.

## Install

The customer-facing path is in [`INSTALL.md`](INSTALL.md) — one line:

```bash
curl -fsSL "https://ark-self-evolve-stg.tos-cn-beijing.volces.com/evolve_skill/latest/install.sh" | bash
```

If you've already extracted the bundle (or are working inside this repo), run the
installer directly — it walks you through env, identity, and runtime choice:

```bash
cd evolve_skill && bash install.sh
```

Manual install (skip the wizard):

```bash
pip install ./cli                                     # installs the `evolve` CLI

# Claude Code
mkdir -p ~/.claude/skills/evolve-setup
cp claude_code/SKILL.md ~/.claude/skills/evolve-setup/SKILL.md
cp -r shared            ~/.claude/skills/evolve-setup/shared

# OpenClaw
mkdir -p ~/.openclaw/workspace/skills/evolve-setup
cp openclaw/SKILL.toml ~/.openclaw/workspace/skills/evolve-setup/SKILL.toml
cp -r shared           ~/.openclaw/workspace/skills/evolve-setup/shared

# Trae — install into BOTH project-local paths so it works regardless of
# which Settings toggle is on (the .trae/skills copy wins on collision).
mkdir -p "$PROJECT/.trae/skills/evolve-setup" "$PROJECT/.agents/skills/evolve-setup"
cp trae/SKILL.md  "$PROJECT/.trae/skills/evolve-setup/SKILL.md"
cp trae/SKILL.md  "$PROJECT/.agents/skills/evolve-setup/SKILL.md"
cp -r shared      "$PROJECT/.trae/skills/evolve-setup/shared"
cp -r shared      "$PROJECT/.agents/skills/evolve-setup/shared"
```

The skill needs `evolve` on PATH and these env vars (or the skill will ask for them
at `init`): `EVOLVE_BASE_URL` and `EVOLVE_API_KEY` (Ark API key — required by any
real backend; falls back to `ARK_API_KEY`). Optional: `EVOLVE_RUNTIME_ROOT`,
`EVOLVE_AGENT_ID`, `EVOLVE_INSECURE=1` (allow plaintext `http://`
for the stg gateway until prod HTTPS lands).

To uninstall: `bash uninstall.sh` (asks before each step).

## Test

```bash
# doc/contract drift guards (fast, offline)
python -m pytest tests/test_skill_docs.py -q

# lifecycle smoke against the mock backend — runs cc_happy + oc_happy + trae_happy
# in parallel, no real backend needed
python tests/eval_suite.py --only cc_happy oc_happy trae_happy

# trae-specific manual acceptance (requires running Trae IDE + a stg Ark key) —
# the only layer eval_suite.py can't cover: actual agent behavior in Trae chat
cat trae/MANUAL_TESTS.md            # 10-step journey to run in Trae

# real ECS, agent driven by Doubao pro (provisions + tears down a box)
source /opt/code/playground/commands_autoPE.sh
PYTHONPATH=/opt/code/self_evolve/benchmark:/opt/code/ark_navigator/case_platform/src \
  python tests/ecs_skill_test.py --framework both
```
