#!/usr/bin/env bash
# evolve_skill uninstaller — removes the skill manifest(s), the evolve CLI, and
# (optionally) the local CLI workspace. Always asks before each destructive step
# unless EVOLVE_NONINTERACTIVE=1, in which case the defaults below apply.
#
# Defaults (non-interactive):
#   • remove the skill manifest dirs that exist
#   • pip-uninstall the evolve CLI
#   • DO NOT touch ~/.evolve (preserves config + apply journal)
#   • DO NOT touch the runtime files (CLAUDE.md, AGENTS.md, …); applied
#     proposals stay in place. Remove them by deleting their <!-- evolvor:chg_… -->
#     chunk in the file.
#
# Environment overrides:
#   EVOLVE_NONINTERACTIVE=1   skip prompts, accept defaults
#   EVOLVE_REMOVE_HOME=1      also delete ~/.evolve (config + journal)
#   EVOLVE_REMOVE_ENVFILE=1   also delete ~/.evolve-skill.env
#   EVOLVE_KEEP_CLI=1         skip the pip uninstall step
#
set -euo pipefail

# Guard against pathological env — without HOME, every path below collapses to
# something we'd refuse, but bail explicitly so the user sees a clear error.
[ -n "${HOME:-}" ] || { echo "HOME is unset; refusing to run." >&2; exit 1; }
case "$HOME" in
  /|"") echo "HOME=$HOME is unsafe; refusing to run." >&2; exit 1 ;;
esac

if [ -t 1 ]; then
  c_bold=$'\033[1m'; c_dim=$'\033[2m'; c_grn=$'\033[32m'; c_ylw=$'\033[33m'
  c_red=$'\033[31m'; c_off=$'\033[0m'
else
  c_bold=""; c_dim=""; c_grn=""; c_ylw=""; c_red=""; c_off=""
fi
say()  { printf '%s\n' "$*"; }
hd()   { printf '\n%s%s%s\n' "$c_bold" "$*" "$c_off"; }
ok()   { printf '%s✓%s %s\n' "$c_grn" "$c_off" "$*"; }
warn() { printf '%s!%s %s\n' "$c_ylw" "$c_off" "$*"; }
die()  { printf '%s✗%s %s\n' "$c_red" "$c_off" "$*" >&2; exit 1; }

NONINT="${EVOLVE_NONINTERACTIVE:-0}"
confirm() {
  # confirm "Question" default(y|n)
  local _q="$1" _def="${2:-y}" _v
  if [ "$NONINT" = "1" ]; then
    [ "$_def" = "y" ] && return 0 || return 1
  fi
  local _hint="[Y/n]"; [ "$_def" = "n" ] && _hint="[y/N]"
  printf '%s%s%s %s ' "$c_bold" "$_q" "$c_off" "$_hint"
  read -r _v
  [ -z "$_v" ] && _v="$_def"
  case "$_v" in y|Y|yes|YES) return 0 ;; *) return 1 ;; esac
}

hd "Evolve Skill — uninstaller"
say "${c_dim}I will ask before each step. Applied proposals (the${c_off}"
say "${c_dim}<!-- evolvor:chg_… --> chunks in CLAUDE.md / AGENTS.md) are NEVER touched.${c_off}"

# --- step 1: skill manifest dirs --------------------------------------------
CC_DIR="$HOME/.claude/skills/evolve-setup"
OC_DIR="$HOME/.openclaw/workspace/skills/evolve-setup"

remove_dir_if_safe() {
  # remove_dir_if_safe <path> <label>
  local d="$1" lbl="$2"
  [ -d "$d" ] || { say "${c_dim}  (no ${lbl} skill at ${d})${c_off}"; return; }
  # Refuse to nuke a path with surprising depth — it must be exactly the skill dir.
  case "$d" in
    "$HOME/.claude/skills/evolve-setup"|"$HOME/.openclaw/workspace/skills/evolve-setup") : ;;
    *) die "Refusing to remove unexpected path: $d" ;;
  esac
  if confirm "Remove ${lbl} skill at ${d}?" y; then
    rm -rf -- "$d"
    ok "Removed ${d}"
  else
    warn "Kept ${d}"
  fi
}
hd "1. Skill manifests"
remove_dir_if_safe "$CC_DIR" "Claude Code"
remove_dir_if_safe "$OC_DIR" "OpenClaw"

# --- step 2: pip uninstall the evolve CLI ------------------------------------
hd "2. evolve CLI (pip package)"
PYBIN="${PYTHON:-python3}"
if [ "${EVOLVE_KEEP_CLI:-0}" = "1" ]; then
  say "${c_dim}  EVOLVE_KEEP_CLI=1 — skipping pip uninstall.${c_off}"
elif ! command -v "$PYBIN" >/dev/null; then
  warn "python3 not found — skipping pip uninstall."
elif ! "$PYBIN" -m pip show evolve-cli >/dev/null 2>&1; then
  say "${c_dim}  evolve-cli is not installed in this Python.${c_off}"
else
  if confirm "pip uninstall evolve-cli from $($PYBIN -c 'import sys;print(sys.prefix)')?" y; then
    "$PYBIN" -m pip uninstall -y -q evolve-cli || warn "pip uninstall returned non-zero."
    ok "evolve-cli uninstalled."
  else
    warn "Kept evolve-cli."
  fi
fi

# --- step 3: env file --------------------------------------------------------
ENVFILE="$HOME/.evolve-skill.env"
hd "3. Shell env file"
if [ ! -f "$ENVFILE" ]; then
  say "${c_dim}  (no env file at ${ENVFILE})${c_off}"
else
  default_yn="n"; [ "${EVOLVE_REMOVE_ENVFILE:-0}" = "1" ] && default_yn="y"
  if confirm "Remove ${ENVFILE}?" "$default_yn"; then
    rm -f "$ENVFILE"
    ok "Removed ${ENVFILE}"
  else
    warn "Kept ${ENVFILE} (don't forget to remove 'source ${ENVFILE}' from your shell rc)."
  fi
fi

# --- step 4: CLI workspace ~/.evolve -----------------------------------------
EVOLVE_HOME_DIR="${EVOLVE_HOME:-$HOME/.evolve}"
hd "4. CLI workspace at ${EVOLVE_HOME_DIR}"
if [ ! -d "$EVOLVE_HOME_DIR" ]; then
  say "${c_dim}  (nothing to remove)${c_off}"
else
  case "$EVOLVE_HOME_DIR" in
    "$HOME/.evolve"|"$HOME/.evolve/") : ;;
    *) warn "EVOLVE_HOME is non-default; refusing to delete ${EVOLVE_HOME_DIR}." ;;
  esac
  if [ "$EVOLVE_HOME_DIR" = "$HOME/.evolve" ]; then
    default_yn="n"; [ "${EVOLVE_REMOVE_HOME:-0}" = "1" ] && default_yn="y"
    say "${c_dim}  This holds config.yaml, capability snapshot, diff previews, and the apply journal.${c_off}"
    if confirm "Remove ${EVOLVE_HOME_DIR}?" "$default_yn"; then
      rm -rf -- "$EVOLVE_HOME_DIR"
      ok "Removed ${EVOLVE_HOME_DIR}"
    else
      warn "Kept ${EVOLVE_HOME_DIR}"
    fi
  fi
fi

# --- step 5: friendly nag about evolvor chunks -------------------------------
hd "5. Applied proposals (manual)"
say "Applied proposals are removable chunks in your runtime files, e.g.:"
say "  ${c_dim}<!-- evolvor:chg_abc123 -->${c_off}"
say "  ${c_dim}…content…${c_off}"
say "  ${c_dim}<!-- /evolvor:chg_abc123 -->${c_off}"
say "Find them with: ${c_bold}grep -rl 'evolvor:chg_' \"\$HOME\" \"\$PWD\"${c_off}"
say "Delete the whole chunk to revert. ${c_ylw}replace-op proposals are NOT wrapped${c_off} —"
say "use git history (or the chunk you saved) to restore those."

hd "Done."
