# evolve-cli

Local deterministic kernel for agent self-evolution. A lightweight client for the
case_platform `self_evolve` backend — it talks to the backend over HTTP only and
never imports the server package.

## Install

```bash
pip install -e .          # provides the `evolve` command
```

## Quickstart (Openclaw)

```bash
# 1. discover the runtime's evolvable surfaces and sync them to the cloud
evolve init --connector openclaw --agent-id openclaw-main \
  --runtime-root ~/.openclaw/workspace \
  --base-url https://<case-platform-host> --account-id <acct> --user-name <you>

evolve status

# 2. import session logs as evidence (async; polls until done)
evolve import --from ~/.openclaw/agents/main/sessions --format jsonl

# 3. review proposals (renders local diffs under ~/.evolve/previews/, no writes)
evolve proposals
evolve proposal <import_id>

# 4. capability auto-apply policy
evolve capability                       # list
evolve capability prompt.soul --auto-apply true

# 5. apply (the only command that writes the runtime)
evolve apply <proposal_id> --dry-run    # preview the file diffs
evolve apply <proposal_id>              # write + report results to the cloud
```

## Workspaces

- `~/.evolve/` — CLI state (config, capability snapshot, binding, previews, apply-journal).
- `--runtime-root` — the agent's real files (read at init, written on apply).
- cloud `self_evolve/imports/{id}/` — managed by the backend.

## Connectors

`evolve_cli/connectors/` — one per runtime kind. `openclaw.py` is implemented;
add a class with `discover_capabilities` / `read_sessions` / `read_target_content`
/ `preview_edit` / `apply_edit` / `target_by_id` and register it in `connectors/__init__.py`.

## Design

See `case_platform/.../modules/self_evolve/CLI_DESIGN.md` for the full design,
the API mapping, and the gap analysis.
