"""Render proposals and local diffs for the user."""

from __future__ import annotations

import difflib
from typing import Any, Dict, List


def unified_diff(before: str, after: str, path: str) -> str:
    diff = difflib.unified_diff(
        before.splitlines(keepends=True),
        after.splitlines(keepends=True),
        fromfile=f"a/{path}",
        tofile=f"b/{path}",
    )
    return "".join(diff) or "(no change)"


def proposal_summary_line(p: Dict[str, Any]) -> str:
    pid = p.get("proposal_id", "?")
    risk = p.get("risk", "?")
    decision = p.get("decision", "?")
    conf = p.get("confidence", "")
    summary = (p.get("summary") or "").strip().replace("\n", " ")
    conf_s = f" conf={conf}" if conf != "" else ""
    return f"{pid}  risk={risk}{conf_s}  [{decision}]  {summary[:96]}"


def render_proposal_detail(p: Dict[str, Any]) -> str:
    lines: List[str] = [proposal_summary_line(p)]
    if p.get("rationale"):
        lines.append(f"  rationale: {p['rationale'][:300]}")
    for e in p.get("expressions", []):
        target = e.get("target", {})
        lines.append(
            f"  - [{e.get('op', '?')}] {target.get('target_id', '?')} "
            f"({target.get('display_name', '')})  status={e.get('status', '?')}"
        )
        if e.get("evidence"):
            lines.append(f"      evidence: {str(e['evidence'])[:160]}")
        after = (e.get("edit", {}) or {}).get("after", "")
        if after:
            lines.append(f"      after: {after[:160]!r}")
    return "\n".join(lines)
