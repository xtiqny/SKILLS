"""Thin HTTP client for the case_platform ``self_evolve`` actions.

The backend auto-creates a REST route per action at ``/{TopActionKey}`` where
``TopActionKey = PascalCase("case_platform_v1_self_evolve_<action>")`` and the body
is the action's request model. Responses are wrapped as
``{"ResponseMetadata": {...}, "Result": {...}}``. Request bodies accept snake_case
keys (the server models set ``populate_by_name=True``); result envelope fields are
PascalCase while the nested cli_prd objects (ProposalObject, …) are snake_case.
"""

from __future__ import annotations

from typing import Any, Dict, Optional

import httpx

API_ACTION_PREFIX = "case_platform"
API_VERSION = "v1"
GROUP = "self_evolve"


def to_pascal(snake: str) -> str:
    return "".join(part[:1].upper() + part[1:] for part in snake.split("_"))


def action_key(action: str) -> str:
    return to_pascal(f"{API_ACTION_PREFIX}_{API_VERSION}_{GROUP}_{action}")


def rget(result: Dict[str, Any], key: str, default: Any = None) -> Any:
    """Read a result field tolerating snake_case or PascalCase envelope keys."""
    if key in result:
        return result[key]
    pascal = to_pascal(key)
    return result.get(pascal, default)


class EvolveAPIError(RuntimeError):
    pass


class EvolveClient:
    def __init__(
        self,
        base_url: str,
        account_id: str,
        user_id: str,
        user_name: str = "",
        api_key: str = "",
        timeout: float = 60.0,
    ):
        self.base_url = base_url.rstrip("/")
        self.headers = {
            "Content-Type": "application/json",
            "X-Top-Account-Id": account_id,
            "X-Top-User-Id": user_id,
        }
        if api_key:
            # The agent's Ark API key. The backend verifies it via the Volcengine
            # OpenAPI (GetAPIKeyMeta) and stamps auth_source=ark_api_key, which the
            # self_evolve CLI actions (register/import/apply/…) require. Without it,
            # the request resolves to TOP-gateway auth and the backend returns 403.
            self.headers["Authorization"] = f"Bearer {api_key}"
        if user_name:
            # Best-effort identity for the self_evolve admin allowlist; real
            # deployments derive user_name via the Top gateway.
            self.headers["X-Top-User-Name"] = user_name
        # Two URL schemes. Against the Volcengine API gateway the route is a fixed
        # path (``/case-platform``) and the action travels only in the ``?Action=``
        # query. Against a bare backend / the local harness each action is its own
        # REST path (``/{ActionKey}``). Auto-detect the gateway from the base URL so
        # a customer only has to pass their gateway endpoint.
        self.gateway = "apigateway" in self.base_url or self.base_url.rstrip("/").endswith("/case-platform")
        self._client = httpx.Client(timeout=timeout)

    def call(self, action: str, payload: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        key = action_key(action)
        url = self.base_url if self.gateway else f"{self.base_url}/{key}"
        try:
            resp = self._client.post(url, json=payload or {}, headers=self.headers, params={"Action": key})
        except httpx.HTTPError as e:
            # connect/timeout/transport failures must surface as a clean message,
            # not a traceback — the CLI/skill maps this to "backend unreachable".
            raise EvolveAPIError(f"{action}: cannot reach backend at {self.base_url} ({type(e).__name__}: {e})") from e
        try:
            body = resp.json()
        except Exception as e:  # noqa: BLE001
            raise EvolveAPIError(f"{action}: non-JSON response (HTTP {resp.status_code}): {resp.text[:300]}") from e
        meta = body.get("ResponseMetadata") or body.get("response_metadata") or {}
        error = meta.get("Error") or meta.get("error")
        if resp.status_code >= 400 or error:
            msg = (error or {}).get("Message") or (error or {}).get("message") or resp.text[:300]
            raise EvolveAPIError(f"{action} failed (HTTP {resp.status_code}): {msg}")
        return body.get("Result") or body.get("result") or {}

    def close(self) -> None:
        self._client.close()
