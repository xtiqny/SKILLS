"""The ``~/.evolve/`` CLI-state workspace (workspace #1 of the three).

Holds everything the CLI needs locally: the active config, the last-synced
CapabilityMap, the target<->file binding (with content digests for drift checks),
rendered proposal previews, and an apply-journal used for rollback.

State is scoped per connector so multiple agents on one machine don't collide:

    ~/.evolve/<connector>/
      config.yaml                   # agent_id, env, connector, runtime_root, cloud, identity
      capability.generated.json     # last CapabilityMap registered with the cloud
      local-binding.generated.json  # target_id -> absolute path + content digest
      previews/{import_id}/*.diff   # rendered diffs from `evolve proposal`
      apply-journal.jsonl           # one record per applied expression (for rollback)

``$EVOLVE_HOME`` overrides the whole scheme (used verbatim, never sharded).
"""

from __future__ import annotations

import hashlib
import json
import os
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml

# The CLI-state workspace. Defaults to ``~/.evolve`` but can be relocated with the
# ``EVOLVE_HOME`` env var — handy for CI/test isolation and running several agents
# on one machine without their workspaces colliding.
# The backend environment this CLI build is bound to. Baked into the artifact
# at publish time: the stg bucket ships "stg", the prod bucket ships "prod"
# (scripts/build_upload_zips.py + scripts/publish_bundle.py rewrite THIS single
# line before packaging — keep it a bare `_BOUND_ENV = "..."` assignment so the
# string replace stays trivial). There is deliberately no customer `--env` flag.
_BOUND_ENV = "prod"

# Env -> gateway base URL. Baked in so a copy-and-go install needs ONLY an Ark
# API key: the artifact already knows its own backend. `$EVOLVE_BASE_URL` (and
# the `--base-url` flag) still override this for the E2E test injection and local
# dev, but customers never have to supply or be asked for a URL.
_ENV_BASE_URL = {
    "stg": "https://sd8fq9c4cuac30otu789g.apigateway-cn-beijing.volceapi.com/case-platform",
    "prod": "https://prompt-pilot.cn-beijing.volces.com/case-platform",
}
# Falls back to localhost only if _BOUND_ENV is somehow unknown (dev builds).
DEFAULT_BASE_URL = _ENV_BASE_URL.get(_BOUND_ENV, "http://localhost:8000")

# --- state directory: project-local discovery + connector scoping ----------- #
# Where CLI state lives, resolved in this precedence (highest first):
#   1. ``$EVOLVE_HOME`` — explicit, wins outright and is used flat (no connector
#      subdir). CI/test isolation + the vefaas E2E rely on this.
#   2. A project-local ``.evolve/`` discovered by walking up from cwd (git-style).
#      Needed for sandboxed runtimes (e.g. Trae) that can't write $HOME — `init`
#      creates ``<runtime-root>/.evolve/`` when $HOME isn't writable, and every
#      later command rediscovers it from the project dir. Sharded by connector.
#   3. ``~/.evolve/<connector>/`` — the normal home workspace, scoped by connector
#      so several agents on one machine don't clobber each other.
#   4. legacy ``~/.evolve/`` — back-compat for single-agent installs from before
#      sharding.
_home_env = os.environ.get("EVOLVE_HOME")
_LEGACY_HOME = Path.home() / ".evolve"  # the home base (name kept for compat)
# Pinned base set by `init` once it picks/creates a writable base (project-local
# in a sandbox). Read commands leave this None and rediscover from cwd.
_base_override: Optional[Path] = None

# The module-level path constants below are rebound by ``use_connector()`` once
# the connector is known; all writers reference these names, so one rebind moves
# every artifact (config, capability snapshot, binding, previews, journal).
EVOLVE_HOME: Path
CONFIG_PATH: Path
CAPABILITY_PATH: Path
BINDING_PATH: Path
PREVIEWS_DIR: Path
APPLY_JOURNAL: Path


def _discover_project_base() -> Optional[Path]:
    """Nearest existing ``.evolve/`` walking up from cwd (git-style), else None."""
    try:
        cur = Path.cwd()
    except OSError:
        return None
    for d in (cur, *cur.parents):
        cand = d / ".evolve"
        if cand.is_dir():
            return cand
    return None


def _base_dir() -> Path:
    """The root under which connector shards live (ignored when $EVOLVE_HOME set)."""
    if _base_override is not None:
        return _base_override
    proj = _discover_project_base()
    return proj if proj is not None else _LEGACY_HOME


def _is_writable(p: Path) -> bool:
    """True if ``p`` exists-or-can-be-created and we can write a file in it."""
    try:
        p.mkdir(parents=True, exist_ok=True)
        probe = p / ".write_probe"
        probe.write_text("ok")
        probe.unlink()
        return True
    except OSError:
        return False


def prepare_base_for_init(runtime_root: Path) -> Path:
    """Pick (and pin) the base dir `init` will write to, creating it if needed.

    Reuses an explicit $EVOLVE_HOME or an already-discovered project ``.evolve/``;
    otherwise prefers ``~/.evolve`` when writable and falls back to a project-local
    ``<runtime-root>/.evolve/`` for sandboxes that can't write $HOME. A project-local
    base gets a ``.gitignore`` (``*``) so workspace state never lands in the repo.
    """
    global _base_override
    if _home_env:
        return Path(_home_env).expanduser()
    proj = _discover_project_base()
    if proj is not None:
        _base_override = proj
        return proj
    if _is_writable(_LEGACY_HOME):
        _base_override = _LEGACY_HOME
        return _LEGACY_HOME
    # Sandbox: $HOME isn't writable — keep state next to the project instead.
    local = (runtime_root / ".evolve").expanduser()
    local.mkdir(parents=True, exist_ok=True)
    gi = local / ".gitignore"
    if not gi.exists():
        gi.write_text("*\n")
    _base_override = local
    return local


def _home_for(connector: str) -> Path:
    """Resolve the state dir for ``connector`` honouring the precedence above."""
    if _home_env:
        return Path(_home_env).expanduser()
    base = _base_dir()
    return base / connector if connector else base


def project_local_runtime_root() -> Optional[Path]:
    """The runtime root implied by a project-local ``<root>/.evolve/`` state base.

    When CLI state lives in a project-local ``.evolve/`` (the sandbox / copy-and-go
    case), the runtime root is unambiguously that base's parent — the folder that
    physically contains the ``.evolve/`` we just discovered. Returning it lets a
    read/apply command self-heal after the whole folder is *moved*: the absolute
    ``runtime_root`` persisted in ``config.yaml`` at init is now stale, but the
    on-disk location of ``.evolve/`` still tells us the truth.

    Returns ``None`` when the base is ``$EVOLVE_HOME`` (used flat, tells us nothing
    about the runtime) or the legacy/home ``~/.evolve`` (whose parent is ``$HOME``,
    not a runtime root) — those installs can't self-heal and fall through to the
    caller's drift guard instead.
    """
    if _home_env:
        return None
    base = _base_dir()
    if base == _LEGACY_HOME or base.name != ".evolve":
        return None
    return base.parent


def use_connector(connector: str) -> None:
    """(Re)bind the module-level state paths to ``connector``'s workspace.

    A no-op when ``$EVOLVE_HOME`` is set (that path always wins). ``connector``
    may be "" to fall back to the un-sharded base.
    """
    global EVOLVE_HOME, CONFIG_PATH, CAPABILITY_PATH, BINDING_PATH, PREVIEWS_DIR, APPLY_JOURNAL
    EVOLVE_HOME = _home_for(connector)
    CONFIG_PATH = EVOLVE_HOME / "config.yaml"
    CAPABILITY_PATH = EVOLVE_HOME / "capability.generated.json"
    BINDING_PATH = EVOLVE_HOME / "local-binding.generated.json"
    PREVIEWS_DIR = EVOLVE_HOME / "previews"
    APPLY_JOURNAL = EVOLVE_HOME / "apply-journal.jsonl"


def autodetect_connector() -> Optional[str]:
    """Return the sole connector shard under the active base ``*/config.yaml``.

    Returns None when there are zero or several shards — a lone shard is
    unambiguous (the common single-agent case); anything else needs an explicit
    ``$EVOLVE_CONNECTOR`` / ``--connector`` to disambiguate. Ignores ``$EVOLVE_HOME``
    (that path is used directly, not autodetected). Resolves against the active
    base, so a project-local ``.evolve/`` is honoured just like ``~/.evolve/``.
    """
    if _home_env:
        return None
    base = _base_dir()
    if not base.is_dir():
        return None
    shards = sorted(p.parent.name for p in base.glob("*/config.yaml"))
    return shards[0] if len(shards) == 1 else None


def list_connectors() -> List[str]:
    """All connector shards under the active base (for disambiguation messages)."""
    if _home_env:
        return []
    base = _base_dir()
    if not base.is_dir():
        return []
    return sorted(p.parent.name for p in base.glob("*/config.yaml"))


# Initialise paths from $EVOLVE_CONNECTOR (env-driven); the CLI refines this at
# runtime via use_connector() once init's flag / a read command's resolution runs.
use_connector(os.environ.get("EVOLVE_CONNECTOR", "").strip())


@dataclass
class EvolveConfig:
    agent_id: str = ""
    # Friendly name shown in `evolve status`; not part of the wire identity.
    # Falls back to "" so old configs load fine.
    display_name: str = ""
    # Backend env this config is bound to. Mirrors the baked _BOUND_ENV so a
    # config loaded missing the field matches the artifact; CLI flows always
    # pass an explicit value at init.
    environment: str = _BOUND_ENV
    connector: str = "openclaw"
    runtime_root: str = ""
    base_url: str = DEFAULT_BASE_URL
    # Identity sent to the Top gateway (account/user). user_name drives the
    # self_evolve admin allowlist on the backend.
    account_id: str = ""
    user_id: str = "0"
    user_name: str = ""
    # The agent's Ark API key (Bearer), required by the real backend's
    # require_ark_account gate. Prefer the EVOLVE_API_KEY env var over persisting
    # the secret to config.yaml.
    api_key: str = ""
    capability_id: str = ""

    @staticmethod
    def load() -> "EvolveConfig":
        path = CONFIG_PATH
        if not path.exists():
            # Back-compat: a pre-sharding install kept its config at the legacy
            # un-sharded ~/.evolve/config.yaml. Fall back to it only when the
            # active base IS the home dir (never bleed a home config into a
            # project-local workspace).
            legacy = _LEGACY_HOME / "config.yaml"
            if not _home_env and _base_dir() == _LEGACY_HOME and legacy.exists():
                path = legacy
            else:
                raise FileNotFoundError(f"No Evolve workspace at {CONFIG_PATH}. Run `evolve init` first.")
        data = yaml.safe_load(path.read_text()) or {}
        known = {k: data[k] for k in EvolveConfig().__dict__ if k in data}
        return EvolveConfig(**known)

    def save(self) -> None:
        EVOLVE_HOME.mkdir(parents=True, exist_ok=True)
        CONFIG_PATH.write_text(yaml.safe_dump(asdict(self), sort_keys=True))


def digest_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:32]


def write_capability_snapshot(capabilities: List[Dict[str, Any]]) -> None:
    EVOLVE_HOME.mkdir(parents=True, exist_ok=True)
    CAPABILITY_PATH.write_text(json.dumps(capabilities, ensure_ascii=False, indent=2))


def write_binding(binding: Dict[str, Dict[str, Any]]) -> None:
    EVOLVE_HOME.mkdir(parents=True, exist_ok=True)
    BINDING_PATH.write_text(json.dumps(binding, ensure_ascii=False, indent=2))


def read_binding() -> Dict[str, Dict[str, Any]]:
    if not BINDING_PATH.exists():
        return {}
    return json.loads(BINDING_PATH.read_text())


def preview_dir(import_id: str) -> Path:
    d = PREVIEWS_DIR / import_id
    d.mkdir(parents=True, exist_ok=True)
    return d


@dataclass
class ApplyJournalEntry:
    proposal_id: str
    expression_id: str
    target_id: str
    file_path: str
    op: str
    change_id: str
    before_digest: str
    after_digest: str
    before_bytes_b64: str = ""
    applied_at: str = ""
    extra: Dict[str, Any] = field(default_factory=dict)


def append_journal(entry: ApplyJournalEntry) -> None:
    EVOLVE_HOME.mkdir(parents=True, exist_ok=True)
    with APPLY_JOURNAL.open("a") as f:
        f.write(json.dumps(asdict(entry), ensure_ascii=False) + "\n")


def read_journal() -> List[Dict[str, Any]]:
    if not APPLY_JOURNAL.exists():
        return []
    return [json.loads(line) for line in APPLY_JOURNAL.read_text().splitlines() if line.strip()]


def last_apply() -> Optional[Dict[str, Any]]:
    entries = read_journal()
    return entries[-1] if entries else None
