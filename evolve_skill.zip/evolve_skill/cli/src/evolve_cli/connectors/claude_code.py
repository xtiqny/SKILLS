"""Claude Code connector.

Surfaces are Claude Code's auto-loaded memory files: the project ``CLAUDE.md``
and ``CLAUDE.local.md`` (read from the runtime root), plus the user-level
``~/.claude/CLAUDE.md``. Session logs are the transcript JSONL files under
``~/.claude/projects/{encoded-cwd}/{session}.jsonl``; each line is a typed
record (``user`` / ``assistant`` / ``summary`` / …) whose ``message.content``
is either a string or a list of Anthropic content blocks (``text`` /
``thinking`` / ``tool_use`` / ``tool_result``).

Edits append a delimited, removable "evolvor chunk" to the target file (or do a
single literal replace), exactly like the Openclaw connector — Claude Code
re-reads these markdown files on every run, so an appended block takes effect on
the next session with no restart.
"""

from __future__ import annotations

import json
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from evolve_cli.connectors.base import TargetSpec

# (target_id, surface_type, relpath, display_name, supported_ops, root)
#   root="runtime" → resolved under the configured runtime_root
#   root="home"    → resolved under the user's home (Claude's global memory)
_SURFACES = [
    (
        "memory.project",
        "persistent_memory_file",
        "CLAUDE.md",
        "Project Memory (CLAUDE.md)",
        ["append", "replace"],
        "runtime",
    ),
    (
        "memory.local",
        "persistent_memory_file",
        "CLAUDE.local.md",
        "Local Project Memory",
        ["append", "replace"],
        "runtime",
    ),
    (
        "memory.user",
        "persistent_memory_file",
        ".claude/CLAUDE.md",
        "User Memory (~/.claude/CLAUDE.md)",
        ["append", "replace"],
        "home",
    ),
]

_MAX_TURNS = 60
_MAX_TEXT = 1500


class ClaudeCodeConnector:
    name = "claude_code"

    # --- capabilities ---------------------------------------------------------

    def _resolve_path(self, runtime_root: Path, relpath: str, root: str) -> Path:
        base = Path.home() if root == "home" else runtime_root
        return base / relpath

    def discover_capabilities(self, runtime_root: Path) -> List[TargetSpec]:
        specs: List[TargetSpec] = []
        for target_id, surface_type, relpath, display_name, ops, root in _SURFACES:
            fpath = self._resolve_path(runtime_root, relpath, root)
            specs.append(
                TargetSpec(
                    target_id=target_id,
                    surface_type=surface_type,
                    file_path=str(fpath),
                    display_name=display_name,
                    supported_ops=ops,
                    folder_path=str(fpath.parent),
                    usable=fpath.exists(),
                )
            )
        return specs

    def target_by_id(self, runtime_root: Path, target_id: str) -> Optional[TargetSpec]:
        for spec in self.discover_capabilities(runtime_root):
            if spec.target_id == target_id:
                return spec
        return None

    # --- sessions -------------------------------------------------------------

    def read_sessions(
        self,
        from_path: Optional[Path],
        fmt: str,
        session_ids: Optional[List[str]] = None,
        started_at: Optional[str] = None,
        ended_at: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        files = self._resolve_session_files(from_path, session_ids)
        sessions = [self._parse_session(f) for f in files]
        sessions = [s for s in sessions if s["turn_count"]]
        if limit:
            sessions = sessions[:limit]
        return sessions

    def _resolve_session_files(self, from_path: Optional[Path], session_ids: Optional[List[str]]) -> List[Path]:
        if from_path and from_path.is_file():
            return [from_path]
        base = from_path if (from_path and from_path.is_dir()) else (Path.home() / ".claude" / "projects")
        candidates = list(base.rglob("*.jsonl"))
        if session_ids:
            # Explicit selection: respect what the user asked for, no recency sort.
            wanted = set(session_ids)
            return sorted(p for p in candidates if p.stem in wanted)
        # Default: newest first, so an --limit cap keeps the most recent sessions
        # instead of whichever ones happen to sort early alphabetically.
        return sorted(candidates, key=lambda p: p.stat().st_mtime, reverse=True)

    def _clip(self, text: Any) -> str:
        s = text if isinstance(text, str) else json.dumps(text, ensure_ascii=False, default=str)
        return s if len(s) <= _MAX_TEXT else s[:_MAX_TEXT] + " …[clip]"

    def _content_blocks(self, content: Any) -> List[Dict[str, Any]]:
        """Claude content is a bare string or a list of typed blocks."""
        if isinstance(content, str):
            return [{"type": "text", "text": content}]
        if isinstance(content, list):
            return [b for b in content if isinstance(b, dict)]
        return []

    def _parse_session(self, path: Path) -> Dict[str, Any]:
        model = ""
        turns: List[Dict[str, Any]] = []
        for line in path.read_text(errors="ignore").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except json.JSONDecodeError:
                continue
            rtype = rec.get("type")
            if rtype not in ("user", "assistant"):
                continue
            msg = rec.get("message", {}) or {}
            role = msg.get("role", rtype)
            if msg.get("model"):
                model = msg["model"]
            for item in self._content_blocks(msg.get("content")):
                itype = item.get("type")
                if itype == "text":
                    text = self._clip(item.get("text", ""))
                    if text:
                        turns.append({"role": role, "text": text})
                elif itype == "tool_use":
                    turns.append(
                        {
                            "role": "assistant",
                            "tool_call": item.get("name"),
                            "arguments": self._clip(item.get("input", {})),
                        }
                    )
                elif itype == "tool_result":
                    turns.append(
                        {
                            "role": "tool",
                            "tool": item.get("tool_use_id", ""),
                            "result": self._clip(item.get("content", "")),
                        }
                    )
                # "thinking" blocks are intentionally dropped (redacted/noisy).
            if len(turns) >= _MAX_TURNS:
                break
        return {
            "session_id": path.stem,
            "source": "claude_code",
            "model": model,
            "turn_count": len(turns),
            "turns": turns,
        }

    # --- read / apply ---------------------------------------------------------

    def read_target_content(self, runtime_root: Path, target: TargetSpec) -> str:
        p = Path(target.file_path)
        return p.read_text(errors="ignore") if p.exists() else ""

    def _compute_after(self, before: str, op: str, payload: Dict[str, Any], change_id: str) -> str:
        content = str(payload.get("content") or payload.get("after") or "")
        if op == "replace" and payload.get("before"):
            return before.replace(str(payload["before"]), content, 1)
        if op == "replace" and not before:
            return content
        # append (default): add a delimited, removable "evolvor chunk".
        chunk = f"\n\n<!-- evolvor:{change_id} -->\n{content}\n<!-- /evolvor:{change_id} -->\n"
        return before + chunk

    def preview_edit(self, runtime_root: Path, target: TargetSpec, op: str, payload: Dict[str, Any]) -> Tuple[str, str]:
        before = self.read_target_content(runtime_root, target)
        after = self._compute_after(before, op, payload, "preview")
        return before, after

    def apply_edit(
        self, runtime_root: Path, target: TargetSpec, op: str, payload: Dict[str, Any]
    ) -> Tuple[str, str, str]:
        p = Path(target.file_path)
        before = p.read_text(errors="ignore") if p.exists() else ""
        change_id = f"chg_{uuid.uuid4().hex[:16]}"
        after = self._compute_after(before, op, payload, change_id)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(after)
        return before, after, change_id
