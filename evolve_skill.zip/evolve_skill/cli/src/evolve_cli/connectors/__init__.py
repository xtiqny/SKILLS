"""Connectors translate a specific agent runtime to/from the Evolve contract.

A connector knows three things about one runtime kind (e.g. Openclaw):
  - which files are evolvable surfaces (-> CapabilityMap targets),
  - how to read its session logs (-> normalized session objects),
  - how to read/write a target's content (-> local preview + apply).
"""

from __future__ import annotations

from evolve_cli.connectors.base import Connector, TargetSpec
from evolve_cli.connectors.claude_code import ClaudeCodeConnector
from evolve_cli.connectors.openclaw import OpenclawConnector
from evolve_cli.connectors.trae import TraeConnector

_REGISTRY = {c.name: c for c in [OpenclawConnector(), ClaudeCodeConnector(), TraeConnector()]}


def get_connector(name: str) -> Connector:
    if name not in _REGISTRY:
        raise KeyError(f"unknown connector '{name}'; available: {sorted(_REGISTRY)}")
    return _REGISTRY[name]


__all__ = ["Connector", "TargetSpec", "get_connector"]
