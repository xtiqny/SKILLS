"""Trae IDE connector.

Surfaces are Trae's project-level instruction file ``AGENTS.md`` at the runtime
root. Trae's docs (https://docs.trae.ai/ide/rules) describe ``AGENTS.md`` as
"a lightweight markdown file located in the project's root directory, used to
provide behavioral guidance to AI agents… reusable in other IDEs that support
AGENTS.md" — the same role ``CLAUDE.md`` plays for Claude Code.

Trae also has ``.trae/rules/*.md`` (per-rule files with required YAML
frontmatter and activation modes) and a Settings-managed Global Rules section.
Neither is exposed as an evolvable target by this connector — ``.trae/rules``
is a structured rule store, not a free-form instruction surface, and Trae
documents no user-global *file* analogous to ``~/.claude/CLAUDE.md``.

Edits append a delimited "evolvor chunk"
(``<!-- evolvor:chg_… --> … <!-- /evolvor:chg_… -->``) to ``AGENTS.md`` so
applied changes are visible and removable, exactly like the Claude Code and
OpenClaw connectors.
"""

from __future__ import annotations

import json
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from evolve_cli.connectors.base import TargetSpec

# (target_id, surface_type, relpath, display_name, supported_ops, root)
#   root="runtime" → resolved under the configured runtime_root
_SURFACES = [
    (
        "memory.project",
        "persistent_memory_file",
        "AGENTS.md",
        "Project Agent Instructions (AGENTS.md)",
        ["append", "replace"],
        "runtime",
    ),
]

# Likely locations of Trae session JSONL files. Trae's docs do not document
# the on-disk session-log path, so we probe these in order. If none exist and
# the user does not pass ``--from``, ``read_sessions`` returns an empty list
# and the CLI's normal "no sessions" path fires.
_SESSION_PROBES = (
    Path.home() / ".trae" / "sessions",
    Path.home() / ".trae" / "agents",
    Path.home() / "Library" / "Application Support" / "Trae" / "sessions",
    Path.home() / ".config" / "Trae" / "sessions",
)

_MAX_TURNS = 60
_MAX_TEXT = 1500


class TraeConnector:
    name = "trae"

    # --- capabilities ---------------------------------------------------------

    def _resolve_path(self, runtime_root: Path, relpath: str, root: str) -> Path:
        base = Path.home() if root == "home" else runtime_root
        return base / relpath

    def discover_capabilities(self, runtime_root: Path) -> List[TargetSpec]:
        specs: List[TargetSpec] = []
        for target_id, surface_type, relpath, display_name, ops, root in _SURFACES:
            fpath = self._resolve_path(runtime_root, relpath, root)
            specs.append(
                TargetSpec(
                    target_id=target_id,
                    surface_type=surface_type,
                    file_path=str(fpath),
                    display_name=display_name,
                    supported_ops=ops,
                    folder_path=str(fpath.parent),
                    usable=fpath.exists(),
                )
            )
        return specs

    def target_by_id(self, runtime_root: Path, target_id: str) -> Optional[TargetSpec]:
        for spec in self.discover_capabilities(runtime_root):
            if spec.target_id == target_id:
                return spec
        return None

    # --- sessions -------------------------------------------------------------

    def read_sessions(
        self,
        from_path: Optional[Path],
        fmt: str,
        session_ids: Optional[List[str]] = None,
        started_at: Optional[str] = None,
        ended_at: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        files = self._resolve_session_files(from_path, session_ids)
        sessions = [self._parse_session(f) for f in files]
        sessions = [s for s in sessions if s["turn_count"]]
        if limit:
            sessions = sessions[:limit]
        return sessions

    def _resolve_session_files(self, from_path: Optional[Path], session_ids: Optional[List[str]]) -> List[Path]:
        if from_path and from_path.is_file():
            return [from_path]
        base: Optional[Path] = None
        if from_path and from_path.is_dir():
            base = from_path
        else:
            for probe in _SESSION_PROBES:
                if probe.is_dir():
                    base = probe
                    break
        if base is None:
            return []
        candidates = list(base.rglob("*.jsonl"))
        if session_ids:
            # Explicit selection: respect what the user asked for, no recency sort.
            wanted = set(session_ids)
            return sorted(p for p in candidates if p.stem in wanted)
        # Default: newest first, so an --limit cap keeps the most recent sessions
        # instead of whichever ones happen to sort early alphabetically.
        return sorted(candidates, key=lambda p: p.stat().st_mtime, reverse=True)

    def _clip(self, text: Any) -> str:
        s = text if isinstance(text, str) else json.dumps(text, ensure_ascii=False, default=str)
        return s if len(s) <= _MAX_TEXT else s[:_MAX_TEXT] + " …[clip]"

    def _content_blocks(self, content: Any) -> List[Dict[str, Any]]:
        """Mirrors ClaudeCodeConnector — content is a bare string or typed blocks."""
        if isinstance(content, str):
            return [{"type": "text", "text": content}]
        if isinstance(content, list):
            return [b for b in content if isinstance(b, dict)]
        return []

    def _parse_session(self, path: Path) -> Dict[str, Any]:
        # TODO: confirm Trae's session JSONL schema once a real install is
        # available. For now we accept the union of the Claude Code shape
        # (top-level ``type=user|assistant`` with ``message.content`` as bare
        # string or Anthropic content blocks) and the OpenClaw shape (top-level
        # ``type=message`` with ``message.content`` as content blocks; a
        # ``model_change`` record carrying ``modelId``). If Trae uses neither,
        # this returns ``turn_count=0`` and the session is filtered out by
        # ``read_sessions`` — ``import`` will be a no-op until updated.
        model = ""
        turns: List[Dict[str, Any]] = []
        for line in path.read_text(errors="ignore").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except json.JSONDecodeError:
                continue
            rtype = rec.get("type")
            if rtype == "model_change":
                model = rec.get("modelId") or rec.get("provider") or model
                continue
            if rtype not in ("user", "assistant", "message"):
                continue
            msg = rec.get("message", {}) or {}
            role = msg.get("role", rtype if rtype != "message" else "?")
            if msg.get("model"):
                model = msg["model"]
            for item in self._content_blocks(msg.get("content")):
                itype = item.get("type")
                if itype == "text":
                    text = self._clip(item.get("text", ""))
                    if text:
                        turns.append({"role": role, "text": text})
                elif itype in ("tool_use", "toolCall"):
                    turns.append(
                        {
                            "role": "assistant",
                            "tool_call": item.get("name"),
                            "arguments": self._clip(item.get("input", item.get("arguments", {}))),
                        }
                    )
                elif itype in ("tool_result", "toolResult"):
                    turns.append(
                        {
                            "role": "tool",
                            "tool": item.get("tool_use_id", item.get("toolName", "")),
                            "result": self._clip(item.get("content", "")),
                        }
                    )
                # "thinking" blocks are intentionally dropped (redacted/noisy).
            if len(turns) >= _MAX_TURNS:
                break
        return {"session_id": path.stem, "source": "trae", "model": model, "turn_count": len(turns), "turns": turns}

    # --- read / apply ---------------------------------------------------------

    def read_target_content(self, runtime_root: Path, target: TargetSpec) -> str:
        p = Path(target.file_path)
        return p.read_text(errors="ignore") if p.exists() else ""

    def _compute_after(self, before: str, op: str, payload: Dict[str, Any], change_id: str) -> str:
        content = str(payload.get("content") or payload.get("after") or "")
        if op == "replace" and payload.get("before"):
            return before.replace(str(payload["before"]), content, 1)
        if op == "replace" and not before:
            return content
        # append (default): add a delimited, removable "evolvor chunk".
        chunk = f"\n\n<!-- evolvor:{change_id} -->\n{content}\n<!-- /evolvor:{change_id} -->\n"
        return before + chunk

    def preview_edit(self, runtime_root: Path, target: TargetSpec, op: str, payload: Dict[str, Any]) -> Tuple[str, str]:
        before = self.read_target_content(runtime_root, target)
        after = self._compute_after(before, op, payload, "preview")
        return before, after

    def apply_edit(
        self, runtime_root: Path, target: TargetSpec, op: str, payload: Dict[str, Any]
    ) -> Tuple[str, str, str]:
        p = Path(target.file_path)
        before = p.read_text(errors="ignore") if p.exists() else ""
        change_id = f"chg_{uuid.uuid4().hex[:16]}"
        after = self._compute_after(before, op, payload, change_id)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(after)
        return before, after, change_id
