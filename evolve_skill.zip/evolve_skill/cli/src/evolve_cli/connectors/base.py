"""Connector protocol + the TargetSpec it emits."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Protocol, Tuple, runtime_checkable


@dataclass
class TargetSpec:
    """A discovered evolvable surface (maps 1:1 to a backend CapabilityMap target)."""

    target_id: str
    surface_type: str
    file_path: str  # absolute path in the runtime
    display_name: str = ""
    supported_ops: List[str] = field(default_factory=list)
    content_shape: str = "text"
    actuation: str = "connector_actuator"
    folder_path: str = ""
    usable: bool = True

    def to_target_input(self) -> Dict[str, Any]:
        """Snake-case body for RegisterCapabilityMapRequest.targets[]."""
        return {
            "target_id": self.target_id,
            "surface_type": self.surface_type,
            "content_shape": self.content_shape,
            "supported_ops": self.supported_ops,
            "actuation": self.actuation,
            "display_name": self.display_name or self.target_id,
            "file_path": self.file_path,
            "folder_path": self.folder_path,
            "usable": self.usable,
        }


@runtime_checkable
class Connector(Protocol):
    name: str

    def discover_capabilities(self, runtime_root: Path) -> List[TargetSpec]:
        """Enumerate the runtime's evolvable surfaces."""

    def read_sessions(
        self,
        from_path: Optional[Path],
        fmt: str,
        session_ids: Optional[List[str]] = None,
        started_at: Optional[str] = None,
        ended_at: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        """Read + normalize session logs into session objects for import."""

    def read_target_content(self, runtime_root: Path, target: TargetSpec) -> str:
        """Current content of a target's file (for previews / drift checks)."""

    def preview_edit(self, runtime_root: Path, target: TargetSpec, op: str, payload: Dict[str, Any]) -> Tuple[str, str]:
        """Compute (before_text, after_text) WITHOUT writing — for `evolve proposal`."""

    def apply_edit(
        self, runtime_root: Path, target: TargetSpec, op: str, payload: Dict[str, Any]
    ) -> Tuple[str, str, str]:
        """Apply an edit to the runtime. Returns (before_text, after_text, change_id)."""

    def target_by_id(self, runtime_root: Path, target_id: str) -> Optional["TargetSpec"]:
        """Resolve a target spec by id (or None)."""
