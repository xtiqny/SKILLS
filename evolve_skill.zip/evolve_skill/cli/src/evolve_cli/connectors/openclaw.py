"""Openclaw connector.

Runtime root defaults to ``~/.openclaw/workspace``; session logs live under
``~/.openclaw/agents/{agentId}/sessions/*.jsonl``. Surfaces are the workspace
markdown files. Edits append-to (or replace) those files; ``append`` writes an
"evolvor chunk" delimited block so applied changes are visible and removable.

Privacy: every text fragment that leaves the machine goes through ``_redact``
(emails, API keys/tokens, IPs, home-dir usernames are replaced with placeholders)
and each session is tagged ``privacy="redacted"`` — keeping the upload honest
about the registered ``default_privacy``. Redaction is recall-oriented: it is
better to over-mask than to leak.

Besides the native openclaw JSONL event log, ``*.messages.json`` files in the
arkclaw export shape (``{"messages": [...]}`` OpenAI-style) are also parsed.
"""

from __future__ import annotations

import json
import re
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from evolve_cli.connectors.base import TargetSpec

# Recall-oriented redaction patterns, applied in order. Placeholders keep the
# text shape readable for the cloud-side signal extraction.
_REDACTIONS: List[Tuple[re.Pattern, str]] = [
    (re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}"), "<REDACTED_EMAIL>"),
    (re.compile(r"(?i)bearer\s+[A-Za-z0-9._\-]{10,}"), "<REDACTED_TOKEN>"),
    (re.compile(r"\bsk-[A-Za-z0-9_\-]{8,}\b"), "<REDACTED_KEY>"),
    (re.compile(r"\bAKLT[A-Za-z0-9+/=_\-]{8,}\b"), "<REDACTED_KEY>"),
    (re.compile(r"\b[0-9a-fA-F]{32,}\b"), "<REDACTED_HEX>"),
    (re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b"), "<REDACTED_IP>"),
    (re.compile(r"(/(?:Users|home)/)[A-Za-z0-9._\-]+"), r"\1<REDACTED_USER>"),
]


def _redact(text: str) -> str:
    for pattern, repl in _REDACTIONS:
        text = pattern.sub(repl, text)
    return text


# (target_id, surface_type, filename, display_name, supported_ops)
_SURFACES = [
    ("prompt.agent", "prompt_text", "AGENTS.md", "Main Agent Instruction", ["append", "replace"]),
    ("prompt.soul", "prompt_text", "SOUL.md", "Agent Personality (Soul)", ["append", "replace"]),
    ("prompt.identity", "prompt_text", "IDENTITY.md", "Agent Identity", ["append", "replace"]),
    ("user.context", "prompt_text", "USER.md", "User Context", ["append", "replace"]),
    ("tool.notes", "prompt_text", "TOOLS.md", "Tool Notes", ["append", "replace"]),
    ("bootstrap.tasks", "prompt_text", "BOOTSTRAP.md", "Bootstrap Tasks", ["append", "replace"]),
    ("heartbeat.routine", "prompt_text", "HEARTBEAT.md", "Heartbeat Routine", ["append", "replace"]),
    ("memory.persistent", "persistent_memory_file", "MEMORY.md", "Persistent Memory", ["append", "replace"]),
]

_MAX_TURNS = 60
_MAX_TEXT = 1500


class OpenclawConnector:
    name = "openclaw"

    # --- capabilities ---------------------------------------------------------

    def discover_capabilities(self, runtime_root: Path) -> List[TargetSpec]:
        specs: List[TargetSpec] = []
        for target_id, surface_type, filename, display_name, ops in _SURFACES:
            fpath = runtime_root / filename
            specs.append(
                TargetSpec(
                    target_id=target_id,
                    surface_type=surface_type,
                    file_path=str(fpath),
                    display_name=display_name,
                    supported_ops=ops,
                    folder_path=str(runtime_root),
                    usable=fpath.exists(),
                )
            )
        return specs

    def target_by_id(self, runtime_root: Path, target_id: str) -> Optional[TargetSpec]:
        for spec in self.discover_capabilities(runtime_root):
            if spec.target_id == target_id:
                return spec
        return None

    # --- sessions -------------------------------------------------------------

    def read_sessions(
        self,
        from_path: Optional[Path],
        fmt: str,
        session_ids: Optional[List[str]] = None,
        started_at: Optional[str] = None,
        ended_at: Optional[str] = None,
        limit: Optional[int] = None,
    ) -> List[Dict[str, Any]]:
        files = self._resolve_session_files(from_path, session_ids)
        sessions = [self._parse_session(f) for f in files]
        sessions = [s for s in sessions if s["turn_count"]]
        if limit:
            sessions = sessions[:limit]
        return sessions

    def _resolve_session_files(self, from_path: Optional[Path], session_ids: Optional[List[str]]) -> List[Path]:
        if from_path and from_path.is_file():
            return [from_path]
        base = from_path if (from_path and from_path.is_dir()) else (Path.home() / ".openclaw" / "agents")
        # *.trajectory.jsonl files are a trace format, not session events — skip them.
        jsonl = [f for f in base.rglob("*.jsonl") if not f.name.endswith(".trajectory.jsonl")]
        candidates = list(jsonl) + list(base.rglob("*.messages.json"))
        if session_ids:
            # Explicit selection: respect what the user asked for, no recency sort.
            wanted = set(session_ids)
            return sorted(p for p in candidates if p.stem in wanted or p.name.split(".")[0] in wanted)
        # Default: newest first, so an --limit cap keeps the most recent sessions
        # instead of whichever ones happen to sort early alphabetically.
        return sorted(candidates, key=lambda p: p.stat().st_mtime, reverse=True)

    def _clip(self, text: Any) -> str:
        s = text if isinstance(text, str) else json.dumps(text, ensure_ascii=False, default=str)
        s = _redact(s)
        return s if len(s) <= _MAX_TEXT else s[:_MAX_TEXT] + " …[clip]"

    def _parse_session(self, path: Path) -> Dict[str, Any]:
        if path.name.endswith(".messages.json"):
            return self._parse_arkclaw_session(path)
        return self._parse_openclaw_session(path)

    def _parse_arkclaw_session(self, path: Path) -> Dict[str, Any]:
        """arkclaw export shape: ``{"messages": [{role, content, tool_calls?, ...}]}``."""
        turns: List[Dict[str, Any]] = []
        model = ""
        try:
            data = json.loads(path.read_text(errors="ignore"))
        except json.JSONDecodeError:
            data = {}
        for msg in data.get("messages", []) or []:
            if not isinstance(msg, dict):
                continue
            role = msg.get("role", "?")
            meta = msg.get("meta") or {}
            model = meta.get("model_name") or model
            content = msg.get("content")
            if role == "tool":
                # Tool outputs are emitted result-style so downstream weak
                # supervision can scan them for error markers.
                if content not in (None, ""):
                    turns.append({"role": "tool", "tool": "", "result": self._clip(content)})
            elif isinstance(content, str) and content.strip():
                turns.append({"role": role, "text": self._clip(content)})
            for tc in msg.get("tool_calls") or []:
                fn = (tc or {}).get("function") or {}
                turns.append(
                    {"role": "assistant", "tool_call": fn.get("name"), "arguments": self._clip(fn.get("arguments", ""))}
                )
            if len(turns) >= _MAX_TURNS:
                break
        session_id = path.name.split(".")[0]
        return {
            "session_id": session_id,
            "source": "arkclaw",
            "model": model,
            "privacy": "redacted",
            "turn_count": len(turns),
            "turns": turns,
        }

    def _parse_openclaw_session(self, path: Path) -> Dict[str, Any]:
        model = ""
        turns: List[Dict[str, Any]] = []
        for line in path.read_text(errors="ignore").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                rec = json.loads(line)
            except json.JSONDecodeError:
                continue
            if rec.get("type") == "model_change":
                model = rec.get("modelId") or rec.get("provider") or model
            if rec.get("type") != "message":
                continue
            msg = rec.get("message", {})
            role = msg.get("role", "?")
            content = msg.get("content")
            # Real logs carry user content as a plain string (not a typed-item list).
            if isinstance(content, str):
                if content.strip():
                    turns.append({"role": role, "text": self._clip(content)})
                content = []
            for item in content or []:
                if not isinstance(item, dict):
                    continue
                itype = item.get("type")
                if itype == "text":
                    turns.append({"role": role, "text": self._clip(item.get("text", ""))})
                elif itype == "toolCall":
                    turns.append(
                        {
                            "role": "assistant",
                            "tool_call": item.get("name"),
                            "arguments": self._clip(item.get("arguments", {})),
                        }
                    )
                elif itype == "toolResult":
                    turns.append(
                        {"role": "tool", "tool": item.get("toolName"), "result": self._clip(item.get("content", ""))}
                    )
            if len(turns) >= _MAX_TURNS:
                break
        return {
            "session_id": path.stem,
            "source": "openclaw",
            "model": model,
            "privacy": "redacted",
            "turn_count": len(turns),
            "turns": turns,
        }

    # --- read / apply ---------------------------------------------------------

    def read_target_content(self, runtime_root: Path, target: TargetSpec) -> str:
        p = Path(target.file_path)
        return p.read_text(errors="ignore") if p.exists() else ""

    def _compute_after(self, before: str, op: str, payload: Dict[str, Any], change_id: str) -> str:
        content = str(payload.get("content") or payload.get("after") or "")
        if op == "replace" and payload.get("before"):
            return before.replace(str(payload["before"]), content, 1)
        if op == "replace" and not before:
            return content
        # append (default): add a delimited, removable "evolvor chunk".
        chunk = f"\n\n<!-- evolvor:{change_id} -->\n{content}\n<!-- /evolvor:{change_id} -->\n"
        return before + chunk

    def preview_edit(self, runtime_root: Path, target: TargetSpec, op: str, payload: Dict[str, Any]) -> Tuple[str, str]:
        before = self.read_target_content(runtime_root, target)
        after = self._compute_after(before, op, payload, "preview")
        return before, after

    def apply_edit(
        self, runtime_root: Path, target: TargetSpec, op: str, payload: Dict[str, Any]
    ) -> Tuple[str, str, str]:
        p = Path(target.file_path)
        before = p.read_text(errors="ignore") if p.exists() else ""
        change_id = f"chg_{uuid.uuid4().hex[:16]}"
        after = self._compute_after(before, op, payload, change_id)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(after)
        return before, after, change_id
