"""The ``evolve`` CLI — local deterministic kernel for agent self-evolution.

Commands map onto the case_platform self_evolve backend actions; the connector
handles runtime discovery, session parsing, and runtime writes. See CLI_DESIGN.md
in the backend module for the full design and the three-workspace model.
"""

from __future__ import annotations

import json
import os
import time
import uuid
from pathlib import Path
from typing import List, Optional

import typer
from evolve_cli import config as cfg
from evolve_cli.api import EvolveAPIError, EvolveClient, rget
from evolve_cli.connectors import get_connector
from evolve_cli.render import (
    proposal_summary_line,
    render_proposal_detail,
    unified_diff,
)

app = typer.Typer(no_args_is_help=True, add_completion=False, help="Evolve CLI — agent self-evolution kernel.")

_TERMINAL = {"completed", "failed"}

# Mirror of case_platform.modules.self_evolve.ingestion_ops._DEFAULT_SESSION_LIMIT.
# The server enforces this same cap; applying it client-side avoids reading and
# uploading sessions that will only be trimmed on arrival. Keep the two in sync.
_DEFAULT_SESSION_LIMIT = 10


# The backend environment every install is implicitly bound to (baked into the
# CapabilityMap PK cap_<agent>_<env>). Single source of truth lives in config.py
# so the publish scripts rewrite exactly ONE line; do NOT re-expose --env to
# customers. The env-bound gateway URL is config.DEFAULT_BASE_URL.
_BOUND_ENV = cfg._BOUND_ENV


def _client(c: cfg.EvolveConfig, explicit_api_key: str = "") -> EvolveClient:
    """Build an EvolveClient with a clear API-key precedence.

    Precedence (most explicit wins):
      1. ``explicit_api_key``    — the per-command ``--api-key`` flag value,
                                   passed in by the typer command. POSIX
                                   convention: an explicit flag must win.
      2. ``$EVOLVE_API_KEY``     — evolve-specific env override
      3. ``$ARK_API_KEY``        — the standard Ark env var the customer
                                   already exports for their agent
      4. ``c.api_key``           — persisted in ``~/.evolve/config.yaml`` by
                                   a prior ``init`` (last resort)

    The earlier "env > flag" order silently broke users whose
    ``~/.evolve-skill.env`` carried a stale key — they'd update on the
    command line, the env var would still win, and the request would 401.
    """
    api_key = explicit_api_key or os.environ.get("EVOLVE_API_KEY") or os.environ.get("ARK_API_KEY") or c.api_key
    return EvolveClient(c.base_url, c.account_id, c.user_id, c.user_name, api_key=api_key)


def _err(msg: str) -> None:
    typer.secho(msg, fg=typer.colors.RED, err=True)
    raise typer.Exit(1)


def _is_under(path: Path, root: Path) -> bool:
    """True if ``path`` lives at or below ``root`` (both resolved, existence-agnostic)."""
    try:
        path.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


def _require_usable_surface(conn, connector: str, runtime_root: Path) -> list:
    """Discover the connector's surfaces and assert the runtime root is real.

    ``discover_capabilities`` returns the connector's FULL surface catalogue
    regardless of what's on disk — each spec's ``usable`` flag reflects whether
    its file actually exists. We require at least one usable surface UNDER
    ``runtime_root``; if there is none the root is bogus (wrong ``--runtime-root``,
    or the folder was moved/renamed/deleted after init), so we fail loudly with the
    exact paths instead of letting a caller silently resurrect a ghost directory.

    A home-scoped surface (e.g. claude_code's global ``~/.claude/CLAUDE.md``) exists
    independent of the folder passed, so requiring the usable surface to be *under*
    the root keeps it from masking a wrong/stale root. Returns the full spec list.
    """
    specs = conn.discover_capabilities(runtime_root)
    if not specs:
        _err(f"connector '{connector}' exposes no capabilities (empty surface catalogue)")
    rooted = [s for s in specs if s.usable and _is_under(Path(s.file_path), runtime_root)]
    if not rooted:
        lines = [
            f"connector '{connector}' found no usable evolvable surface under {runtime_root}.",
            "The directory is missing or none of the expected files exist there — a wrong "
            "--runtime-root, or the folder was moved/renamed after init. Surfaces looked for:",
        ]
        for s in specs:
            tag = "outside root" if s.usable else "missing"
            lines.append(f"    [{tag}] {s.file_path}  ({s.display_name or s.target_id})")
        lines.append(
            "Re-run `evolve init` with --runtime-root set to the directory that owns these "
            "files (or create at least one of them there first), then retry."
        )
        _err("\n".join(lines))
    return specs


def _runtime_root_for(c: cfg.EvolveConfig) -> Path:
    """Resolve the runtime root for a read/apply command, self-healing a move.

    When state lives in a project-local ``<root>/.evolve/``, the folder that
    contains it *is* the runtime root — so prefer that over the (possibly stale)
    absolute path saved in ``config.yaml`` at init time. This makes moving the
    whole folder-with-its-.evolve transparent. Home-based / ``$EVOLVE_HOME``
    installs return the persisted path unchanged (they can't self-heal; the
    caller's drift guard catches a stale root instead).
    """
    healed = cfg.project_local_runtime_root()
    if healed is not None and str(healed) != c.runtime_root:
        typer.secho(
            f"runtime_root self-healed to {healed} (config.yaml had {c.runtime_root!r}; "
            f"the project-local .evolve/ moved with the folder)",
            fg=typer.colors.CYAN,
            err=True,
        )
        return healed
    return Path(c.runtime_root)


def _activate_connector(explicit: str = "") -> None:
    """Point cfg's state paths at the right connector shard for a read command.

    Resolution: explicit ``--connector`` / ``$EVOLVE_CONNECTOR`` → autodetect a
    lone shard → legacy un-sharded ``~/.evolve/``. When several shards exist and
    none is selected, error with a disambiguation hint rather than guessing.
    ``$EVOLVE_HOME`` short-circuits everything (cfg.use_connector is a no-op then).
    """
    connector = (explicit or os.environ.get("EVOLVE_CONNECTOR", "")).strip()
    # An explicit $EVOLVE_HOME pins the workspace outright (CI/test isolation, the
    # E2E harness) — skip connector autodetect/ambiguity entirely so a stray
    # ~/.evolve on the box can't trigger a false "multiple agents" error.
    if os.environ.get("EVOLVE_HOME"):
        cfg.use_connector(connector)
        return
    if not connector:
        connector = cfg.autodetect_connector() or ""
    if not connector:
        shards = cfg.list_connectors()
        if len(shards) > 1:
            _err(
                "Multiple evolve agents are set up on this machine "
                f"({', '.join(shards)}). Set EVOLVE_CONNECTOR=<one> (or pass "
                "--connector) to choose which one this command targets."
            )
    cfg.use_connector(connector)


def _migrate_legacy_config(connector: str) -> None:
    """Adopt a pre-sharding ~/.evolve/config.yaml into this connector's shard.

    Only when: sharding is active (no $EVOLVE_HOME), the legacy config exists and
    names THIS connector, and the shard has no config yet. The legacy file is
    left in place (harmless) — we just seed the shard so init reuses the existing
    agent_id instead of minting a fresh, cloud-orphaning one.
    """
    if os.environ.get("EVOLVE_HOME"):
        return
    # Only relevant for the home base — never seed a project-local .evolve from
    # the home legacy config.
    if cfg._base_dir() != cfg._LEGACY_HOME:
        return
    legacy = cfg._LEGACY_HOME / "config.yaml"
    if cfg.CONFIG_PATH == legacy or cfg.CONFIG_PATH.exists() or not legacy.exists():
        return
    try:
        prior = cfg.EvolveConfig.load()  # falls back to legacy when shard is empty
    except Exception:  # noqa: BLE001
        return
    if prior.connector == connector and prior.agent_id:
        prior.save()  # writes into the now-active shard
        typer.secho(
            f"migrated legacy ~/.evolve/config.yaml → {cfg.CONFIG_PATH}",
            fg=typer.colors.CYAN,
        )


def _load_config(connector: str = "") -> cfg.EvolveConfig:
    _activate_connector(connector)
    try:
        return cfg.EvolveConfig.load()
    except FileNotFoundError as e:
        _err(str(e))
        raise  # unreachable; satisfies type checkers


# Optional inline selector for read commands when several agents are set up on
# one machine. Same effect as exporting $EVOLVE_CONNECTOR; omit it and the CLI
# autodetects a lone shard (the single-agent common case).
_CONNECTOR_OPT = typer.Option(
    "",
    "--connector",
    envvar="EVOLVE_CONNECTOR",
    help="Which agent's workspace to target (~/.evolve/<connector>/). "
    "Omit when only one agent is set up; required to disambiguate several.",
)


# --------------------------------------------------------------------------- #


@app.command()
def init(
    connector: str = typer.Option("openclaw", "--connector"),
    agent_id: str = typer.Option(
        "",
        "--agent-id",
        help=(
            "Agent UUID (must be a valid UUID). Omit to auto-generate uuid4. "
            "Once set, this is the agent's permanent identity for the bound Ark account."
        ),
    ),
    display_name: str = typer.Option(
        "",
        "--display-name",
        envvar="EVOLVE_DISPLAY_NAME",
        help=(
            "Friendly name shown in `evolve status` (e.g. 'openclaw-main'). "
            "Optional; defaults to '' and shown only when set. "
            "Env var: EVOLVE_DISPLAY_NAME."
        ),
    ),
    runtime_root: Optional[Path] = typer.Option(
        None,
        "--runtime-root",
        envvar="EVOLVE_RUNTIME_ROOT",
        help=(
            "Project root that owns the evolvable surfaces. "
            "Env var: EVOLVE_RUNTIME_ROOT (skill manifests rely on this fallback)."
        ),
    ),
    base_url: str = typer.Option(
        cfg.DEFAULT_BASE_URL,
        "--base-url",
        envvar="EVOLVE_BASE_URL",
        help="Backend base URL. Defaults to the env-bound gateway baked into this build; override with EVOLVE_BASE_URL.",
    ),
    account_id: str = typer.Option(
        "",
        "--account-id",
        envvar="EVOLVE_ACCOUNT_ID",
        help="Account id. Env var: EVOLVE_ACCOUNT_ID.",
    ),
    user_id: str = typer.Option("0", "--user-id"),
    user_name: str = typer.Option(
        "",
        "--user-name",
        envvar="EVOLVE_USER_NAME",
        help="User name. Env var: EVOLVE_USER_NAME.",
    ),
    api_key: str = typer.Option("", "--api-key", help="Ark API key (Bearer). Prefer the EVOLVE_API_KEY env var."),
    refresh: bool = typer.Option(False, "--refresh"),
) -> None:
    """Discover the runtime's capabilities and sync them to the cloud.

    ``agent_id`` is the global PK component for this agent's CapabilityMap. It
    must be a UUID — server enforces strict validation and human-typed names
    (e.g. 'openclaw-main') are rejected. The CLI auto-generates a uuid4 if you
    don't pass one; pin it with ``--agent-id`` only when re-binding an existing
    agent (e.g. across machines for the same Ark account).

    Several args fall back to ``EVOLVE_*`` env vars (runtime_root, base_url,
    account_id, user_name, display_name) so a skill manifest can rely on the
    env wiring the installer set up rather than re-pass every flag each call.
    A skill-driven init with all env vars set therefore reduces to
    ``evolve init --connector <c>``.
    """
    if runtime_root is None:
        _err("--runtime-root is required (or set EVOLVE_RUNTIME_ROOT)")
    # Choose (and create) the base dir this init writes to BEFORE binding paths:
    # explicit $EVOLVE_HOME, else a discovered/created project-local .evolve when
    # $HOME isn't writable (sandboxed runtimes like Trae), else ~/.evolve. Pins
    # the base so use_connector + the save below all target the same place.
    base = cfg.prepare_base_for_init(runtime_root.expanduser().resolve())
    # Point cfg's state paths at this connector's shard under that base (e.g.
    # <base>/<connector>/) BEFORE anything reads or writes them — the agent_id
    # reuse check below and the save at the end must both hit the same workspace.
    # init's --connector is the authoritative source of the shard.
    cfg.use_connector(connector)
    if str(base) != str(cfg._LEGACY_HOME):
        typer.secho(f"using state dir {cfg.EVOLVE_HOME}", fg=typer.colors.CYAN)
    # One-time migration: a pre-sharding install left its config at the legacy
    # ~/.evolve/config.yaml. If it belongs to THIS connector and the shard is
    # still empty, adopt it (so the agent_id/history carry over instead of the
    # reuse-check below missing it and minting a fresh, orphaning uuid).
    _migrate_legacy_config(connector)
    # Idempotency: an existing workspace already owns a uuid agent_id. Re-rolling
    # it on every `evolve init` silently orphans the prior agent's CapabilityMap +
    # imports + proposals on the cloud (the new agent_id is a fresh row, and the
    # old one becomes unreachable from this machine). We saw this bite the
    # vefaas-vs-stg test: every retry minted a new uuid, so the harvest's
    # `evolve proposals --status applied` queried the LATEST uuid while the real
    # apply landed under an earlier one → false-negative APPLIED=0.
    # The fix is to reuse the persisted agent_id by default. Customers can opt
    # into re-keying explicitly via --agent-id (re-bind) or --refresh (sync).
    if not agent_id and cfg.CONFIG_PATH.exists():
        try:
            prior = cfg.EvolveConfig.load()
        except Exception:  # noqa: BLE001 — malformed config falls through to fresh-mint
            prior = None
        if prior is not None and prior.agent_id:
            agent_id = prior.agent_id
            typer.secho(
                f"reusing existing agent_id={agent_id} from {cfg.CONFIG_PATH} "
                f"(pass --agent-id <uuid> to re-bind, or delete the file to mint a new one)",
                fg=typer.colors.CYAN,
            )
    if not agent_id:
        agent_id = str(uuid.uuid4())
        typer.secho(f"generated agent_id={agent_id}", fg=typer.colors.YELLOW)
    else:
        try:
            # ``uuid.UUID(...)`` accepts hex/urn/braced shapes too — re-stringify
            # the parsed value so the wire id is always the canonical 8-4-4-4-12.
            agent_id = str(uuid.UUID(agent_id))
        except ValueError:
            _err(f"--agent-id must be a UUID; got {agent_id!r}")
    conn = get_connector(connector)
    runtime_root = runtime_root.expanduser().resolve()
    specs = _require_usable_surface(conn, connector, runtime_root)

    c = cfg.EvolveConfig(
        agent_id=agent_id,
        display_name=display_name,
        environment=_BOUND_ENV,
        connector=connector,
        runtime_root=str(runtime_root),
        base_url=base_url,
        account_id=account_id,
        user_id=user_id,
        user_name=user_name,
        api_key=api_key,
    )
    # Tell the user when an env var would otherwise override their --api-key.
    # The old precedence silently let EVOLVE_API_KEY / ARK_API_KEY beat the
    # flag, which led to a fleet of "I just updated my key on the command
    # line and still get 401" tickets. We now prefer the flag (see _client),
    # and warn so it's obvious the env file is stale.
    env_key = os.environ.get("EVOLVE_API_KEY") or os.environ.get("ARK_API_KEY") or ""
    if api_key and env_key and api_key != env_key:
        which = "EVOLVE_API_KEY" if os.environ.get("EVOLVE_API_KEY") else "ARK_API_KEY"
        typer.secho(
            f"warning: --api-key differs from ${which} in the environment. "
            f"Using --api-key (the flag wins). If you want this key to persist "
            f"across shells, update {which} in ~/.evolve-skill.env (or wherever "
            f"you source it from).",
            fg=typer.colors.YELLOW,
            err=True,
        )
    client = _client(c, explicit_api_key=api_key)
    try:
        result = client.call(
            "register_capability_map",
            {
                "agent_id": agent_id,
                "display_name": display_name,
                "runtime": connector,
                "environment": _BOUND_ENV,
                "connector": connector,
                "targets": [s.to_target_input() for s in specs],
                "refresh": refresh,
            },
        )
    except EvolveAPIError as e:
        _err(str(e))
    finally:
        client.close()

    c.capability_id = rget(result, "capability_id", "")
    c.save()
    cfg.write_capability_snapshot([s.to_target_input() for s in specs])
    binding = {}
    for s in specs:
        content = conn.read_target_content(runtime_root, s)
        binding[s.target_id] = {"file_path": s.file_path, "digest": cfg.digest_text(content), "usable": s.usable}
    cfg.write_binding(binding)

    label = f"{display_name} ({agent_id})" if display_name else agent_id
    typer.secho(
        f"{rget(result, 'status', '?')}  agent_id={label} capability_id={c.capability_id} "
        f"digest={rget(result, 'capability_digest', '')} ({len(specs)} targets)",
        fg=typer.colors.GREEN,
    )


@app.command()
def status(connector: str = _CONNECTOR_OPT) -> None:
    """Show agent/runtime status and pending proposals."""
    c = _load_config(connector)
    client = _client(c)
    try:
        result = client.call("get_status", {"agent_id": c.agent_id, "environment": c.environment})
        reachable = True
    except EvolveAPIError:
        result, reachable = {}, False
    finally:
        client.close()
    la = cfg.last_apply()
    # Server-side display_name wins (it's the authoritative name); fall back to
    # the locally-cached one so `evolve status` still shows something useful
    # when the cloud is unreachable.
    server_display_name = rget(result, "display_name", "") if reachable else ""
    display_name = server_display_name or c.display_name
    typer.echo(f"agent_id:          {c.agent_id}")
    if display_name:
        typer.echo(f"display_name:      {display_name}")
    # `environment` is intentionally hidden — customers don't choose it (see
    # _BOUND_ENV); surfacing it would invite questions about a knob the skill
    # does not expose. Re-show only if/when per-call switching is added.
    typer.echo(f"connector:         {c.connector}")
    typer.echo(f"runtime_root:      {_runtime_root_for(c)}")
    typer.echo(f"capability_synced: {rget(result, 'capability_synced', False)}")
    typer.echo(f"cloud_reachable:   {reachable}")
    typer.echo(f"pending_proposals: {rget(result, 'pending_proposals', 0)}")
    typer.echo(f"last_apply:        {(la or {}).get('applied_at') or (la or {}).get('proposal_id') or '-'}")


@app.command(name="import")
def import_cmd(
    from_path: Optional[Path] = typer.Option(None, "--from", help="session file or dir (default: connector default)"),
    fmt: str = typer.Option("jsonl", "--format"),
    model: str = typer.Option("auto", "--model"),
    session_ids: Optional[List[str]] = typer.Option(None, "--session-id"),
    started_at: Optional[str] = typer.Option(None, "--started-at"),
    ended_at: Optional[str] = typer.Option(None, "--ended-at"),
    limit: Optional[int] = typer.Option(None, "--limit"),
    no_wait: bool = typer.Option(False, "--no-wait", help="return import_id immediately without polling"),
    connector: str = _CONNECTOR_OPT,
) -> None:
    """Import session logs as evidence; the cloud analyzes them asynchronously."""
    c = _load_config(connector)
    conn = get_connector(c.connector)
    # Apply the same per-import cap the server uses (_DEFAULT_SESSION_LIMIT) so we
    # don't read and upload sessions that would only be trimmed on arrival. An
    # explicit positive --limit overrides; non-positive falls back to the default.
    effective_limit = limit if (limit is not None and limit > 0) else _DEFAULT_SESSION_LIMIT
    sessions = conn.read_sessions(
        from_path.expanduser() if from_path else None, fmt, session_ids, started_at, ended_at, effective_limit
    )
    if not sessions:
        _err("no sessions found to import")
    client = _client(c)
    try:
        result = client.call(
            "import_sessions",
            {
                "agent_id": c.agent_id,
                "capability_id": c.capability_id,
                "environment": c.environment,
                "model": model,
                "sessions": sessions,
                "format": fmt,
                "session_ids": session_ids,
                "started_at": started_at,
                "ended_at": ended_at,
                "limit": effective_limit,
            },
        )
        import_id = rget(result, "import_id", "")
        # Server-side default cap (10) trims oversized inputs; surface the real
        # processed count so the user doesn't think they uploaded more than was
        # analyzed. Falls back to len(sessions) for older backends that don't
        # populate the count fields yet.
        processed = rget(result, "session_count", len(sessions))
        original = rget(result, "original_session_count", len(sessions))
        typer.secho(
            f"import_id={import_id} status={rget(result, 'status', '?')} ({processed} sessions)",
            fg=typer.colors.GREEN,
        )
        if isinstance(original, int) and isinstance(processed, int) and original > processed:
            typer.secho(
                f"  note: server trimmed {original} -> {processed} sessions (use --limit to set a smaller cap)",
                fg=typer.colors.YELLOW,
            )
        if no_wait:
            return
        typer.echo("analyzing", nl=False)
        for _ in range(120):  # poll up to ~10 min
            time.sleep(5)
            typer.echo(".", nl=False)
            st = client.call("get_import_status", {"import_id": import_id})
            run = rget(st, "import_run", {})
            if run.get("status") in _TERMINAL:
                typer.echo("")
                typer.secho(
                    f"{run.get('status')}: signals={run.get('signal_count')} "
                    f"proposals={run.get('generated_proposal_count')} "
                    f"expressions={run.get('generated_expression_count')}",
                    fg=typer.colors.GREEN if run.get("status") == "completed" else typer.colors.RED,
                )
                if run.get("error"):
                    typer.echo(f"error: {run.get('error')}")
                typer.echo(f"next: evolve proposal {import_id}")
                return
        typer.echo("\n(still running; check `evolve proposal " + import_id + "` later)")
    except EvolveAPIError as e:
        _err(str(e))
    finally:
        client.close()


@app.command()
def proposals(
    status: Optional[str] = typer.Option(None, "--status", help="not_applied|applied|pending|approved|rejected"),
    limit: int = typer.Option(20, "--limit"),
    connector: str = _CONNECTOR_OPT,
) -> None:
    """List proposals."""
    c = _load_config(connector)
    client = _client(c)
    try:
        result = client.call("list_proposals", {"agent_id": c.agent_id, "status": status, "limit": limit})
    except EvolveAPIError as e:
        _err(str(e))
    finally:
        client.close()
    items = rget(result, "proposals", [])
    if not items:
        typer.echo("(no proposals)")
        return
    for p in items:
        typer.echo(proposal_summary_line(p))


@app.command()
def proposal(
    id: str = typer.Argument(..., metavar="ID", help="import_id (ep_…) or proposal_id (p_…)"),
    connector: str = _CONNECTOR_OPT,
) -> None:
    """Show proposals and render local diff previews (no runtime write).

    Accepts either an ``import_id`` (``ep_*`` — every proposal generated by that
    import) or a single ``proposal_id`` (``p_*``). Prefix-typed ids are routed
    server-side via the matching ``get_proposal`` argument; explicit prefixes
    make the dispatch unambiguous without an extra ``--by`` flag.
    """
    c = _load_config(connector)
    conn = get_connector(c.connector)
    runtime_root = _runtime_root_for(c)
    _require_usable_surface(conn, c.connector, runtime_root)
    client = _client(c)
    if id.startswith("p_"):
        params, preview_key = {"proposal_id": id}, id
    elif id.startswith("ep_"):
        params, preview_key = {"import_id": id}, id
    else:
        # Unknown shape — default to import_id for back-compat with old call
        # sites that passed a bare import id. The server will 4xx if it's
        # neither, and we surface that error verbatim.
        params, preview_key = {"import_id": id}, id
    try:
        result = client.call("get_proposal", params)
    except EvolveAPIError as e:
        _err(str(e))
    finally:
        client.close()
    items = rget(result, "proposals", [])
    if not items:
        typer.echo("(no proposals found)")
        return
    out_dir = cfg.preview_dir(preview_key)
    for p in items:
        typer.echo("\n" + render_proposal_detail(p))
        for e in p.get("expressions", []):
            target_id = (e.get("target") or {}).get("target_id", "")
            spec = conn.target_by_id(runtime_root, target_id)
            if spec is None:
                continue
            before, after = conn.preview_edit(runtime_root, spec, e.get("op", "append"), e.get("payload", {}))
            diff = unified_diff(before, after, spec.file_path)
            (out_dir / f"{e.get('expression_id', 'exp')}.diff").write_text(diff)
    typer.secho(f"\npreviews written to {out_dir}", fg=typer.colors.BLUE)


@app.command()
def capability(
    target_id: Optional[str] = typer.Argument(None),
    # Take the value explicitly (``--auto-apply true|false``) rather than a bare
    # flag, so the policy can be turned both on AND off and the documented syntax
    # works. A bare ``--auto-apply`` flag could only ever set it to true.
    auto_apply: Optional[str] = typer.Option(None, "--auto-apply", help="true or false"),
    connector: str = _CONNECTOR_OPT,
) -> None:
    """List capabilities, or toggle Auto Apply for one."""
    c = _load_config(connector)
    aa: Optional[bool] = None
    if auto_apply is not None:
        if auto_apply.strip().lower() not in ("true", "false"):
            _err("--auto-apply must be 'true' or 'false'")
        aa = auto_apply.strip().lower() == "true"
    client = _client(c)
    try:
        if target_id and aa is not None:
            result = client.call(
                "update_capability",
                {
                    "target_id": target_id,
                    "auto_apply": aa,
                    # scope the target to this agent's CapabilityMap (target_id is not
                    # globally unique on the backend).
                    "agent_id": c.agent_id,
                    "environment": c.environment,
                },
            )
            cap = rget(result, "capability", {})
            typer.secho(f"{cap.get('target_id')} auto_apply={cap.get('auto_apply')}", fg=typer.colors.GREEN)
        else:
            result = client.call("list_capabilities", {"agent_id": c.agent_id, "environment": c.environment})
            for cap in rget(result, "capabilities", []):
                typer.echo(
                    f"{cap.get('target_id'):24} {cap.get('target_type'):24} "
                    f"auto_apply={cap.get('auto_apply')}  {cap.get('display_name', '')}"
                )
    except EvolveAPIError as e:
        _err(str(e))
    finally:
        client.close()


@app.command()
def approve(proposal_id: str = typer.Argument(...), connector: str = _CONNECTOR_OPT) -> None:
    """Approve a proposal (required before `evolve apply` for manual-review proposals)."""
    _decide(proposal_id, "approved", connector)


@app.command()
def reject(proposal_id: str = typer.Argument(...), connector: str = _CONNECTOR_OPT) -> None:
    """Reject a proposal; its expressions are disabled and it can never be applied."""
    _decide(proposal_id, "rejected", connector)


def _decide(proposal_id: str, decision: str, connector: str = "") -> None:
    c = _load_config(connector)
    client = _client(c)
    try:
        result = client.call("submit_proposal_decision", {"proposal_id": proposal_id, "decision": decision})
        typer.secho(
            f"{rget(result, 'proposal_id', proposal_id)} -> {rget(result, 'decision', decision)}", fg=typer.colors.GREEN
        )
    except EvolveAPIError as e:
        _err(str(e))
    finally:
        client.close()


def _external_manifest_path(proposal_id: str, expression_id: str) -> Path:
    return cfg.preview_dir(proposal_id) / f"{expression_id}.expected.json"


def _write_external_manifest(
    proposal_id: str,
    expression_id: str,
    target_id: str,
    file_path: str,
    op: str,
    before: str,
    after: str,
    change_id: str,
) -> Path:
    """Persist the write the CLI *meant* to make, so a failed apply can be finished
    by the agent writing the file itself and confirming with --confirm-external."""
    out_dir = cfg.preview_dir(proposal_id)
    manifest = {
        "proposal_id": proposal_id,
        "expression_id": expression_id,
        "target_id": target_id,
        "file_path": file_path,
        "op": op,
        "change_id": change_id,
        "before_digest": cfg.digest_text(before),
        "after_digest": cfg.digest_text(after),
    }
    manifest_path = out_dir / f"{expression_id}.expected.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2))
    (out_dir / f"{expression_id}.after.txt").write_text(after)
    (out_dir / f"{expression_id}.diff").write_text(unified_diff(before, after, file_path))
    return manifest_path


def _confirm_external_write(client: EvolveClient, proposal_id: str, expression_id: str) -> None:
    """Verify a file the agent wrote itself (after `evolve apply` failed to write it)
    matches the content the CLI intended, then report + journal it exactly like a
    normal apply would have."""
    manifest_path = _external_manifest_path(proposal_id, expression_id)
    if not manifest_path.exists():
        _err(
            f"no pending external-write record for expression {expression_id} under proposal {proposal_id} "
            f"(run `evolve apply {proposal_id}` first — this only works after it reports a write failure)"
        )
    manifest = json.loads(manifest_path.read_text())
    file_path = Path(manifest["file_path"])
    if not file_path.exists():
        _err(
            f"{file_path} does not exist yet — write the intended content (see {manifest_path.parent / f'{expression_id}.after.txt'}) before confirming"
        )
    current_digest = cfg.digest_text(file_path.read_text(errors="ignore"))
    if current_digest != manifest["after_digest"]:
        _err(
            f"{file_path} does not match the intended content (digest {current_digest} != expected "
            f"{manifest['after_digest']}) — see {manifest_path.parent / f'{expression_id}.after.txt'} for the "
            f"exact content, or {manifest_path.parent / f'{expression_id}.diff'} for the diff"
        )
    client.call(
        "submit_apply_result",
        {
            "operation_id": f"{proposal_id}:{expression_id}",
            "proposal_id": proposal_id,
            "expression_id": expression_id,
            "change_id": manifest["change_id"],
            "status": "applied",
            "after_digest": current_digest,
        },
    )
    cfg.append_journal(
        cfg.ApplyJournalEntry(
            proposal_id=proposal_id,
            expression_id=expression_id,
            target_id=manifest["target_id"],
            file_path=manifest["file_path"],
            op=manifest["op"],
            change_id=manifest["change_id"],
            before_digest=manifest["before_digest"],
            after_digest=current_digest,
            applied_at=_now(),
            extra={"externally_written": True},
        )
    )
    manifest_path.unlink()
    typer.secho(f"  confirmed external write {manifest['target_id']} -> {file_path}", fg=typer.colors.GREEN)
    remaining = sorted(p.stem.rsplit(".expected", 1)[0] for p in manifest_path.parent.glob("*.expected.json"))
    if remaining:
        typer.secho(
            f"  {len(remaining)} expression(s) still outstanding: {', '.join(remaining)}", fg=typer.colors.YELLOW
        )
        return
    client.call("apply_proposal", {"proposal_id": proposal_id})
    typer.secho(f"all expressions resolved — proposal {proposal_id} finalized", fg=typer.colors.GREEN)


@app.command()
def apply(
    proposal_id: str = typer.Argument(...),
    dry_run: bool = typer.Option(False, "--dry-run", help="show what would change without writing"),
    confirm_external: Optional[str] = typer.Option(
        None,
        "--confirm-external",
        help="expression_id you wrote to disk yourself after a prior `evolve apply` reported a write "
        "failure for it; verifies the file matches the intended content and records it",
    ),
    connector: str = _CONNECTOR_OPT,
) -> None:
    """Apply a proposal to the runtime (the only command that writes). Reports each result to the cloud."""
    c = _load_config(connector)
    conn = get_connector(c.connector)
    runtime_root = _runtime_root_for(c)
    # Guard against a moved/renamed/deleted runtime root BEFORE the write loop:
    # apply_edit does `mkdir -p` on the target's parent, so a stale root would be
    # silently *resurrected* and the evolvor chunk would land in a ghost folder the
    # live agent never reads. Refuse loudly instead. (Self-heal above already fixed
    # a project-local move; this catches home-based installs that can't self-heal.)
    _require_usable_surface(conn, c.connector, runtime_root)
    client = _client(c)
    try:
        if confirm_external:
            _confirm_external_write(client, proposal_id, confirm_external)
            return
        detail = client.call("get_proposal", {"proposal_id": proposal_id})
        items = rget(detail, "proposals", [])
        if not items:
            _err(f"proposal {proposal_id} not found")
        p = items[0]
        # Review gate: never touch the runtime for an undecided/rejected proposal.
        # (Server-side apply_proposal / submit_apply_result enforce the same rule;
        # checking here keeps the runtime untouched instead of failing halfway.)
        decision = p.get("decision", "pending")
        if not dry_run and decision == "pending":
            _err(
                f"proposal {proposal_id} is pending review — run `evolve approve {proposal_id}` first "
                f"(or `evolve reject {proposal_id}`); use --dry-run to inspect the change"
            )
        if not dry_run and decision == "rejected":
            _err(f"proposal {proposal_id} was rejected and cannot be applied")
        applied: List[str] = []
        failed: List[str] = []
        for e in p.get("expressions", []):
            target_id = (e.get("target") or {}).get("target_id", "")
            spec = conn.target_by_id(runtime_root, target_id)
            if spec is None:
                typer.secho(f"  skip {target_id}: not a known runtime target", fg=typer.colors.YELLOW)
                continue
            op, payload = e.get("op", "append"), e.get("payload", {})
            expression_id = e.get("expression_id", "")
            if dry_run:
                before, after = conn.preview_edit(runtime_root, spec, op, payload)
                typer.echo(unified_diff(before, after, spec.file_path))
                continue
            try:
                before, after, change_id = conn.apply_edit(runtime_root, spec, op, payload)
            except OSError as write_err:
                # The write itself failed (permission denied, read-only fs, disk full,
                # …). Don't crash the whole apply on a raw traceback and don't lose
                # progress on expressions that already wrote fine — persist what we
                # MEANT to write so the agent can write it itself and confirm later.
                before, after = conn.preview_edit(runtime_root, spec, op, payload)
                change_id = f"chg_{uuid.uuid4().hex[:16]}"
                # preview_edit stamps the evolvor chunk with a placeholder "preview" id
                # (fine for a read-only --dry-run diff); this content is going to be
                # written verbatim by the agent, so it needs the real change_id.
                after = after.replace("evolvor:preview", f"evolvor:{change_id}")
                manifest_path = _write_external_manifest(
                    proposal_id, expression_id, target_id, spec.file_path, op, before, after, change_id
                )
                failed.append(expression_id)
                typer.secho(f"  FAILED to write {target_id} -> {spec.file_path}: {write_err}", fg=typer.colors.RED)
                typer.echo(unified_diff(before, after, spec.file_path))
                typer.secho(
                    f"    intended content saved to {manifest_path.parent / f'{expression_id}.after.txt'} — "
                    f"write it yourself, then run: evolve apply {proposal_id} --confirm-external {expression_id}",
                    fg=typer.colors.YELLOW,
                )
                continue
            after_digest = cfg.digest_text(after)
            client.call(
                "submit_apply_result",
                {
                    "operation_id": f"{proposal_id}:{expression_id}",
                    "proposal_id": proposal_id,
                    "expression_id": expression_id,
                    "change_id": change_id,
                    "status": "applied",
                    "after_digest": after_digest,
                },
            )
            cfg.append_journal(
                cfg.ApplyJournalEntry(
                    proposal_id=proposal_id,
                    expression_id=expression_id,
                    target_id=target_id,
                    file_path=spec.file_path,
                    op=op,
                    change_id=change_id,
                    before_digest=cfg.digest_text(before),
                    after_digest=after_digest,
                    applied_at=_now(),
                )
            )
            applied.append(expression_id)
            typer.secho(f"  applied {target_id} ({op}) -> {spec.file_path}", fg=typer.colors.GREEN)
        if dry_run:
            typer.echo("(dry-run; nothing written)")
            return
        if failed:
            # Don't finalize a proposal that's only partially written — the server-side
            # apply_proposal call means "fully applied"; a partial write must stay open
            # until every failed expression is resolved via --confirm-external.
            typer.secho(
                f"\npartial apply: {len(applied)} written, {len(failed)} failed to write — proposal NOT "
                f"finalized. Resolve each failure above, then re-run `evolve apply {proposal_id}` to finalize.",
                fg=typer.colors.RED,
            )
            raise typer.Exit(1)
        client.call("apply_proposal", {"proposal_id": proposal_id})
        typer.secho(f"applied proposal {proposal_id} ({len(applied)} expressions)", fg=typer.colors.GREEN)
        # Reconcile: report which expressions are now active on this instance
        # (best-effort — a failed heartbeat must not fail the apply).
        try:
            _send_heartbeat(client, c)
        except EvolveAPIError:
            typer.secho("(heartbeat failed; run `evolve heartbeat` to reconcile later)", fg=typer.colors.YELLOW)
    except EvolveAPIError as e:
        _err(str(e))
    finally:
        client.close()


@app.command()
def heartbeat(connector: str = _CONNECTOR_OPT) -> None:
    """Report the instance's active expressions to the cloud for reconciliation."""
    c = _load_config(connector)
    client = _client(c)
    try:
        hb_id = _send_heartbeat(client, c)
        typer.secho(f"heartbeat={hb_id}", fg=typer.colors.GREEN)
    except EvolveAPIError as e:
        _err(str(e))
    finally:
        client.close()


def _send_heartbeat(client: EvolveClient, c: cfg.EvolveConfig) -> str:
    import socket

    # Active = every expression ever applied on this instance, per the local
    # apply-journal (rollbacks would remove entries once supported).
    seen: List[str] = []
    for entry in cfg.read_journal():
        eid = entry.get("expression_id", "")
        if eid and eid not in seen:
            seen.append(eid)
    result = client.call(
        "submit_heartbeat",
        {
            "instance_id": f"{c.agent_id}@{socket.gethostname()}",
            "agent_id": c.agent_id,
            "plugin_version": "evolve_cli",
            "active_expression_ids": seen,
        },
    )
    return rget(result, "heartbeat_id", "")


def _now() -> str:
    from datetime import datetime, timezone

    return datetime.now(timezone.utc).isoformat()


def main() -> None:
    app()


if __name__ == "__main__":
    main()
