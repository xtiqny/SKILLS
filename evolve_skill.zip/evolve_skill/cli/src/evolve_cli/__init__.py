"""Evolve CLI — local deterministic execution kernel.

A lightweight client for the case_platform ``self_evolve`` backend. It discovers a
local agent runtime through a connector, syncs its evolvable surfaces as a
CapabilityMap, imports session logs as evidence, and applies cloud-generated
Proposals back to the runtime. It talks to the backend over HTTP only and never
imports the server package.
"""

__version__ = "0.1.0"
