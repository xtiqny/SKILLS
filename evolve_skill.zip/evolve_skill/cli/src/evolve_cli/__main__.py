"""Allow invocation as ``python -m evolve_cli`` so tooling that knows the
Python interpreter the package is installed under can call the CLI without
relying on the PATH-resolved ``evolve`` console script. Useful when a
customer machine has a stale ``evolve`` shim from an earlier install on a
different interpreter."""

from evolve_cli.main import main

if __name__ == "__main__":
    main()
