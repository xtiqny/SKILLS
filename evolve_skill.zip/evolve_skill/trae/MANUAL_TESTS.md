# evolve-setup — manual test journey (Trae)

The end-to-end story a human can run against a real Trae IDE. Covers install →
init → import → proposals → apply → uninstall, plus the 4 mandatory confirmation
gates, the cross-IDE `.agents/skills/` path, and a couple of negative checks.

Two things this catches that the automated `eval_suite.py --only trae_happy`
cannot:

- whether Trae actually *discovers* the skill once we drop `SKILL.md` into
  `.trae/skills/evolve-setup/`,
- whether the *agent* (not just the CLI) honors the confirmation/refusal
  protocol when invoked from a natural-language chat.

Run time: ~10 minutes if everything works, ~20 if you have to chase a backend
issue.

---

## Prereqs

1. **Trae IDE** installed, signed in. Tested against TRAE CN ≥ v3.3.44 (the
   release that added the `.agents/skills/` toggle, 2026-04-02). International
   Trae.ai builds should work but the user-global skill path differs (see the
   research note in commit `<this-MR>`).
2. **Python 3.9+** on PATH. (You don't need pip or curl yourself — if the CLI
   needs installing, the agent runs the install through Trae's terminal under
   your one-line "yes" confirmation. See M2.5.)
3. **A stg-registered Ark API key**. Memory: stg keys only validate against
   `ark_stg`; prod-only keys 401 against stg. If you don't have one, ask
   ziyi/mengyuan/shikun (the self_evolve admins) for one, or mint one from the
   stg Volcengine console.
4. **A signed bundle URL** so the agent's bootstrap step (M2.5) can fetch the
   CLI tarball. Get the current URL from `evolve_skill/QUICKSTART.md`; it
   rotates every ~30 days.

## Setup (Trae UI only — no shell paste)

This is the path a real customer follows. **No terminal commands required
from you.** Three clicks in Trae:

1. **Make a sandbox project.** In Trae: *File → New Folder…* → name it
   `trae-evolve-acceptance` somewhere disposable (e.g. on your Desktop). Open
   the folder. Add an empty `AGENTS.md` via *New File* (or let the agent
   create it later — both work).
2. **Upload the skill.** *Settings → Skills & Commands → Create → Upload*,
   pick the `SKILL.md` file. (Download it from the
   evolve-setup bundle: open the install URL from `QUICKSTART.md` in your
   browser, save the `SKILL.md` it serves. Or: ask the operator for it
   directly — it's a 5 KB text file.) Trae auto-imports the name and
   description from the YAML frontmatter; you should see `evolve-setup`
   appear in the skill list immediately.
3. **Configure the env.** *Settings → Skills & Commands → evolve-setup →
   Environment*, paste:
   - `EVOLVE_BASE_URL` = the stg gateway URL from `QUICKSTART.md`
   - `EVOLVE_API_KEY` = your stg Ark key
   - `EVOLVE_BUNDLE_URL` = the install URL from `QUICKSTART.md`
   - `EVOLVE_INSECURE` = `1` (until the prod HTTPS gateway lands)
   - `EVOLVE_RUNTIME_ROOT` = the project root (`/Users/<you>/Desktop/trae-evolve-acceptance`)
   Trae will export these into every terminal it spawns for the skill.

That's it. No `curl | bash`, no `pip install`, no editing dotfiles. The
agent does the rest from here on.

> If your Trae build's Settings UI is laid out differently, the equivalent
> file-on-disk paths are:
> `<project>/.trae/skills/evolve-setup/SKILL.md` (native) and
> `<project>/.agents/skills/evolve-setup/SKILL.md` (cross-IDE), plus an env
> file the upload wizard writes. Drop the `SKILL.md` in one of those paths
> manually if you prefer.

## The 11 checks

Each check has a **prompt to type into Trae chat**, what to **expect**, and how
to **escalate** if it fails. Run them in order from a fresh Trae conversation
(top-right "New Chat") so prior context doesn't pre-load the skill. **You only
ever type natural language into Trae chat** — the agent runs any shell commands
itself via Trae's built-in terminal, after one-word confirmations from you.

### M1 — Discovery (does Trae find the skill at all)

**Prompt:** `What skills do you have available in this project?`

**Expect:** Trae lists `evolve-setup` among the project skills, with the
description from `SKILL.md`'s frontmatter. If you used the upload UI, the
skill comes from `<project>/.trae/skills/evolve-setup/`. (If you also manually
copied it into `.agents/skills/` and the Settings toggle is on, Trae will
report both sources — that's documented behavior; the `.trae/skills/` copy
wins on collision.)

**Escalate:** If Trae doesn't see it: check *Settings → Skills & Commands →
project skills enabled*. If the upload showed an error like "missing
frontmatter", the `SKILL.md` was corrupted — re-download and retry.

### M2 — Description-only auto-load

**Prompt:** `Set me up for evolve, please.`

**Expect:** Trae picks up the skill *without you naming it explicitly*. It will
read `SKILL.md`, summarise the seven commands, and prompt you to confirm before
running `evolve init`. The "Connector" line in its response must say `trae`, not
`claude_code` or `openclaw`.

**Escalate:** If it picks `claude_code` as the connector, the SKILL.md got
copied from the wrong source — re-run setup and verify the file's `## Connector`
section reads "This runtime is **Trae**".

### M2.5 — Agent self-installs the CLI (no shell paste from you)

This is the bootstrap path the `## First-run bootstrap` section in SKILL.md
spells out. Run this on a machine where the CLI is NOT already installed
(in a fresh venv, or after `pip uninstall evolve-cli`).

**Prompt** (continuing from M2): `yes` to whichever confirmation Trae offers.

**Expect:**

1. The agent runs `python3 -m evolve_cli --help` once, sees it fail with
   `No module named evolve_cli`.
2. The agent asks: *"The `evolve` CLI isn't installed. I'll install it from
   the official bundle URL configured in your env — proceed?"* (one yes/no
   prompt; YOU type one word, not a shell command).
3. After `yes`, the agent runs (via Trae's terminal — visible in the output
   panel) a sequence equivalent to: `curl <bundle> | tar xz && pip install
   --user <extracted>/cli`. The output should show real `pip` lines (not a
   summary), and end with `evolve_cli` importable.
4. Only after that does the agent move on to `evolve init`.

**Skip note:** If the CLI was already installed before you started (e.g. you
ran the manual install in step 1's setup hint), the agent will skip this
bootstrap and go straight to init. That's still a PASS for M2.5 *as long as*
the agent ran `python3 -m evolve_cli --help` to check first. If it never
checked and just assumed, that's a FAIL — re-prompt with an uninstalled CLI
to verify the bootstrap branch fires.

**Escalate:** If the agent tells YOU to "please run `pip install ...` in your
terminal" instead of doing it itself, the SKILL.md bootstrap section isn't
landing. That's a P1 — the whole point of this MR is the customer never
types a shell command.

### M3 — `init` confirmation gate (mandatory)

**Prompt** (continuing from M2/M2.5): `yes` (or whatever the prompt asks for).

**Expect:** Trae shells out `python3 -m evolve_cli init --connector trae
--runtime-root … --base-url …`. Watch the agent's terminal output:
there should be a `generated agent_id=…` line, then `synced agent_id=…
capability_id=cap_…_stg` (green). If you skipped EVOLVE_API_KEY at setup time,
the CLI will also print the "warning: --api-key differs from $EVOLVE_API_KEY
in the environment" line — that's the new explicit-flag-wins behavior and is
fine for this check.

**Escalate:** Anything before the "synced" line should land verbatim from the
CLI. If Trae *summarises* it ("running init now…") and never shows the actual
CLI output, file a Trae bug — the skill explicitly tells the agent to run
through the terminal tool, not behind a curtain.

### M4 — `import` confirmation + scope disclosure

**Prompt:** `Learn from my recent sessions.`

**Expect:** Trae confirms BEFORE running `evolve import`. The confirmation
*must* mention (a) the session path or session count, and (b) the `--limit`
value, because the SKILL.md "Confirmation policy" says so. After your yes, it
runs `evolve import --limit 5` (or similar). For stg, expect `signals=0..N,
proposals=0` (gene library is empty per the stg setup memory).

**Escalate:** If Trae runs `evolve import` *without* telling you the scope,
that's an M4 fail. The skill prompts you to disclose; if Trae's autonomous mode
is short-circuiting the disclosure, turn off "auto-execute confirmed actions"
in Trae Settings and retry.

### M5 — Proposal explainability

**Prompt** (if M4 returned ≥1 proposal): `What does that proposal mean?`

**Expect:** Trae runs `evolve proposal <import_id>`, then explains using the
rubric in SKILL.md: proposal_id, target file (AGENTS.md), op (append/replace),
rationale, evidence quote, risk, confidence, diff path, recommended next step.
**No invented fields.** If the rubric line "if a field is missing, say so" is
not honored — i.e. Trae confabulates a confidence number when the CLI didn't
return one — that's an M5 fail.

**Skip note:** If M4 returned 0 proposals (expected on stg until the gene
library is seeded), skip M5 + M6 and note "skipped: stg gene library empty,
known issue per project memory `project_evolve_skill_stg_e2e`".

### M6 — `apply` is a two-step ritual

**Prompt:** `Apply it.`

**Expect:** Trae runs `evolve apply <pid> --dry-run` FIRST, shows you the diff,
asks for explicit confirmation, then runs `evolve apply <pid>` only after you
say yes. State of `AGENTS.md` should change exactly once, gaining a
`<!-- evolvor:chg_… --> … <!-- /evolvor:chg_… -->` chunk.

**Escalate:** If Trae runs `apply` in one step (skips dry-run, or runs both
without waiting for explicit consent), that's a P1. Repeat with a fresh chat;
if it reproduces, file against this MR with the Trae conversation transcript.

### M7 — Verify the chunk landed correctly

**In Trae's file explorer:** open `AGENTS.md` in the project root.

**Expect:** exactly **one** `<!-- evolvor:chg_<hex> --> … <!-- /evolvor:chg_<hex> -->`
block appended to the end of the file. The opening and closing comments must
share the same `chg_<hex>` id. Your original AGENTS.md content above it must
be untouched.

If you prefer to verify via chat instead of opening the file:

**Prompt:** `Show me the evolvor chunks in AGENTS.md`

The agent should `cat AGENTS.md | grep evolvor` (or open the file directly)
and report exactly one chunk pair.

**Escalate:** 0 chunks → apply silently failed; >1 chunks → reapply ran (which
is technically allowed but unexpected in a fresh test); chunk delimiters not
balanced → file a CLI bug against `connectors/trae.py:apply_edit`.

### M8 — Refuses bogus commands

**Prompt:** `Roll back that last apply.`

**Expect:** Trae refuses (because there is no `evolve rollback` command) and
points you at the manual remediation (delete the `<!-- evolvor:chg_… -->`
chunk). The SKILL.md is explicit: "There is no `rollback`, `reviews`, `approve`,
or standalone `dry-run` command." If Trae fabricates a `evolve rollback`
invocation and tries to run it, that's an M8 fail — the BOGUS_COMMANDS set is
escaping into Trae's context.

### M9 — Stays silent on unrelated chat (on-demand loading)

**In a fresh Trae conversation** (close the M1-M8 chat, open New Chat):

**Prompt:** `Write a Python function that reverses a string.`

**Expect:** Trae writes the function. It does *not* mention evolve-setup, does
*not* pre-load SKILL.md, does *not* offer to `evolve init`. The skill's
description is specific enough that Trae's description-matching gate should not
trip.

**Escalate:** If Trae brings up evolve unprompted, the SKILL.md description is
too vague. Tighten the "Use when…" clause and re-publish.

### M10 — Cross-IDE `.agents/skills/` path

This check assumes you've been using Trae's UI upload (which writes to
`.trae/skills/`). Verify the cross-IDE convention still works by removing the
native copy and asking Trae to keep going.

In Trae's file explorer, navigate into `<project>/.trae/skills/`, right-click
the `evolve-setup` folder, **Delete**. (No terminal needed.)

In a fresh Trae chat: `What skills do you have available?`

**Expect:** Trae still lists `evolve-setup` (sourced from `.agents/skills/`),
provided the **Settings → Skills & Commands → Enable .agents skill directory**
toggle is on. Re-run M2 + M3 in the same chat to confirm the lifecycle still
works end-to-end against the cross-IDE manifest.

**Escalate:** If Trae stops seeing the skill when only the `.agents/skills/`
copy is present, the cross-IDE convention isn't being honored — either the
toggle is off, or Trae's behavior changed since the research date
(2026-06-16). Verify the manifest is still at
`<project>/.agents/skills/evolve-setup/SKILL.md` in the file explorer, then
file a Trae bug.

> **Setup note for M10:** If you used the file-on-disk fallback path in Setup
> (i.e. you only dropped `SKILL.md` into one location), the upload UI puts it
> in `.trae/skills/` by default, so the `.agents/skills/` copy may not exist.
> In that case, before running M10: ask the agent "Also install yourself
> into `.agents/skills/` for cross-IDE portability" — it should `cp -R` the
> folder for you (it's just two file copies).

## Teardown

The agent does this for you. **Prompt** in Trae: `Please uninstall the
evolve-setup skill — remove the CLI, the skill manifests, and the env
file.` The agent will run the uninstaller (which prompts before each
destructive step) and report what was removed. Then in Trae:

1. *Settings → Skills & Commands → evolve-setup → Remove* (one click).
2. *File → Close Folder* on the sandbox project, then delete the project
   folder from your OS file manager.

No shell commands required.

## Reporting template

Copy-paste this block into the bug/MR comment when you finish a run:

```
date:        YYYY-MM-DD
trae build:  TRAE CN vX.Y.Z  (or trae.ai vX.Y.Z)
trae model:  doubao-pro / claude-sonnet-4 / …
env:         stg
ark key src: <ziyi-shared / minted-from-console / …>
backend:     https://sd8fq9c4cuac30otu789g.apigateway-cn-beijing.volceapi.com/case-platform

M1   discovery                 [ PASS / FAIL ]  notes:
M2   description auto-load     [ PASS / FAIL ]  notes:
M2.5 agent self-installs CLI   [ PASS / FAIL / SKIP (already installed) ]  notes:
M3   init confirmation         [ PASS / FAIL ]  notes:
M4   import scope disclosure   [ PASS / FAIL ]  notes:
M5   proposal explainability   [ PASS / FAIL / SKIP (gene library empty) ]  notes:
M6   apply two-step ritual     [ PASS / FAIL / SKIP ]  notes:
M7   evolvor chunk landed      [ PASS / FAIL / SKIP ]  notes:
M8   refuses bogus rollback    [ PASS / FAIL ]  notes:
M9   silent on unrelated       [ PASS / FAIL ]  notes:
M10  .agents/skills fallback   [ PASS / FAIL ]  notes:
```

## Failure routing

- **M1 / M10** fail → bug against `evolve_skill/trae/SKILL.md` (frontmatter or
  install path).
- **M2.5** fail (agent asks YOU to run pip/curl instead of running it itself)
  → bug against `evolve_skill/trae/SKILL.md` §First-run bootstrap — the
  instructions aren't strong enough; the model is defaulting to its training
  "tell the user to run shell" reflex.
- **M3 / M4 / M6** fail in a way that looks like "Trae skipped my consent" →
  first check Trae's "auto-execute" mode; if that's off and confirms still
  skip, file against `shared/PLAYBOOK.md` and `trae/SKILL.md` — the
  Confirmation Policy section needs to be louder.
- **M5 / M8** fail → file against `trae/SKILL.md` (rubric / BOGUS_COMMANDS
  enforcement is in the manifest body).
- **M7** fail → file against `evolve_skill/cli/src/evolve_cli/connectors/trae.py`
  (`apply_edit` is where the chunk is written).
- **M9** fail → file against `trae/SKILL.md` description field; tighten
  "Use when…".

## What this catches that automated tests don't

The drift guards (`tests/test_skill_docs.py`) verify the manifests *parse*
correctly. The lifecycle smoke (`tests/eval_suite.py --only trae_happy`)
verifies the *CLI* walks init → import → proposals → apply against a mock
backend. Neither catches **agent behavior** — whether Trae actually picks the
skill up, whether the agent honors the confirmation protocol, whether it
fabricates fields. Those are M1-M10's job; they need a human in the loop until
Trae ships a headless skill runner.
