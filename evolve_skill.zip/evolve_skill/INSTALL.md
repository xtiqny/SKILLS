# Evolve Skill — install & uninstall guide

The **evolve-setup** skill connects your coding agent (Claude Code or OpenClaw) to
the self_evolve service so the agent can learn from past sessions and propose
edits to its own instruction files. This page is the customer-facing setup guide.

> Everything you need is in this one folder: the `evolve` CLI lives in `cli/`,
> and the runtime manifests live in `claude_code/` and `openclaw/`. The
> installer ties them together.

---

## TL;DR — one-line install

The fastest path. Paste this into your shell, or paste it to your agent and ask
"please run this":

```bash
curl -fsSL "https://ark-self-evolve-stg.tos-cn-beijing.volces.com/evolve_skill/latest/install.sh" | bash
```

That's a permanent public URL (no signature, never expires) that downloads the
bundle from TOS, extracts it, and walks you through a short conversation:

```
1. Backend URL                    (pre-filled with the rollout default)
2. Who are you to the backend?    Ark API key (only — backend derives the rest)
3. Which runtime is this skill for?   claude_code / openclaw / both
4. Installing the evolve CLI       (pip install ./cli)
5. Installing the skill manifest   → ~/.claude/skills/evolve-setup/
6. Writing ~/.evolve-skill.env     (sourceable, chmod 600)
7. Run `evolve init` now?          (registers the agent with the cloud)
```

When it's done, open your agent and say **"set me up for evolve"** or **"learn
from my recent sessions"** — the skill takes it from there.

> **About the default URL.** Today it points at the stg-style apigateway over
> plaintext `http://`, so the installer warns once that the Ark API key
> travels unencrypted. There is a `TODO(prod)` in `install.sh` to switch to
> `https://prompt-pilot.cn-beijing.volces.com` once the prod endpoint is up.
> Until then, accept the warning interactively, or set `EVOLVE_INSECURE=1` for
> non-interactive runs.

---

## Conversational install — what to ask your agent

If you'd rather have your agent run the installer for you, paste this:

> Please install the evolve_skill for this agent. Download the installer from
> the URL below and run it. I'll paste my Ark API key when prompted (the
> backend derives my account from the key, so that's the only credential
> you'll need to ask for).
>
> `curl -fsSL "<one-line-URL-above>" | bash`

The agent will:

1. Run the curl + bash command.
2. Pause when the installer asks for the Ark API key (input is hidden).
3. Hand back control once the installer prints **"Done."**

If your agent runs in a non-interactive shell, set the env vars in advance and
the installer will skip every prompt:

```bash
export EVOLVE_NONINTERACTIVE=1
export EVOLVE_BASE_URL=https://sd8fq9c4cuac30otu789g.apigateway-cn-beijing.volceapi.com/case-platform
export EVOLVE_API_KEY="…your Ark API key…"
export EVOLVE_RUNTIME=claude_code         # or openclaw, or both
export EVOLVE_RUNTIME_ROOT="$PWD"         # where CLAUDE.md lives
curl -fsSL "<one-line-URL>" | bash
```

---

## What gets installed where

| Path | Purpose | Removed by `uninstall.sh`? |
|------|---------|----------------------------|
| `~/.local/lib/python*/site-packages/evolve_cli/` (or active venv) | the `evolve` CLI Python package | yes |
| `~/.local/bin/evolve` (or active venv) | the `evolve` console entry point | yes (via `pip uninstall`) |
| `~/.claude/skills/evolve-setup/` | Claude Code skill manifest (`SKILL.md`) + shared playbook | yes |
| `~/.openclaw/workspace/skills/evolve-setup/` | OpenClaw skill manifests (`SKILL.toml` + `SKILL.md`) + shared playbook | yes |
| `~/.evolve-skill.env` | sourceable env file with the values you entered | asks (default: keep) |
| `~/.evolve/` | CLI workspace: `config.yaml`, capability snapshot, diff previews, apply journal | asks (default: keep) |
| **inside CLAUDE.md / AGENTS.md / etc.** | applied proposals (`<!-- evolvor:chg_… -->` chunks) | **never** — see "Reverting applied proposals" below |

---

## Backend URL

The installer ships one rollout `EVOLVE_BASE_URL`. The wizard accepts it as the
default; override with `EVOLVE_BASE_URL` in the environment if you need to point
at a different gateway.

Default: `https://sd8fq9c4cuac30otu789g.apigateway-cn-beijing.volceapi.com/case-platform`
(HTTPS — no `EVOLVE_INSECURE=1` required).

A real backend rejects every action without a valid Ark key (HTTP 403 / `401
Invalid or expired token`). The local mock harness ignores the key — useful
for offline demos.

> **Why no env / account_id / user_name prompts.** The backend environment is
> bound at install time (see `_BOUND_ENV` in `cli/src/evolve_cli/main.py`), and
> under Ark-key auth the backend derives the owner account from the verified
> Ark key — the `X-Top-Account-Id` / `X-Top-User-Name` headers are ignored.
> The Ark API key is the sole identity. See `cli/src/evolve_cli/api.py` and
> the backend's `self_evolve/auth.py` if this changes.

---

## Already extracted the bundle?

If you have the folder on disk (e.g. you cloned it from git, or you ran
`tar xzf evolve_skill.tar.gz`):

```bash
cd evolve_skill
bash install.sh
```

Same wizard, no download.

---

## Uninstall

From inside the bundle folder:

```bash
bash uninstall.sh
```

…or, if you no longer have the folder, run the standalone uninstaller from TOS
(same permanent public URL):

```bash
curl -fsSL "https://ark-self-evolve-stg.tos-cn-beijing.volces.com/evolve_skill/latest/uninstall.sh" | bash
```

The uninstaller asks before each destructive step. Defaults:

- skill manifest dir(s): **remove**
- `evolve` CLI (pip): **uninstall**
- `~/.evolve-skill.env`: **keep** (so you can re-install with the same answers)
- `~/.evolve/` workspace: **keep** (config + apply journal)
- runtime files (CLAUDE.md, AGENTS.md, …): **never touched**

For a fully unattended teardown:

```bash
EVOLVE_NONINTERACTIVE=1 EVOLVE_REMOVE_HOME=1 EVOLVE_REMOVE_ENVFILE=1 \
  bash uninstall.sh
```

### Reverting applied proposals

Applied proposals are *removable chunks* in your runtime files:

```markdown
<!-- evolvor:chg_abc123 -->
…content the proposal added…
<!-- /evolvor:chg_abc123 -->
```

The uninstaller does **not** touch them — they're your files. Find them with:

```bash
grep -rl 'evolvor:chg_' "$HOME" "$PWD"
```

…and delete each chunk (the two HTML-comment delimiters and everything between).
**`replace`-op proposals are not wrapped** in a chunk — those edits are in
place and need git history (or a pre-edit copy of the file) to revert.

---

## Re-publishing the bundle

If you (the operator) need to re-bake the bundle:

```bash
# from /opt/code/ark_navigator/evolve_skill with INNER_AK / INNER_SK or PROMPT_PILOT_VENDOR_AK/SK on env
python3 scripts/publish_bundle.py --label vN        # tarball + install.sh
python3 scripts/build_upload_zips.py --label vN     # 3 per-runtime zips
```

Both scripts default to the **public-read** `ark-self-evolve-stg` bucket
(region `cn-beijing`). Each object is written twice:

- **`evolve_skill/latest/…`** — the stable prefix the docs link to, overwritten
  on every publish. The URLs are signature-free and **never expire**, so the
  docs don't rot.
- **`evolve_skill/dist/<UTC-timestamp>-<label>/…`** — a timestamped archive copy
  for rollback, never overwritten.

Because the `latest/` URLs are permanent, re-publishing does **not** require any
doc edits — the same URLs keep working. (`--no-public` falls back to the old
30-day presigned-URL behaviour if you ever need it; `ark-self-evolve-prod` is a
separate bucket for the prod-bound skill.)

The bundle excludes everything customers don't need: `tests/`, `scripts/`,
`build/`, `dist/`, `__pycache__`, `.egg-info`, and `prd.md` (which is a stale
PM sketch — the canonical spec is `shared/PLAYBOOK.md`).

---

## Troubleshooting

| Symptom | What it means | Fix |
|---------|---------------|-----|
| `'evolve' not on PATH yet` after install | pip put `evolve` under `~/.local/bin` (or the user-base bin) | Restart your shell, or add the path the installer printed to your shell rc |
| `pip install` fails with "externally managed environment" | Debian-managed Python | Run inside a venv/conda env, or pass `--break-system-packages` |
| `evolve init` returns `cloud_reachable: False` | wrong `EVOLVE_BASE_URL` or the backend is down | Re-check the URL (must end in `/case-platform`); curl it directly |
| `evolve init` returns 403 / `auth_source` mismatch | Ark key isn't registered against the backend's Ark service | Use a key registered in the Ark environment the installer bound this CLI to |
| `connector 'X' found no capabilities under R` | `EVOLVE_RUNTIME_ROOT` doesn't contain `CLAUDE.md` / `AGENTS.md` | Re-run with the right runtime root |
| Installer downloads but exits with "Bundle layout unexpected" | Tarball was truncated | Re-run; the bundle is small (~40 KB) but TOS occasionally returns partial bytes |
| Download URL returns `403 AccessDenied` | The bucket ACL changed, or you're hitting the bucket root (only object GETs are public) | Confirm the full object key; ask the operator to re-check the `ark-self-evolve-stg` bucket is still public-read |
| Installer aborts with "EVOLVE_BASE_URL is plaintext http://" | The base URL would send your Ark API key unencrypted | Use the `https://` variant of the URL, or set `EVOLVE_INSECURE=1` if you really mean to (not recommended for prod) |

The download URLs in this file live on the public-read `ark-self-evolve-stg`
bucket and **never expire** — no signatures, no rotation. If a URL stops
working, the bucket ACL likely changed; ask the operator to verify it's still
public-read and re-run `scripts/publish_bundle.py`.
