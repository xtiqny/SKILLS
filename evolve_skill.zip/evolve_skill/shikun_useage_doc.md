Evolve Skill
Evolve Skill 是面向 Claude Code、OpenClaw、TRAE 等 AI 工具的持续进化能力。
它可以学习 Agent 的近期会话，识别当前运行时中可优化的指令文件，并生成改进建议。在用户确认后，Evolve 会将建议写入 CLAUDE.md、AGENTS.md 等运行时文件，帮助 Agent 在后续任务中持续改进。

能力介绍
Evolve 支持以下核心能力：
- 会话学习：读取近期 Agent 会话，将其中的有效经验和问题作为优化证据上传至云端。
- 优化建议：基于历史会话，为当前 Agent 运行时生成可应用的优化提案。
- 提案解释：查看建议将修改哪些文件、修改原因、参考证据、风险和置信度。
- 变更预览：在写入前查看完整 diff，了解具体会发生哪些修改。
- 受控应用：仅在用户明确确认后，将建议写入运行时文件。
- 能力面发现：识别当前运行时中可被 Evolve 优化的指令文件和 Skills。

当前支持的Agent运行时如下：
This content is only supported in a Feishu Docs
使用限制
- 当前环境需允许agent使用 python3 3.9 及以上版本和 pip。（有conda，venv或者uv即可，原生python>=3.9也可）
- 开发机需要能够访问公网，以连接 Evolve 后端服务。
- 使用 Evolve 需要有效的 Ark API Key。Evolve 通过 API Key 识别当前账号，无需额外配置账号 ID 或用户名。
- 新部署环境、会话样本较少，或云端尚未积累足够经验时，暂时没有生成建议属于正常情况。
- 当前不提供独立的回滚命令。已应用内容会以可识别的标记块写入文件，删除对应标记块即可撤销。
使用 Evolve Skill
步骤一：订阅套餐
1. 在 开通管理-Agent Plan 页面购买 Agent Plan 个人版套餐。套餐说明参见套餐概览。
2. 在控制台进入使用配置页签，单击配置Harness，开启火山引擎Agent Evolve的抵扣开关。

待补充一张图
步骤二：安装 Evolve Skill
可将以下命令交给 Agent 执行，由 Agent 自动完成 Evolve Skill 和 CLI 的配置。
curl -fsSL "https://ark-self-evolve-stg.tos-cn-beijing.volces.com/evolve_skill/latest/install.sh" | bash
也可以按不同运行时手动安装对应的 Skill 包。
This content is only supported in a Feishu Docs
每个安装包均包含对应运行时的 SKILL.md、预构建的 Evolve CLI，以及 Agent 使用的共享指令文件。首次运行时，Agent 会自动安装所需 CLI，无需单独执行 pip install。
步骤三：完成首次设置
安装完成后，启动对应的 AI 工具，并对 Agent 说：
Set me up for evolve
Agent 会检查 Evolve 是否已完成设置。若尚未初始化，Agent 会识别当前运行时中的可优化文件，并在获得确认后完成初始化。
初始化后，Evolve 会保存当前运行时与可优化目标的绑定关系。后续使用时通常无需重复设置。
步骤四：在工具中使用 Evolve
完成初始化后，可以直接通过自然语言与 Agent 对话使用 Evolve。
This content is only supported in a Feishu Docs
Evolve 在执行初始化、导入会话和应用建议前，都会请求确认。
应用建议时，Evolve 会先展示 diff；只有在你明确确认后，才会将内容写入运行时文件。
CLI 接入方式
除通过 Skill 使用外，也可以直接调用 Evolve CLI，适用于脚本化调用、CI 流程或需要检查底层执行结果的场景。
CLI wheel 已包含在 Skill 安装包中。建议使用以下方式调用：
python3 -m evolve_cli --help
常用命令如下：
# 查看当前设置和待处理建议
python3 -m evolve_cli status

# 导入近期会话
python3 -m evolve_cli import --limit 5

# 查看建议
python3 -m evolve_cli proposals

# 查看某项建议
python3 -m evolve_cli proposal <proposal_id>

# 预览变更
python3 -m evolve_cli apply <proposal_id> --dry-run

# 应用变更
python3 -m evolve_cli apply <proposal_id>
通过 CLI 应用建议时，建议先使用 --dry-run 查看 diff，再执行实际应用。
常见问题
初始化后暂时没有建议，是否正常？
正常。刚部署的环境、会话样本较少，或云端尚未积累足够经验时，导入会话后可能暂时没有可用建议。
完成更多实际任务后，可以再次让 Agent 学习近期会话。
Evolve 会自动修改我的文件吗？
不会。
Evolve 会先展示 diff。只有在你明确确认后，才会将建议写入运行时文件。
如何撤销已应用的建议？
Evolve 会将已应用内容写入带有标记的代码块中，例如：
<!-- evolvor:chg_<id> -->
...
<!-- /evolvor:chg_<id> -->
删除对应代码块即可撤销该次变更。
提示找不到可优化文件怎么办？
请确认初始化时选择的目录正确，并且目录中存在对应运行时的指令文件。
例如：
- Claude Code：CLAUDE.md
- OpenClaw：AGENTS.md、SOUL.md 或相关 Skills
- TRAE：AGENTS.md
初始化或导入会话失败怎么办？
请检查：
- Ark API Key 是否有效；
- 当前网络是否可以访问 Evolve 后端；
- 当前运行时目录是否正确；
- 本机是否安装 Python 3.9 或更高版本，以及 pip。
