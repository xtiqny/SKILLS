# Install evolve_skill

_Last published: 2026-07-22, label `v16`, bucket `ark-self-evolve-stg` (stg-bound)._

## Upload-only path (no shell paste — recommended for IDE customers)

Download the per-runtime zip and drag-drop it into your IDE's skill upload UI. Each zip is fully self-contained — it carries the manifest, the shared playbook/contract, and a prebuilt `evolve_cli` wheel — so the agent can pip-install the CLI from the zip on first run with no network beyond pip's index.

| Runtime | UI path | Zip (permanent public URL) |
|---|---|---|
| Trae | Settings → Skills & Commands → Create → Upload | [evolve-setup-trae.zip](https://ark-self-evolve-stg.tos-cn-beijing.volces.com/evolve_skill/latest/evolve-setup-trae.zip) (44 KB) |
| Claude Code | Drop into `~/.claude/skills/` (unzip first) | [evolve-setup-claude_code.zip](https://ark-self-evolve-stg.tos-cn-beijing.volces.com/evolve_skill/latest/evolve-setup-claude_code.zip) (43 KB) |
| OpenClaw | Drop into `~/.openclaw/workspace/skills/` (unzip first) | [evolve-setup-openclaw.zip](https://ark-self-evolve-stg.tos-cn-beijing.volces.com/evolve_skill/latest/evolve-setup-openclaw.zip) (46 KB) |

Local copies of all three: `evolve_skill/dist/evolve-setup-{trae,claude_code,openclaw}.zip`.

After upload, say to your agent: **"set me up for evolve"**. The agent runs through `## First-run bootstrap` in `SKILL.md` (installs the bundled wheel, runs `evolve init`, asks for your Ark API key).

For Trae specifically, the 11-step manual acceptance journey is in `evolve_skill/trae/MANUAL_TESTS.md`.

## Shell-paste path (for dev / CI installs)

Run this in any shell with `python3` and `curl`; the script downloads the bundle from TOS, asks for your Ark API key, lets you pick a runtime (claude_code / openclaw / trae / all), and wires the skill into the right path. This build is stamped to the stg gateway over HTTPS, so no `EVOLVE_INSECURE` flag is needed.

```bash
curl -fsSL "https://ark-self-evolve-stg.tos-cn-beijing.volces.com/evolve_skill/latest/install.sh" | bash
```

Permanent public URLs (no signature, never expire). To re-publish: `python3 evolve_skill/scripts/build_upload_zips.py --label vN` (zips) or `python3 evolve_skill/scripts/publish_bundle.py --label vN` (curl-bundle) — both push to the `latest/` prefix, so these URLs keep working. See [INSTALL.md](INSTALL.md) for the full guide.
