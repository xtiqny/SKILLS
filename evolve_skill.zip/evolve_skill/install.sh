#!/usr/bin/env bash
# evolve_skill installer — conversational setup for the evolve-setup skill.
#
# Two modes:
#   1. STANDALONE — `curl -fsSL <public-url-to-this-script> | bash`
#      Downloads the bundle from TOS, untars to a temp dir, re-execs from inside it.
#   2. BUNDLE — `cd evolve_skill && bash install.sh`
#      Installs the `evolve` CLI and the skill manifest(s) into the runtime(s) you pick.
#
# Environment overrides (skip the matching prompt when set):
#   EVOLVE_BUNDLE_URL      override the default bundle URL (standalone mode only)
#   EVOLVE_BASE_URL        self_evolve API gateway URL ending in /case-platform
#                          (defaults to the rollout URL baked in below)
#   EVOLVE_API_KEY         Ark API key (sent as Authorization: Bearer) — sole identity
#   EVOLVE_AGENT_ID        agent UUID (auto-generated if omitted)
#   EVOLVE_RUNTIME         claude_code | openclaw | both (default: ask)
#   EVOLVE_RUNTIME_ROOT    where CLAUDE.md / AGENTS.md lives
#   EVOLVE_INSECURE        set to 1 to allow plaintext http:// (the Ark key
#                          travels in clear text — only for known-internal hosts)
#   EVOLVE_NONINTERACTIVE  set to 1 to fail rather than prompt for missing vars
#   EVOLVE_SKIP_INIT       set to 1 to skip the auto `evolve init` at the end
#
# NOTE: account_id and user_name are NOT collected — under Ark-key auth the
# backend derives identity from the verified Ark key and ignores the
# X-Top-Account-Id / X-Top-User-Name headers entirely. (X-Top-User-Name isn't
# even the right header name; the backend reads X-Top-IdentityName, and only
# under TOP-gateway auth.) Asking the user for them was friction with no
# behavioral effect. See evolve_skill/cli/src/evolve_cli/api.py and
# case_platform/.../self_evolve/auth.py if this changes.
set -euo pipefail

# --- the only place that needs updating when the bundle is re-uploaded -------
# publish_bundle.py bakes the permanent public-read URL of the latest/ tarball
# in here (https://ark-self-evolve-stg.tos-cn-beijing.volces.com/evolve_skill/
# latest/evolve_skill.tar.gz). It never expires, so re-publishing to latest/
# keeps this value valid — no doc/script edits needed on each release.
DEFAULT_BUNDLE_URL="${EVOLVE_BUNDLE_URL:-__EVOLVE_BUNDLE_URL__}"

# The single rollout backend the skill is bound to. Customers do not see an
# "environment" knob — see _BOUND_ENV / _ENV_BASE_URL in
# cli/src/evolve_cli/config.py for the matching CLI-side constants. The CLI now
# carries the same per-env default baked in, so the copy-and-go (zip) install
# path needs no URL at all; this wizard value just pre-fills the prompt and is
# written to ~/.evolve-skill.env as EVOLVE_BASE_URL.
# TODO(prod): the prod artifact stamps _BOUND_ENV="prod" at publish time and the
# CLI resolves the prompt-pilot URL automatically; keep this stg value in sync
# with _ENV_BASE_URL["stg"]. The value points at the stg-style apigateway over
# HTTPS, so the installer's http:// guard stays quiet.
DEFAULT_BASE_URL="https://prompt-pilot.cn-beijing.volces.com/case-platform"

# --- pretty printing ---------------------------------------------------------
if [ -t 1 ]; then
  c_bold=$'\033[1m'; c_dim=$'\033[2m'; c_grn=$'\033[32m'; c_ylw=$'\033[33m'
  c_red=$'\033[31m'; c_blu=$'\033[34m'; c_off=$'\033[0m'
else
  c_bold=""; c_dim=""; c_grn=""; c_ylw=""; c_red=""; c_blu=""; c_off=""
fi
say()  { printf '%s\n' "$*"; }
hd()   { printf '\n%s%s%s\n' "$c_bold" "$*" "$c_off"; }
info() { printf '%s%s%s\n' "$c_blu" "$*" "$c_off"; }
ok()   { printf '%s✓%s %s\n' "$c_grn" "$c_off" "$*"; }
warn() { printf '%s!%s %s\n' "$c_ylw" "$c_off" "$*"; }
die()  { printf '%s✗%s %s\n' "$c_red" "$c_off" "$*" >&2; exit 1; }

# --- step 1: where am I (standalone vs. bundle) ------------------------------
script_dir() {
  # When piped (curl | bash) BASH_SOURCE may be empty / "bash"; treat that as standalone.
  local s="${BASH_SOURCE[0]:-}"
  case "$s" in
    ""|bash|/dev/fd/*|/proc/self/fd/*) printf ""; return ;;
  esac
  cd "$(dirname "$s")" >/dev/null 2>&1 && pwd
}
SCRIPT_DIR="$(script_dir)"
IS_BUNDLE=0
# A real bundle root has cli/, shared/, and at least one runtime manifest dir.
if [ -n "$SCRIPT_DIR" ] \
   && [ -d "$SCRIPT_DIR/cli" ] \
   && [ -d "$SCRIPT_DIR/shared" ] \
   && { [ -d "$SCRIPT_DIR/claude_code" ] || [ -d "$SCRIPT_DIR/openclaw" ]; }; then
  IS_BUNDLE=1
fi

if [ "$IS_BUNDLE" -eq 0 ]; then
  hd "Evolve Skill — bootstrapping"
  [ -n "$DEFAULT_BUNDLE_URL" ] && [ "$DEFAULT_BUNDLE_URL" != "__EVOLVE_BUNDLE_URL__" ] || \
    die "No bundle URL baked in and EVOLVE_BUNDLE_URL is unset. Either run from inside an extracted evolve_skill/ folder, or set EVOLVE_BUNDLE_URL=<signed-url>."
  command -v curl >/dev/null || die "curl is required."
  command -v tar  >/dev/null || die "tar is required."
  TMP="$(mktemp -d -t evolve-skill.XXXXXX)"
  trap 'rm -rf "$TMP"' EXIT
  info "Downloading bundle…"
  curl -fsSL "$DEFAULT_BUNDLE_URL" -o "$TMP/bundle.tgz" || die "Download failed."
  info "Extracting…"
  tar -xzf "$TMP/bundle.tgz" -C "$TMP"
  # Locate the evolve_skill/ root inside the tarball (single-folder layout).
  ROOT="$(find "$TMP" -maxdepth 3 -type d -name evolve_skill | head -n1)"
  if [ -z "$ROOT" ] || [ ! -d "$ROOT/cli" ]; then
    # Fallback: tarball might already be extracted at top-level (no wrapping dir).
    if [ -d "$TMP/cli" ] && [ -d "$TMP/shared" ]; then
      ROOT="$TMP"
    else
      die "Bundle layout unexpected — no evolve_skill/ root with cli/ inside."
    fi
  fi
  ok "Bundle ready at $ROOT"
  # NOTE: bash (not exec) — we want the EXIT trap above to clean up $TMP after
  # the inner installer returns. exec replaces the current shell, dropping the trap.
  # Redirect stdin from /dev/tty so the inner installer's prompts work even when
  # we were piped from `curl … | bash` (in which case our own stdin is the
  # already-closed pipe and `read` would EOF immediately under `set -e`).
  if [ -e /dev/tty ] && [ "${EVOLVE_NONINTERACTIVE:-0}" != "1" ]; then
    bash "$ROOT/install.sh" "$@" </dev/tty
  else
    bash "$ROOT/install.sh" "$@"
  fi
  exit $?
fi

# ============================================================================
#  Bundle mode — actual installer
# ============================================================================
cd "$SCRIPT_DIR"

hd "Evolve Skill — installer"
say "${c_dim}This installs the ${c_off}${c_bold}evolve${c_off}${c_dim} CLI and the ${c_off}${c_bold}evolve-setup${c_off}${c_dim} skill into your agent runtime.${c_off}"
say "${c_dim}You can re-run this any time; it overwrites in place. Ctrl-C to abort.${c_off}"

# --- helpers -----------------------------------------------------------------
NONINT="${EVOLVE_NONINTERACTIVE:-0}"
prompt() {
  # prompt VAR "Question" "default" [silent] [required]
  local _var="$1" _q="$2" _def="${3:-}" _silent="${4:-0}" _req="${5:-0}" _v
  if [ -n "${!_var:-}" ]; then return; fi
  if [ "$NONINT" = "1" ]; then
    if [ -n "$_def" ]; then
      printf -v "$_var" '%s' "$_def"; return
    fi
    if [ "$_req" = "1" ]; then
      die "$_var is required (non-interactive mode)."
    fi
    printf -v "$_var" '%s' ""
    return
  fi
  # If our own stdin isn't a tty (e.g. someone ran `cat install.sh | bash` or
  # forgot to redirect </dev/tty), fall back to /dev/tty so prompts still work.
  local _read_from=""
  if [ ! -t 0 ] && [ -e /dev/tty ]; then
    _read_from="/dev/tty"
  fi
  local _suffix=""; [ -n "$_def" ] && _suffix=" [${_def}]"
  if [ "$_silent" = "1" ]; then
    printf '%s%s%s' "$c_bold" "$_q" "$c_off"
    printf '%s%s%s: ' "$c_dim" "$_suffix" "$c_off"
    if [ -n "$_read_from" ]; then read -r -s _v <"$_read_from"; else read -r -s _v; fi
    printf '\n'
  else
    printf '%s%s%s%s%s%s: ' "$c_bold" "$_q" "$c_off" "$c_dim" "$_suffix" "$c_off"
    if [ -n "$_read_from" ]; then read -r _v <"$_read_from"; else read -r _v; fi
  fi
  [ -z "$_v" ] && _v="$_def"
  printf -v "$_var" '%s' "$_v"
}
confirm() {
  # confirm "Question" default(y|n)
  local _q="$1" _def="${2:-y}" _v
  if [ "$NONINT" = "1" ]; then
    [ "$_def" = "y" ] && return 0 || return 1
  fi
  local _read_from=""
  if [ ! -t 0 ] && [ -e /dev/tty ]; then
    _read_from="/dev/tty"
  fi
  local _hint="[Y/n]"; [ "$_def" = "n" ] && _hint="[y/N]"
  printf '%s%s%s %s ' "$c_bold" "$_q" "$c_off" "$_hint"
  if [ -n "$_read_from" ]; then read -r _v <"$_read_from"; else read -r _v; fi
  [ -z "$_v" ] && _v="$_def"
  case "$_v" in y|Y|yes|YES) return 0 ;; *) return 1 ;; esac
}

# --- step 2: confirm the backend URL ----------------------------------------
hd "1. Backend URL"
EVOLVE_BASE_URL="${EVOLVE_BASE_URL:-$DEFAULT_BASE_URL}"
prompt EVOLVE_BASE_URL "Backend base URL (must end in /case-platform)" "$EVOLVE_BASE_URL" 0 1
case "$EVOLVE_BASE_URL" in
  http://*|https://*) ;;
  *) die "EVOLVE_BASE_URL must start with http(s)://" ;;
esac

# Reject plaintext HTTP unless the user explicitly opts in — we're about to
# send an Ark API key as Authorization: Bearer, which on a public network
# leaks a bearer credential.
case "$EVOLVE_BASE_URL" in
  http://127.0.0.1*|http://localhost*|http://[::1]*) ;;  # local dev is fine
  http://*)
    if [ "${EVOLVE_INSECURE:-0}" = "1" ]; then
      warn "EVOLVE_BASE_URL is plaintext http:// — your Ark API key will travel unencrypted."
      warn "Proceeding because EVOLVE_INSECURE=1."
    elif [ "$NONINT" = "1" ]; then
      die "EVOLVE_BASE_URL is plaintext http://; refusing in non-interactive mode. Set EVOLVE_INSECURE=1 to override (NOT recommended for prod)."
    else
      warn "EVOLVE_BASE_URL is plaintext http:// — your Ark API key will travel UNENCRYPTED."
      if confirm "Continue anyway?" n; then
        :
      else
        die "Aborted by user. Use an https:// URL or set EVOLVE_INSECURE=1."
      fi
    fi
    ;;
esac

# --- step 3: identity (Ark key) ----------------------------------------------
hd "2. Who are you to the backend?"
say "${c_dim}The backend identifies you by your Ark API key (sent as Authorization: Bearer).${c_off}"
say "${c_dim}The key must be registered in the Ark service the backend points at;${c_off}"
say "${c_dim}the local mock harness ignores it.${c_off}"
EVOLVE_API_KEY="${EVOLVE_API_KEY:-${ARK_API_KEY:-}}"
prompt EVOLVE_API_KEY "Ark API key (input is hidden)" "" 1
[ -n "$EVOLVE_API_KEY" ] || warn "No Ark key entered — every backend call will 403 until you set EVOLVE_API_KEY."

# --- step 4: agent + runtime root --------------------------------------------
hd "3. Which runtime is this skill for?"
RUNTIME="${EVOLVE_RUNTIME:-}"
if [ -z "$RUNTIME" ]; then
  if [ "$NONINT" = "1" ]; then
    RUNTIME="claude_code"
  else
    say "  1) claude_code — installs to ~/.claude/skills/evolve-setup/"
    say "  2) openclaw    — installs to ~/.openclaw/workspace/skills/evolve-setup/"
    say "  3) trae        — installs to <project>/.trae/skills/evolve-setup/ + <project>/.agents/skills/evolve-setup/"
    say "  4) all         — claude_code + openclaw + trae"
    printf '%sChoose 1-4 [1]:%s ' "$c_bold" "$c_off"
    read -r _r; _r="${_r:-1}"
    case "$_r" in
      1) RUNTIME="claude_code" ;;
      2) RUNTIME="openclaw" ;;
      3) RUNTIME="trae" ;;
      4) RUNTIME="all" ;;
      *) die "Invalid." ;;
    esac
  fi
fi

# Sanity-check the skill manifests are actually present in the bundle.
case "$RUNTIME" in
  claude_code|all) [ -f "$SCRIPT_DIR/claude_code/SKILL.md"   ] || die "Bundle is missing claude_code/SKILL.md." ;;
esac
case "$RUNTIME" in
  openclaw|all)    [ -f "$SCRIPT_DIR/openclaw/SKILL.toml"    ] || die "Bundle is missing openclaw/SKILL.toml." ;;
esac
case "$RUNTIME" in
  # OpenClaw reads both SKILL.md (human-readable manifest, frontmatter-typed)
  # and SKILL.toml (structured tool registry) from the skill dir — feishu-doc
  # / feishu-perm / feishu-wiki / feishu-drive all ship SKILL.md alongside
  # whatever structured registry they use. We were shipping only the toml
  # for evolve-setup, which left the openclaw side without the markdown that
  # tells the agent how to think about the lifecycle. Refuse to install if
  # it's missing from the bundle.
  openclaw|all)    [ -f "$SCRIPT_DIR/openclaw/SKILL.md"      ] || die "Bundle is missing openclaw/SKILL.md." ;;
esac
case "$RUNTIME" in
  trae|all)        [ -f "$SCRIPT_DIR/trae/SKILL.md"          ] || die "Bundle is missing trae/SKILL.md." ;;
esac

case "$RUNTIME" in
  claude_code|trae|all) DEFAULT_RUNTIME_ROOT="${EVOLVE_RUNTIME_ROOT:-$PWD}" ;;
  openclaw)             DEFAULT_RUNTIME_ROOT="${EVOLVE_RUNTIME_ROOT:-$HOME/.openclaw/workspace}" ;;
  *) die "EVOLVE_RUNTIME must be claude_code|openclaw|trae|all (got $RUNTIME)" ;;
esac
EVOLVE_RUNTIME_ROOT="${EVOLVE_RUNTIME_ROOT:-}"
if [ -z "$EVOLVE_RUNTIME_ROOT" ]; then
  prompt EVOLVE_RUNTIME_ROOT "Runtime root (where CLAUDE.md / AGENTS.md lives)" "$DEFAULT_RUNTIME_ROOT"
fi

# Default agent_id per primary connector
case "$RUNTIME" in
  all)         PRIMARY_CONNECTOR="claude_code" ;;
  *)           PRIMARY_CONNECTOR="$RUNTIME" ;;
esac
prompt EVOLVE_AGENT_ID "Agent id (UUID; blank = auto-generate)" ""

# --- step 5: pip install evolve CLI ------------------------------------------
hd "4. Installing the evolve CLI"
PYBIN="${PYTHON:-python3}"
command -v "$PYBIN" >/dev/null || die "python3 not found — install Python 3.9+ first."
PIPFLAGS=( --upgrade )
# Inside an active venv/conda we MUST NOT pass --user.
if [ -z "${VIRTUAL_ENV:-}" ] && [ -z "${CONDA_PREFIX:-}" ]; then
  PIPFLAGS=( --user "${PIPFLAGS[@]}" )
fi

# Some base images (notably the claudecode AIO sandbox / Debian-managed Python)
# ship pip 22.0.2 / setuptools <61, which silently install PEP 621 packages as
# `UNKNOWN-0.0.0` (no entry points, no importable module) and exit 0. That makes
# the post-install sanity check fail confusingly. Upgrade pip+setuptools first
# so [project].name in pyproject.toml is honored.
PIP_VER="$("$PYBIN" -m pip --version 2>/dev/null | awk '{print $2}')"
PIP_MAJOR="${PIP_VER%%.*}"
if [ -z "$PIP_MAJOR" ] || [ "$PIP_MAJOR" -lt 23 ] 2>/dev/null; then
  info "Upgrading pip+setuptools (yours is ${PIP_VER:-unknown}; need >=23 for PEP 621 pyproject.toml)"
  if ! "$PYBIN" -m pip install "${PIPFLAGS[@]}" "pip>=23" "setuptools>=68" 2>&1 | tail -3; then
    warn "pip self-upgrade failed; continuing — install may install as UNKNOWN-0.0.0."
  fi
fi

info "Running: $PYBIN -m pip install ${PIPFLAGS[*]} ./cli"
# NOTE: not --quiet — customers need to see real errors if pip install fails.
if ! "$PYBIN" -m pip install "${PIPFLAGS[@]}" "$SCRIPT_DIR/cli" 2>&1 | tail -8; then
  die "pip install failed (see lines above)."
fi
ok "pip install reported success."

# Strong post-install verification. The pip-22.x/UNKNOWN-0.0.0 trap exits 0 with
# no usable artifact, so a clean exit is NOT proof of a working install. Verify
# the package is actually importable as `evolve_cli` and the CLI runs.
EVOLVE_CMD="$PYBIN -m evolve_cli"
if ! "$PYBIN" -c "import evolve_cli; import evolve_cli.main" >/dev/null 2>&1; then
  warn "Post-install sanity check FAILED: '$PYBIN -c \"import evolve_cli\"' did not resolve."
  warn "This usually means pip silently installed the package as UNKNOWN-0.0.0 (a known trap on"
  warn "pip<23 with PEP 621 pyproject.toml). Try:"
  warn "    $PYBIN -m pip install --upgrade pip setuptools"
  warn "    $PYBIN -m pip install $SCRIPT_DIR/cli"
  warn "If you see 'Successfully installed UNKNOWN-0.0.0', that's the bug."
  die "Aborting before writing the env file — fix the install first."
fi
if ! "$PYBIN" -m evolve_cli --help >/dev/null 2>&1; then
  die "Post-install sanity check FAILED: '$PYBIN -m evolve_cli --help' returned nonzero. Check the pip output above."
fi
ok "evolve CLI verified callable as: $EVOLVE_CMD"

# Make sure `evolve` is also on PATH for direct CLI use later (best-effort).
if ! command -v evolve >/dev/null 2>&1; then
  USERBASE="$("$PYBIN" -c 'import site; print(site.USER_BASE)' 2>/dev/null || true)"
  if [ -n "$USERBASE" ] && [ -x "$USERBASE/bin/evolve" ]; then
    export PATH="$USERBASE/bin:$PATH"
    warn "Added $USERBASE/bin to PATH for this run. Add it to your shell rc to make 'evolve' work in new shells."
  else
    warn "'evolve' is not on PATH yet. The skill calls it via '$EVOLVE_CMD' so this works, but you may want to add the pip --user bin dir to PATH for direct CLI use."
  fi
fi

# --- step 6: copy skill manifests --------------------------------------------
install_claude_code() {
  local dst="$HOME/.claude/skills/evolve-setup"
  hd "5a. Installing Claude Code skill → $dst"
  mkdir -p "$dst"
  cp "$SCRIPT_DIR/claude_code/SKILL.md" "$dst/SKILL.md"
  rm -rf -- "$dst/shared"
  cp -R "$SCRIPT_DIR/shared" "$dst/shared"
  ok "Claude Code skill installed."
}
install_openclaw() {
  local dst="$HOME/.openclaw/workspace/skills/evolve-setup"
  hd "5b. Installing OpenClaw skill → $dst"
  mkdir -p "$dst"
  # Ship BOTH manifests: SKILL.toml is the structured tool registry OpenClaw
  # binds at activation, and SKILL.md is the human-readable lifecycle guide
  # the agent reads when it's reasoning about *which* tool to invoke. Without
  # the .md the agent falls back to guessing, and we saw weaker models forget
  # required flags (e.g. --runtime-root) entirely.
  cp "$SCRIPT_DIR/openclaw/SKILL.toml" "$dst/SKILL.toml"
  cp "$SCRIPT_DIR/openclaw/SKILL.md"   "$dst/SKILL.md"
  rm -rf -- "$dst/shared"
  cp -R "$SCRIPT_DIR/shared" "$dst/shared"
  ok "OpenClaw skill installed."
}
install_trae() {
  # Trae picks up skills from <project>/.trae/skills/ (native) and
  # <project>/.agents/skills/ (cross-IDE convention, toggle-gated in Trae's
  # Settings). Install to BOTH so it works regardless of which toggle is on.
  # If a name collides, the .trae/skills/ copy wins per Trae's docs.
  local native="$EVOLVE_RUNTIME_ROOT/.trae/skills/evolve-setup"
  local crossi="$EVOLVE_RUNTIME_ROOT/.agents/skills/evolve-setup"
  hd "5c. Installing Trae skill → $native + $crossi"
  for dst in "$native" "$crossi"; do
    mkdir -p "$dst"
    cp "$SCRIPT_DIR/trae/SKILL.md" "$dst/SKILL.md"
    rm -rf -- "$dst/shared"
    cp -R "$SCRIPT_DIR/shared" "$dst/shared"
  done
  ok "Trae skill installed (both .trae/skills/ and .agents/skills/)."
}
case "$RUNTIME" in
  claude_code) install_claude_code ;;
  openclaw)    install_openclaw ;;
  trae)        install_trae ;;
  all)         install_claude_code; install_openclaw; install_trae ;;
esac

# --- step 7: write a sourceable env file -------------------------------------
ENVFILE="$HOME/.evolve-skill.env"
hd "6. Writing $ENVFILE"
# NOTE: EVOLVE_CONNECTOR is deliberately NOT written here. CLI state is scoped
# per connector (~/.evolve/<connector>/), and a machine may run several runtimes
# off this one shared env file — a global EVOLVE_CONNECTOR would force them all
# onto one shard. `evolve init --connector X` shards by its flag; read commands
# autodetect a lone shard (and each runtime's skill sets EVOLVE_CONNECTOR per call
# when several coexist).
{
  printf '# Generated by evolve_skill installer. Source this to put EVOLVE_* on env.\n'
  printf 'export EVOLVE_BASE_URL=%q\n'   "$EVOLVE_BASE_URL"
  printf 'export EVOLVE_RUNTIME_ROOT=%q\n' "$EVOLVE_RUNTIME_ROOT"
  [ -n "$EVOLVE_AGENT_ID" ] && printf 'export EVOLVE_AGENT_ID=%q\n' "$EVOLVE_AGENT_ID"
  [ -n "$EVOLVE_API_KEY" ]  && printf 'export EVOLVE_API_KEY=%q\n'  "$EVOLVE_API_KEY"
} > "$ENVFILE"
chmod 600 "$ENVFILE"
ok "Wrote $ENVFILE (chmod 600). Add ${c_bold}source $ENVFILE${c_off} to your shell rc."

# --- step 8: optionally run `evolve init` ------------------------------------
if [ "${EVOLVE_SKIP_INIT:-0}" = "1" ]; then
  warn "Skipping 'evolve init' (EVOLVE_SKIP_INIT=1). Run it yourself when ready."
else
  hd "7. Initializing evolve workspace"
  if confirm "Run 'evolve init' now to register this agent with the cloud?" y; then
    set +e
    # shellcheck disable=SC1090
    . "$ENVFILE"
    init_args=( --connector "$PRIMARY_CONNECTOR"
                --runtime-root "$EVOLVE_RUNTIME_ROOT"
                --base-url "$EVOLVE_BASE_URL" )
    [ -n "$EVOLVE_AGENT_ID" ] && init_args+=( --agent-id "$EVOLVE_AGENT_ID" )
    [ -n "$EVOLVE_API_KEY" ]  && init_args+=( --api-key  "$EVOLVE_API_KEY" )
    # Use the same Python we installed under to avoid stale `evolve` shims on PATH.
    "$PYBIN" -m evolve_cli init "${init_args[@]}"
    rc=$?
    set -e
    if [ "$rc" -eq 0 ]; then
      ok "evolve init succeeded."
      "$PYBIN" -m evolve_cli status || true
    else
      warn "evolve init exited $rc — fix the issue and re-run '$PYBIN -m evolve_cli init' manually."
    fi
  else
    say "OK — run 'evolve init' yourself when ready (the env file already has the flags)."
  fi
fi

hd "Done."
say "Next steps:"
say "  • Open your agent (Claude Code / OpenClaw) — it will discover the ${c_bold}evolve-setup${c_off} skill."
say "  • Say ${c_bold}\"set me up for evolve\"${c_off} or ${c_bold}\"learn from my recent sessions\"${c_off}."
say "  • To uninstall, run ${c_bold}bash uninstall.sh${c_off} from the same bundle."
