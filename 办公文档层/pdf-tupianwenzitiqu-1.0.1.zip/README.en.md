# Document Vision Text Recovery

A robust skill for recovering text from PDFs, scanned documents, and images. It first diagnoses each page, then selects native PDF extraction, visual/OCR recognition, or a mixed strategy.

## Highlights

- Native PDF text extraction
- Scanned-page visual/OCR fallback
- Mixed-document recovery
- Layout-aware reading order
- Headings, paragraphs, lists, tables, headers and footers
- Multi-column handling
- Extra verification for dates, amounts, identifiers, URLs and code
- Explicit uncertainty markers
- Markdown, plain text, faithful transcription, or structured fields
- Large-file batch processing
- Page-level diagnostics

## Dependency

```bash
pip install 'pymupdf>=1.24.0'
```

The helper script does not embed a third-party OCR service. OCR/vision on scanned pages is delegated to the visual/OCR capability available in the host environment.

## Diagnostics

```bash
python scripts/pdf_page_probe.py document.pdf
```

Render selected pages:

```bash
python scripts/pdf_page_probe.py document.pdf --pages 2,5-7 --render-dir ./rendered --dpi 180
```
