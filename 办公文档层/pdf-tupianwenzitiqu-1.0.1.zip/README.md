# 文档视觉文字精炼器

**Document Vision Text Recovery · v2.0.0**

一个面向 PDF、扫描件和图片文字恢复的通用 Skill。它不把所有文件都当成“普通 OCR”，而是先判断页面类型，再选择最合适的提取路径。

## 主要能力

- 原生 PDF 文本层提取
- 扫描型 PDF 的页面渲染与视觉/OCR 回退
- 混合 PDF 联合恢复
- 中文、英文、数字及常见符号识别
- 标题、段落、列表、表格和页眉页脚的结构恢复
- 多栏阅读顺序处理
- 金额、日期、编号、代码等高风险内容二次复核
- 不确定字符显式标记
- 输出为保真转写、Markdown、纯文本或字段数据
- 超长 PDF 分批处理
- 页面级异常诊断

## 依赖

```bash
pip install 'pymupdf>=1.24.0'
```

本 Skill 的 PDF 辅助脚本不依赖外部 OCR 服务。扫描页的真正 OCR/视觉识别由当前运行环境可用的视觉或 OCR 能力完成。

## PDF 页面诊断

```bash
python scripts/pdf_page_probe.py document.pdf
```

渲染指定页面：

```bash
python scripts/pdf_page_probe.py document.pdf --pages 2,5-7 --render-dir ./rendered --dpi 180
```

输出会告诉你每页更接近原生文本、扫描页、混合页还是可疑页，并可生成后续视觉识别所需的 PNG。

## 设计原则

1. 能从 PDF 文本层可靠提取时，不做多余 OCR。
2. 文本层为空不等于页面没有文字。
3. 不依赖单一字号阈值猜标题。
4. 不通过常识“修正”看不清的原文。
5. 关键数字必须优先复核。
6. 任何无法可靠恢复的内容都明确标记，不伪造确定性。
