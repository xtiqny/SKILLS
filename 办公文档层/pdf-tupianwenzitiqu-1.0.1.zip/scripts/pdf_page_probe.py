#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""PDF diagnostics and page rendering helper.

The script does not perform OCR. It diagnoses whether a page is likely to contain
native text, scanned content, mixed content, or suspicious text, and can render
selected pages to PNG for a downstream vision/OCR system.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path
from typing import Any

try:
    import fitz  # PyMuPDF
except ImportError:
    print(json.dumps({
        "success": False,
        "error": "Missing dependency: PyMuPDF. Install with: pip install 'pymupdf>=1.24.0'"
    }, ensure_ascii=False))
    raise SystemExit(1)


def _safe_text_len(text: str) -> int:
    return len("".join(text.split()))


def inspect_page(page: fitz.Page) -> dict[str, Any]:
    text_dict = page.get_text("dict")
    text_blocks = [b for b in text_dict.get("blocks", []) if b.get("type") == 0]
    image_blocks = [b for b in text_dict.get("blocks", []) if b.get("type") == 1]
    raw_text = page.get_text("text") or ""
    chars = _safe_text_len(raw_text)
    block_count = len(text_blocks)
    span_count = 0
    bbox_area = 0.0
    page_area = max(page.rect.width * page.rect.height, 1.0)

    for block in text_blocks:
        bbox = block.get("bbox")
        if bbox and len(bbox) == 4:
            x0, y0, x1, y1 = bbox
            bbox_area += max(0.0, x1 - x0) * max(0.0, y1 - y0)
        for line in block.get("lines", []):
            span_count += len(line.get("spans", []))

    text_density = min(bbox_area / page_area, 1.0)
    image_count = len(image_blocks)

    # Heuristics are intentionally conservative. They are diagnostics, not OCR truth.
    if chars >= 12 and block_count >= 1 and image_count == 0:
        kind = "native-text"
    elif chars < 10 and image_count >= 1:
        kind = "scanned"
    elif chars >= 10 and image_count >= 1:
        kind = "mixed"
    elif chars < 10 and image_count == 0:
        kind = "empty-or-nontext"
    else:
        kind = "suspicious"

    return {
        "kind": kind,
        "char_count": chars,
        "text_block_count": block_count,
        "span_count": span_count,
        "image_block_count": image_count,
        "text_density": round(text_density, 4),
        "width": round(page.rect.width, 2),
        "height": round(page.rect.height, 2),
    }


def render_page(page: fitz.Page, output: Path, dpi: int) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    scale = max(dpi, 72) / 72.0
    matrix = fitz.Matrix(scale, scale)
    pix = page.get_pixmap(matrix=matrix, alpha=False)
    pix.save(str(output))


def parse_page_list(value: str | None, total: int) -> list[int]:
    if not value:
        return []
    result: set[int] = set()
    for chunk in value.split(","):
        chunk = chunk.strip()
        if not chunk:
            continue
        if "-" in chunk:
            a, b = chunk.split("-", 1)
            start, end = int(a), int(b)
            if start > end:
                start, end = end, start
            for n in range(start, end + 1):
                if 1 <= n <= total:
                    result.add(n)
        else:
            n = int(chunk)
            if 1 <= n <= total:
                result.add(n)
    return sorted(result)


def main() -> int:
    parser = argparse.ArgumentParser(description="Inspect PDF pages and optionally render selected pages.")
    parser.add_argument("pdf", help="Path to PDF")
    parser.add_argument("--pages", help="1-based pages/ranges, e.g. 1,3-5")
    parser.add_argument("--render-dir", help="Directory for rendered PNG pages")
    parser.add_argument("--dpi", type=int, default=180, help="Render DPI, default 180")
    args = parser.parse_args()

    path = Path(args.pdf)
    if not path.is_file():
        print(json.dumps({"success": False, "error": f"File not found: {path}"}, ensure_ascii=False))
        return 1
    if path.suffix.lower() != ".pdf":
        print(json.dumps({"success": False, "error": "Input must be a PDF file."}, ensure_ascii=False))
        return 1

    try:
        with fitz.open(path) as doc:
            if doc.is_encrypted:
                # authenticate() is intentionally not attempted without a password.
                print(json.dumps({
                    "success": False,
                    "error": "PDF is encrypted or password-protected; a password is required before inspection.",
                    "page_count": len(doc)
                }, ensure_ascii=False, indent=2))
                return 1

            pages = []
            for i, page in enumerate(doc, start=1):
                info = inspect_page(page)
                info["page"] = i
                pages.append(info)

            render_pages = parse_page_list(args.pages, len(doc))
            rendered = []
            if render_pages:
                if not args.render_dir:
                    print(json.dumps({"success": False, "error": "--render-dir is required when --pages is used."}, ensure_ascii=False))
                    return 1
                out_dir = Path(args.render_dir)
                for pno in render_pages:
                    target = out_dir / f"page_{pno:04d}.png"
                    render_page(doc[pno - 1], target, args.dpi)
                    rendered.append(str(target))

            result = {
                "success": True,
                "file": str(path),
                "page_count": len(doc),
                "metadata": doc.metadata,
                "pages": pages,
                "rendered_pages": rendered,
            }
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0
    except Exception as exc:
        print(json.dumps({"success": False, "error": f"PDF processing failed: {exc}"}, ensure_ascii=False, indent=2))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
